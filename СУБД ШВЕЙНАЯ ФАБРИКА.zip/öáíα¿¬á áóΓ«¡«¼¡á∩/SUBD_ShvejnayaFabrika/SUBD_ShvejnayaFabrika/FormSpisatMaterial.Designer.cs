﻿namespace SUBD_ShvejnayaFabrika
{
    partial class FormSpisatMaterial
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.u37_15DataSet1 = new SUBD_ShvejnayaFabrika.u37_15DataSet();
            this.furnituraBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.furnituraTableAdapter = new SUBD_ShvejnayaFabrika.u37_15DataSetTableAdapters.FurnituraTableAdapter();
            this.tableAdapterManager = new SUBD_ShvejnayaFabrika.u37_15DataSetTableAdapters.TableAdapterManager();
            this.izdeliyaTableAdapter = new SUBD_ShvejnayaFabrika.u37_15DataSetTableAdapters.IzdeliyaTableAdapter();
            this.tkaniTableAdapter = new SUBD_ShvejnayaFabrika.u37_15DataSetTableAdapters.TkaniTableAdapter();
            this.furnituraDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TkaniBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.TkaniDataGridView = new System.Windows.Forms.DataGridView();
            this.NazvanieTkan = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnSpisMaterial = new System.Windows.Forms.Button();
            this.btnSformirDock = new System.Windows.Forms.Button();
            this.btnOtmena = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.u37_15DataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.furnituraBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.furnituraDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TkaniBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TkaniDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(886, 128);
            this.panel1.TabIndex = 15;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(221, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(443, 37);
            this.label1.TabIndex = 1;
            this.label1.Text = "Форма списания материала\r\n";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Left;
            this.pictureBox1.Image = global::SUBD_ShvejnayaFabrika.Properties.Resources.fabric_logo;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(169, 128);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // u37_15DataSet1
            // 
            this.u37_15DataSet1.DataSetName = "u37_15DataSet";
            this.u37_15DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // furnituraBindingSource
            // 
            this.furnituraBindingSource.DataMember = "Furnitura";
            this.furnituraBindingSource.DataSource = this.u37_15DataSet1;
            this.furnituraBindingSource.Filter = "countfur > 0";
            // 
            // furnituraTableAdapter
            // 
            this.furnituraTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.FurnituraTableAdapter = this.furnituraTableAdapter;
            this.tableAdapterManager.IzdeliyaTableAdapter = this.izdeliyaTableAdapter;
            this.tableAdapterManager.PolzovateliTableAdapter = null;
            this.tableAdapterManager.TkaniTableAdapter = this.tkaniTableAdapter;
            this.tableAdapterManager.UpdateOrder = SUBD_ShvejnayaFabrika.u37_15DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.ZakazyTableAdapter = null;
            // 
            // izdeliyaTableAdapter
            // 
            this.izdeliyaTableAdapter.ClearBeforeFill = true;
            // 
            // tkaniTableAdapter
            // 
            this.tkaniTableAdapter.ClearBeforeFill = true;
            // 
            // furnituraDataGridView
            // 
            this.furnituraDataGridView.AllowUserToAddRows = false;
            this.furnituraDataGridView.AllowUserToDeleteRows = false;
            this.furnituraDataGridView.AutoGenerateColumns = false;
            this.furnituraDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.furnituraDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.Column1,
            this.Column2});
            this.furnituraDataGridView.DataSource = this.furnituraBindingSource;
            this.furnituraDataGridView.Location = new System.Drawing.Point(12, 161);
            this.furnituraDataGridView.Name = "furnituraDataGridView";
            this.furnituraDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.furnituraDataGridView.Size = new System.Drawing.Size(652, 220);
            this.furnituraDataGridView.TabIndex = 15;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "namefur";
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dataGridViewTextBoxColumn2.DefaultCellStyle = dataGridViewCellStyle9;
            this.dataGridViewTextBoxColumn2.HeaderText = "Название ";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 180;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "countfur";
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dataGridViewTextBoxColumn3.DefaultCellStyle = dataGridViewCellStyle10;
            this.dataGridViewTextBoxColumn3.DividerWidth = 10;
            this.dataGridViewTextBoxColumn3.HeaderText = "Количество";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Сколько списать ";
            this.Column1.Name = "Column1";
            this.Column1.Width = 150;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Причина ";
            this.Column2.Name = "Column2";
            this.Column2.Width = 170;
            // 
            // TkaniBindingSource
            // 
            this.TkaniBindingSource.DataMember = "Tkani";
            this.TkaniBindingSource.DataSource = this.u37_15DataSet1;
            this.TkaniBindingSource.Filter = "Dlina > 0";
            // 
            // TkaniDataGridView
            // 
            this.TkaniDataGridView.AllowUserToAddRows = false;
            this.TkaniDataGridView.AllowUserToDeleteRows = false;
            this.TkaniDataGridView.AutoGenerateColumns = false;
            this.TkaniDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.TkaniDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.NazvanieTkan,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.Column3,
            this.Column4});
            this.TkaniDataGridView.DataSource = this.TkaniBindingSource;
            this.TkaniDataGridView.Location = new System.Drawing.Point(15, 431);
            this.TkaniDataGridView.Name = "TkaniDataGridView";
            this.TkaniDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.TkaniDataGridView.Size = new System.Drawing.Size(701, 163);
            this.TkaniDataGridView.TabIndex = 15;
            // 
            // NazvanieTkan
            // 
            this.NazvanieTkan.DataPropertyName = "NazvanieTkan";
            this.NazvanieTkan.HeaderText = "Название ткани";
            this.NazvanieTkan.Name = "NazvanieTkan";
            this.NazvanieTkan.ReadOnly = true;
            this.NazvanieTkan.Width = 130;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Dlina";
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dataGridViewTextBoxColumn6.DefaultCellStyle = dataGridViewCellStyle11;
            this.dataGridViewTextBoxColumn6.HeaderText = "Длина";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "Shirina";
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dataGridViewTextBoxColumn7.DefaultCellStyle = dataGridViewCellStyle12;
            this.dataGridViewTextBoxColumn7.DividerWidth = 10;
            this.dataGridViewTextBoxColumn7.HeaderText = "Ширина";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Сколько списать";
            this.Column3.Name = "Column3";
            this.Column3.Width = 150;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Причина";
            this.Column4.Name = "Column4";
            this.Column4.Width = 170;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 145);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 13);
            this.label2.TabIndex = 16;
            this.label2.Text = "Фурнитура";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 415);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 13);
            this.label3.TabIndex = 17;
            this.label3.Text = "Изделия";
            // 
            // btnSpisMaterial
            // 
            this.btnSpisMaterial.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(156)))), ((int)(((byte)(26)))));
            this.btnSpisMaterial.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnSpisMaterial.Location = new System.Drawing.Point(670, 248);
            this.btnSpisMaterial.Name = "btnSpisMaterial";
            this.btnSpisMaterial.Size = new System.Drawing.Size(154, 48);
            this.btnSpisMaterial.TabIndex = 24;
            this.btnSpisMaterial.Text = "Списать материалы\r\n";
            this.btnSpisMaterial.UseVisualStyleBackColor = false;
            this.btnSpisMaterial.Click += new System.EventHandler(this.btnSpisMaterial_Click);
            // 
            // btnSformirDock
            // 
            this.btnSformirDock.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(156)))), ((int)(((byte)(26)))));
            this.btnSformirDock.Location = new System.Drawing.Point(670, 161);
            this.btnSformirDock.Name = "btnSformirDock";
            this.btnSformirDock.Size = new System.Drawing.Size(154, 48);
            this.btnSformirDock.TabIndex = 25;
            this.btnSformirDock.Text = "Сформировать документ";
            this.btnSformirDock.UseVisualStyleBackColor = false;
            this.btnSformirDock.Click += new System.EventHandler(this.btnSformirDock_Click);
            // 
            // btnOtmena
            // 
            this.btnOtmena.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(156)))), ((int)(((byte)(26)))));
            this.btnOtmena.Location = new System.Drawing.Point(670, 333);
            this.btnOtmena.Name = "btnOtmena";
            this.btnOtmena.Size = new System.Drawing.Size(154, 48);
            this.btnOtmena.TabIndex = 26;
            this.btnOtmena.Text = "Отменить";
            this.btnOtmena.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(515, 388);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 27;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // FormSpisatMaterial
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(886, 606);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnOtmena);
            this.Controls.Add(this.btnSformirDock);
            this.Controls.Add(this.btnSpisMaterial);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.TkaniDataGridView);
            this.Controls.Add(this.furnituraDataGridView);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormSpisatMaterial";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "FormSpisatMaterial";
            this.Load += new System.EventHandler(this.FormSpisatMaterial_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.u37_15DataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.furnituraBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.furnituraDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TkaniBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TkaniDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private u37_15DataSet u37_15DataSet1;
        private System.Windows.Forms.BindingSource furnituraBindingSource;
        private u37_15DataSetTableAdapters.FurnituraTableAdapter furnituraTableAdapter;
        private u37_15DataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private u37_15DataSetTableAdapters.IzdeliyaTableAdapter izdeliyaTableAdapter;
        private System.Windows.Forms.DataGridView furnituraDataGridView;
        private System.Windows.Forms.BindingSource TkaniBindingSource;
        private System.Windows.Forms.DataGridView TkaniDataGridView;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnSpisMaterial;
        private System.Windows.Forms.Button btnSformirDock;
        private System.Windows.Forms.Button btnOtmena;
        private System.Windows.Forms.Button button1;
        private u37_15DataSetTableAdapters.TkaniTableAdapter tkaniTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn NazvanieTkan;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
    }
}