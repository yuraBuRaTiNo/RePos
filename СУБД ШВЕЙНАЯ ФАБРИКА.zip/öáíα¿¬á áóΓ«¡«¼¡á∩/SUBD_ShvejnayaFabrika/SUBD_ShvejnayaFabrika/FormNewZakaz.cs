﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SUBD_ShvejnayaFabrika
{
    public partial class FormNewZakaz : Form
    {
        public FormNewZakaz()
        {
            InitializeComponent();
        }

        public string idZakazchik = "";

        string idTkan = "", idFur = "";

        List<Tkani> lstTkani = new List<Tkani>();

        public struct Tkani
        {
            public string nazvanie, cvet, primech, id, shirina, dlina;

            public Image PhotoTkan;
        }

        List<Furnitura> lstFurnitura = new List<Furnitura>();

        public struct Furnitura
        {
            public string namefur, counfur, id;

            public Image PhotoFurnitura;
        }

        /// <summary>
        /// получить фурнитуру из БД
        /// </summary>
        void GetFurnFromDB()
        {
            SqlConnection con = new SqlConnection(Properties.Settings.Default.u37_15ConnectionString);

            con.Open();

            SqlCommand q1 = new SqlCommand("Select * from Furnitura where countfur > 0", con);

            SqlDataReader data = q1.ExecuteReader();

            while (data.Read())
            {
                Furnitura FR = new Furnitura();

                FR.id = data["idfur"].ToString();
                FR.namefur = data["namefur"].ToString();
                FR.counfur = data["countfur"].ToString();
                
                try
                {
                    byte[] PhoteByte = (byte[])data["photo"];

                    ImageConverter imc = new ImageConverter();

                    FR.PhotoFurnitura = (Bitmap)imc.ConvertFrom(PhoteByte);
                }
                catch
                {
                    FR.PhotoFurnitura = Properties.Resources.tmp;
                }
                lstFurnitura.Add(FR);
            }

            con.Close();
        }

        /// <summary>
        /// получить список тканей из БД
        /// </summary>
        void GetTkanFromDB()
        {
            SqlConnection con = new SqlConnection(Properties.Settings.Default.u37_15ConnectionString);

            con.Open();

            SqlCommand q1 = new SqlCommand("Select * from Tkani where Dlina > 0", con);

            SqlDataReader data = q1.ExecuteReader();

            while(data.Read())
            {
                Tkani TK = new Tkani();

                TK.id = data["idTkan"].ToString();
                TK.nazvanie = data["NazvanieTkan"].ToString();
                TK.shirina = data["Shirina"].ToString();
                TK.dlina = data["Dlina"].ToString();
                TK.cvet = data["ColorTkan"].ToString();
                TK.primech = data["Primechanie"].ToString();


                try
                {
                    byte[] PhoteByte = (byte[])data["Photo"];

                    ImageConverter imc = new ImageConverter();

                    TK.PhotoTkan = (Bitmap)imc.ConvertFrom(PhoteByte);
                }
                catch
                {
                    TK.PhotoTkan = Properties.Resources.tmp;
                }
                lstTkani.Add(TK);
            }

            con.Close();
        }

        /// <summary>
        /// заполнениее таблицы с тканями
        /// </summary>
        void fillLVTkani()
        {
            LvTkan.Items.Clear();
            imageList1.Images.Clear();
            foreach(Tkani tk in lstTkani)
            {
                ListViewItem lv = new ListViewItem(tk.nazvanie);
                imageList1.Images.Add(tk.PhotoTkan);

                lv.ImageIndex = imageList1.Images.Count - 1;

                LvTkan.Items.Add(lv);
            }
        }

        void fillLVFurnitura()
        {
            LVFurnitura.Items.Clear();
            imageListFur.Images.Clear();
            foreach(Furnitura FR in lstFurnitura)
            {
                 ListViewItem lv = new ListViewItem(FR.namefur);
                imageListFur.Images.Add(FR.PhotoFurnitura);

                lv.ImageIndex = imageListFur.Images.Count - 1;

                LVFurnitura.Items.Add(lv);
            }
        }

        /// <summary>
        /// Определение длины ткани, которую нужно отрезать от рулона
        /// для изготовления нужного кол-ва изделий заданного размера
        /// </summary>
        /// <param name="ShirinaTkan">ширина ткани</param>
        /// <param name="ShirinaIzd">ширина изделия</param>
        /// <param name="DlinaTkan">длина ткани</param>
        /// <param name="DlinaIzd">длина изделия</param>
        /// <returns></returns>
        int CutTkan(int ShirinaTkan, int ShirinaIzd, int DlinaIzd, int CountIzd)
        {
            //если укладывать изделия на ткань в рулоне по ширине изделия 
            //кол-во изделий, умещающихся в один ряд на рулоне ткани
            int IzdInRow1 = ShirinaTkan / ShirinaIzd;
            
            //кол-во рядов, в каждом из которых IzdInRow1 изделий
            int Row1 = CountIzd / IzdInRow1;

            //если кол-во изделий в 1 ряду умноженное на кол-во рядов меньше 
            //кол-ва всех изделий, добавить кол-во рядов 
            if (IzdInRow1 * Row1 < CountIzd)
                Row1++;

            //длина ткани, которую нужно отрезать от рулона, если укладывать по ширине
            int CutTkan1 = DlinaIzd * Row1;

            //если укладывать изделия на ткань в рулоне по длине изделия 
            //кол-во изделий, умещающихся в один ряд на рулоне ткани
            int IzdInRow2 = ShirinaTkan / DlinaIzd;

            //кол-во рядов, в каждом из которых IzdInRow1 изделий
            int Row2 = CountIzd / IzdInRow2;

            //если кол-во изделий в 1 ряду на кол-во рядов и полученное  
            //значение меньше кол-ва необходимых изделий, значит нужно использовать 
            //еще один ряд
            if (IzdInRow2 * Row2 < CountIzd)
                Row2++;

            int CutTkan2 = ShirinaIzd * Row2;

            //вернуть наименьшую длину
            return Math.Min(CutTkan1, CutTkan2);
        }

        private void FormNewZakaz_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'u37_15DataSet1.Polzovateli' table. You can move, or remove it, as needed.
            this.polzovateliTableAdapter.Fill(this.u37_15DataSet1.Polzovateli);
            // TODO: This line of code loads data into the 'u37_15DataSet1.Tkani' table. You can move, or remove it, as needed.
            this.tkaniTableAdapter.Fill(this.u37_15DataSet1.Tkani);
            // TODO: This line of code loads data into the 'u37_15DataSet1.Izdeliya' table. You can move, or remove it, as needed.
            this.izdeliyaTableAdapter.Fill(this.u37_15DataSet1.Izdeliya);

            GetTkanFromDB();
            fillLVTkani();

            GetFurnFromDB();
            fillLVFurnitura();

        }

        private void LvTkan_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(LvTkan.SelectedItems.Count > 0)//есть выделенные элементы
            {
                int num = LvTkan.SelectedIndices[0];//номер выделенного элемента

                nazvanieTkanTextBox.Text = lstTkani[num].nazvanie;

                colorTkanTextBox.Text = lstTkani[num].cvet;

                shirinaTextBox.Text = lstTkani[num].shirina;

                dlinaTextBox.Text = lstTkani[num].dlina;

                primechanieTextBox.Text = lstTkani[num].primech;

                idTkan = lstTkani[num].id;
            }
            else //нет выделенных элементов
            {
                nazvanieTkanTextBox.Text = "";

                colorTkanTextBox.Text = "";

                shirinaTextBox.Text = "";

                dlinaTextBox.Text = "";

                primechanieTextBox.Text = "";

                idTkan = "";
            }
        }

        private void LVFurnitura_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (LVFurnitura.SelectedItems.Count > 0)//есть выделенные элементы
            {
                int num = LVFurnitura.SelectedIndices[0];//номер выделенного элемента

                tbxNazvFurnitura.Text = lstFurnitura[num].namefur;

                tbxKolVoFurnitura.Text = lstFurnitura[num].counfur;

                idFur = lstFurnitura[num].id;
            }
            else //нет выделенных элементов
            {
                tbxKolVoFurnitura.Text = "";

                tbxNazvFurnitura.Text = "";

                idFur = "";
            }
        }

        private void tbxFurnForIzdelie_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(char.IsDigit(e.KeyChar))
            {
                return;
            }
            e.Handled = true;

            if(char.IsLetter(e.KeyChar))
            {
                return;
            }
            e.Handled = false;

          
        }

        private void tbxCountIzd_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar))
            {
                return;
            }
            e.Handled = true;

            if (char.IsLetter(e.KeyChar))
            {
                return;
            }
            e.Handled = false;

          

        }

        private void btnSformirZakaz_Click(object sender, EventArgs e)
        {
            //int a = CutTkan(430, 150, 200, 4);
            //this.Text = a.ToString();
            //return;

            //string h = @"!@#$%^&*()_-+=/:;><,.?''|\""";

            //for (int i = 0; i < h.Length - 1; i++)
            //{
            //    if (tbxCountIzd.Text == h[i].ToString())
            //    {
            //        return;
            //        //MessageBox.Show("Произошел ввод некоректных данных");

            //    }

            //    tbxCountIzd.Clear();

            //}


            //for (int i = 0; i < h.Length - 1; i++)
            //{
            //    if (tbxFurnForIzdelie.Text == h[i].ToString())
            //    {
            //        return;
            //        //MessageBox.Show("Произошел ввод некоректных данных");

            //    }
                
            //    tbxFurnForIzdelie.Clear();

            //}

            //if (tbxFurnForIzdelie.Text == " " && tbxCountIzd.Text == " ")
            //{
            //    MessageBox.Show("Произошел ввод некоректных данных");
            //    return;
            //}


            

          
                int NewCountFur = int.Parse(tbxKolVoFurnitura.Text) - int.Parse(tbxCountIzd.Text) * int.Parse(tbxFurnForIzdelie.Text);


                SqlConnection con2 = new SqlConnection(Properties.Settings.Default.u37_15ConnectionString);

                con2.Open();

                string t1 = string.Format(@"update Furnitura
                                                    set countfur = {0}
                                                                    where idfur = {1}
                                                                                        ", NewCountFur, idFur);

                SqlCommand q2 = new SqlCommand(t1, con2);
                q2.ExecuteNonQuery();
                con2.Close();
          
            //if(int.Parse(tbxFurnForIzdelie.Text) > NewCountFur)
            //{
            //    MessageBox.Show("на складе не хватает фурнитруры");
            //    return;
            //}


                //int NewCountTkan = int.Parse(dlinaTextBox.Text) + int.Parse(shirinaTextBox.Text);

                //SqlConnection con3 = new SqlConnection(Properties.Settings.Default.u37_15ConnectionString);

                //con3.Open();

                //string t2 = string.Format(@"update Tkani
                //                                              set CutTkan = {0}
                //                                                                where idTkan = {1} 
                //                                                                                   ", CutTkan(280, 70, 60, 4), idTkan);

                //SqlCommand q3 = new SqlCommand(t2, con3);
                //q3.ExecuteNonQuery();
                //con3.Close();
           
           


                int ShirinaTkan = int.Parse(shirinaTextBox.Text);

                int ShirinaIzd = int.Parse(dgvIzd.CurrentRow.Cells[2].Value.ToString());

                int DlinaIzd = int.Parse(dgvIzd.CurrentRow.Cells[1].Value.ToString());

                int CountIzd = int.Parse(tbxCountIzd.Text);

                int NewLenthTkan = int.Parse(dlinaTextBox.Text) - CutTkan(ShirinaTkan, ShirinaIzd, DlinaIzd, CountIzd);
            

          

            //обновить таблицу ткани (для выделенной ткани сохранить новую длину NewLenth)




            int IdManager = 3;

            try
            {
                SqlConnection con = new SqlConnection(Properties.Settings.Default.u37_15ConnectionString);

                con.Open();

                string t = string.Format(@"insert into Zakazy (idIzdeliya, idZakazchik, idManajer, idTkan, idFurnitura, KolichFurnitura, KolichIzdelij)
                                                    values ({0}, {1}, {2}, {3}, {4}, {5}, {6})", lblidIzd.Text, idZakazchik, IdManager, idTkan,
                                                                                            idFur, tbxCountIzd.Text, tbxFurnForIzdelie.Text);

                SqlCommand q1 = new SqlCommand(t, con);
                q1.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Заказ сформирован");
                this.Close();
            }
            catch
            {
                MessageBox.Show("ошибка при формировании заказа");
                return;
            }
            
        }
    }
}
