﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using ClassLibrary1;

namespace SUBD_ShvejnayaFabrika
{
    public partial class FormAutorization : Form
    {
        public FormAutorization()
        {
            InitializeComponent();
        }

        //public static string txtcon = @"Data Source=213.155.192.79, 3002;Initial Catalog=u37_15;Persist Security Info=True;User ID=u37_15;Password=ytr3";

        /// <summary>
        /// Генерация капчи из 4х символов
        /// </summary>
        /// <returns> возвращает сгенерированную капчу </returns>
        string GetCapcha()
        {
            string txtBukva = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            string txtChislo = "0123456789";
            string capcha = "";



            Random rnd = new Random();

            bool flagBukva = false;
            bool flagChislo = false;

            for(int i = 0; i < 3; i++)
            {
                char Gachi = (txtChislo + txtBukva)[rnd.Next(txtChislo.Length + txtBukva.Length)];

                capcha += Gachi;

                if (char.IsDigit(Gachi))
                    flagChislo = true;
                
            }

            if(flagChislo == false)
            {
                capcha += txtChislo[rnd.Next(txtChislo.Length)];
            }

            else
            {
                capcha += txtBukva[rnd.Next(txtBukva.Length)];
            }

            return capcha;
        }

        /// <summary>
        /// проверка логина, пароля, капчи
        /// </summary>
        private void btnVxod_Click(object sender, EventArgs e)
        {
            //if (tbxCapcha.Text != lblCapcha.Text)
            //{
            //    MessageBox.Show("Введенная капча не верна");
            //    lblCapcha.Text = GetCapcha();
            //    return;
            //}


            string txtFilterForUsers = string.Format("login = '{0}'", tbxLogin.Text);

            bsPolzovatel.Filter = "Login = '" + tbxLogin.Text + "' and Password = '" + tbxPassword.Text + "' and Role = '" + cmbAutorization.Text + "'";
            if(bsPolzovatel.Count == 0)
            {
                MessageBox.Show("Неверный логин или пароль");
                lblCapcha.Text = GetCapcha();
                return;
            }
            else
            {
                tbxLogin.Clear();
                tbxPassword.Clear();

                this.Visible = false;

                if (cmbAutorization.Text == "менеджер")
                {
                    FormManajer frmManajer = new FormManajer();

                    frmManajer.bsPolzovatel.Filter = txtFilterForUsers;

                    frmManajer.ShowDialog();
                }

                if (cmbAutorization.Text == "кладовщик")
                {
                    FormKladovshik frmKladovshik = new FormKladovshik();

                    frmKladovshik.bsPolzovatel.Filter = txtFilterForUsers;

                    frmKladovshik.ShowDialog();
                }

                if (cmbAutorization.Text == "заказчик")
                {
                    FormZakazchik frmZakazchik = new FormZakazchik();

                    frmZakazchik.bsPolzovatel.Filter = txtFilterForUsers;

                    frmZakazchik.ShowDialog();
                }

                this.Visible = true;
                this.polzovateliTableAdapter.Fill(this.u37_15DataSet1.Polzovateli);
                lblCapcha.Text = GetCapcha();
                tbxCapcha.Clear();

            }

        }

        /// <summary>
        /// скрыть показать пароль 
        /// </summary>
        private void cbxShowPass_CheckedChanged(object sender, EventArgs e)
        {
            tbxPassword.UseSystemPasswordChar = !cbxShowPass.Checked;
        }

        private void FormAutorization_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'u37_15DataSet1.Polzovateli' table. You can move, or remove it, as needed.
            this.polzovateliTableAdapter.Fill(this.u37_15DataSet1.Polzovateli);

            lblCapcha.Text = GetCapcha();
        }

        /// <summary>
        /// изображение случайных линий поверх капчи
        /// </summary>
        private void lblCapcha_Paint(object sender, PaintEventArgs e)
        {
            Random rndLine = new Random();

            int Red = rndLine.Next(0, 255);

            int Orange = rndLine.Next(0, 255);

            int Blue = rndLine.Next(0, 255);

            for(int i = 0; i <= rndLine.Next(20, 20); i++)
            {
                e.Graphics.DrawLine(new Pen(Color.FromArgb(Red, Orange, Blue)), rndLine.Next(lblCapcha.Left), rndLine.Next(lblCapcha.Height), rndLine.Next(lblCapcha.Right),
                    rndLine.Next(lblCapcha.Height));
            }

        }

        private void lblNewReg_Click(object sender, EventArgs e)
        {
            
            FormRegistryZakazchka FrmRegZak = new FormRegistryZakazchka();

            if(FrmRegZak.ShowDialog() == DialogResult.OK)

                this.polzovateliTableAdapter.Fill(this.u37_15DataSet1.Polzovateli);



        }
    }
}
