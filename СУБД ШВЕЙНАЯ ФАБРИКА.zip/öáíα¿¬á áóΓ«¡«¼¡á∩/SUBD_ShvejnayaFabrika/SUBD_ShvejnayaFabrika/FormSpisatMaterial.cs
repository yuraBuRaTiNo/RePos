﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Excel = Microsoft.Office.Interop.Excel;

namespace SUBD_ShvejnayaFabrika
{
    public partial class FormSpisatMaterial : Form
    {
        public FormSpisatMaterial()
        {
            InitializeComponent();
        }

        private void FormSpisatMaterial_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'u37_15DataSet1.Tkani' table. You can move, or remove it, as needed.
            this.tkaniTableAdapter.Fill(this.u37_15DataSet1.Tkani);
            // TODO: This line of code loads data into the 'u37_15DataSet1.Izdeliya' table. You can move, or remove it, as needed.
            this.izdeliyaTableAdapter.Fill(this.u37_15DataSet1.Izdeliya);
            // TODO: This line of code loads data into the 'u37_15DataSet1.Furnitura' table. You can move, or remove it, as needed.
            this.furnituraTableAdapter.Fill(this.u37_15DataSet1.Furnitura);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Excel.Application exc = new Excel.Application();
            exc.Visible = true;

            //открыть только для чтения
            exc.Workbooks.Open(Application.StartupPath + "\\Tkani.xlsx", null , true);

            //переменная для связи с 1 листом рабочей книги
            Excel.Worksheet list1 = exc.Worksheets.get_Item(1);

            for(int i = 0; i <= TkaniDataGridView.RowCount-1; i++)
            {
                list1.get_Range("A" + (i+3)).Value = 
                    TkaniDataGridView.Rows[i].Cells[0].Value;

                list1.get_Range("B" + (i + 3)).Value =
                    TkaniDataGridView.Rows[i].Cells[1].Value;

                list1.get_Range("C" + (i + 3)).Value =
                    TkaniDataGridView.Rows[i].Cells[2].Value;
            }


        }

        private void btnSformirDock_Click(object sender, EventArgs e)
        {
            Excel.Application exc = new Excel.Application();
            exc.Visible = true;

            //открыть только для чтения
            exc.Workbooks.Open(Application.StartupPath + "\\Списание.xlsx", null, true);

            //переменная для связи с 1 листом рабочей книги
            Excel.Worksheet list1 = exc.Worksheets.get_Item(1);

            int RowExel = 24;

            int DataRow = 10;

            string s = DateTime.Now.ToString("dd.mm.yyyy");

          

            for (int i = 0; i <= TkaniDataGridView.RowCount - 1; i++)
            {

                int countspis = 0;

                try
                {
                    countspis = Convert.ToInt32(TkaniDataGridView.Rows[i].Cells[3].Value);
                }
                catch { }

                if (countspis == 0)
                    continue;
                
                if(TkaniDataGridView.Rows[i].Cells[3].Value != null)
                {
                    list1.get_Range("A" + (RowExel )).Value =
                   TkaniDataGridView.Rows[i].Cells[0].Value;

                    list1.get_Range("H" + (RowExel )).Value = "см";

                    list1.get_Range("J" + (RowExel )).Value = "Ткань";

                    list1.get_Range("L" + (RowExel )).Value = TkaniDataGridView.Rows[i].Cells[1].Value;

                    list1.get_Range("N" + (RowExel )).Value = int.Parse(TkaniDataGridView.Rows[i].Cells[2].Value.ToString()) * int.Parse(TkaniDataGridView.Rows[i].Cells[1].Value.ToString());

                    list1.get_Range("R" + (RowExel)).Value = TkaniDataGridView.Rows[i].Cells[4].Value;

                    list1.get_Range("A" + (DataRow)).Value = s;

                    RowExel++;
                }    
            }

            for (int i = 0; i <= furnituraDataGridView.RowCount - 1; i++)
            {
                int countspis = 0;

                try
                {
                    countspis = Convert.ToInt32(furnituraDataGridView.Rows[i].Cells[2].Value);
                }
                catch { }

                if (countspis == 0)
                    continue;

                list1.get_Range("A" + (RowExel)).Value =
             furnituraDataGridView.Rows[i].Cells[0].Value;

                list1.get_Range("H" + (RowExel)).Value = "шт";

                list1.get_Range("J" + (RowExel)).Value = "Фурнитура";

                list1.get_Range("L" + (RowExel)).Value = furnituraDataGridView.Rows[i].Cells[1].Value;

                list1.get_Range("R" + (RowExel )).Value = furnituraDataGridView.Rows[i].Cells[3].Value;

                list1.get_Range("A" + (DataRow)).Value = s;

                RowExel++;
            }
        }

        private void btnSpisMaterial_Click(object sender, EventArgs e)
        {

            DialogResult res =  MessageBox.Show("Списать материалы?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (res == DialogResult.Yes)
            {
                for (int i = 0; i <= TkaniDataGridView.RowCount - 1; i++)
                {

                    int countspis = 0;

                    try
                    {
                        countspis = Convert.ToInt32(TkaniDataGridView.Rows[i].Cells[3].Value);
                    }
                    catch { }

                    if (countspis == 0)
                        continue;

                    else
                    {
                        TkaniDataGridView.Rows[i].Cells[1].Value = int.Parse(TkaniDataGridView.Rows[i].Cells[1].Value.ToString()) -
                            int.Parse(TkaniDataGridView.Rows[i].Cells[3].Value.ToString());

                    }

                   
                }

                for (int i = 0; i <= furnituraDataGridView.RowCount - 1; i++)
                {

                    int countspis = 0;

                    try
                    {
                        countspis = Convert.ToInt32(furnituraDataGridView.Rows[i].Cells[2].Value);
                    }
                    catch { }

                    if (countspis == 0)
                        continue;

                    else
                    {
                        furnituraDataGridView.Rows[i].Cells[1].Value = int.Parse(furnituraDataGridView.Rows[i].Cells[1].Value.ToString()) -
                            int.Parse(furnituraDataGridView.Rows[i].Cells[2].Value.ToString());

                    }

                        //if (int.Parse(furnituraDataGridView.Rows[i].Cells[2].Value.ToString()) > int.Parse(furnituraDataGridView.Rows[i].Cells[1].Value.ToString()))
                        //{
                        //    MessageBox.Show("на складе не хватает фурнитруры");

                        //    return;
                        //}

                }

                TkaniBindingSource.EndEdit();
                this.tkaniTableAdapter.Update(this.u37_15DataSet1.Tkani);
                furnituraBindingSource.EndEdit();
                this.furnituraTableAdapter.Update(this.u37_15DataSet1.Furnitura);

            }
     
        }
    }
}
