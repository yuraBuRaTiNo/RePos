﻿namespace SUBD_ShvejnayaFabrika
{
    partial class FormRegistryZakazchka
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label loginLabel;
            System.Windows.Forms.Label passwordLabel;
            System.Windows.Forms.Label famLabel;
            System.Windows.Forms.Label nameLabel;
            System.Windows.Forms.Label otchLabel;
            System.Windows.Forms.Label phoneLabel;
            System.Windows.Forms.Label label2;
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Btn_Reg = new System.Windows.Forms.Button();
            this.btn_Cansel = new System.Windows.Forms.Button();
            this.u37_15DataSet1 = new SUBD_ShvejnayaFabrika.u37_15DataSet();
            this.bsPolzovatel = new System.Windows.Forms.BindingSource(this.components);
            this.polzovateliTableAdapter = new SUBD_ShvejnayaFabrika.u37_15DataSetTableAdapters.PolzovateliTableAdapter();
            this.tableAdapterManager = new SUBD_ShvejnayaFabrika.u37_15DataSetTableAdapters.TableAdapterManager();
            this.LoginTextBox = new System.Windows.Forms.TextBox();
            this.PasswordTextBox = new System.Windows.Forms.TextBox();
            this.FamTextBox = new System.Windows.Forms.TextBox();
            this.NameTextBox = new System.Windows.Forms.TextBox();
            this.OtchTextBox = new System.Windows.Forms.TextBox();
            this.tbxPhone = new System.Windows.Forms.MaskedTextBox();
            this.tbxProverkaPass = new System.Windows.Forms.TextBox();
            this.lblRole = new System.Windows.Forms.Label();
            this.cbxShowPass = new System.Windows.Forms.CheckBox();
            loginLabel = new System.Windows.Forms.Label();
            passwordLabel = new System.Windows.Forms.Label();
            famLabel = new System.Windows.Forms.Label();
            nameLabel = new System.Windows.Forms.Label();
            otchLabel = new System.Windows.Forms.Label();
            phoneLabel = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.u37_15DataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsPolzovatel)).BeginInit();
            this.SuspendLayout();
            // 
            // loginLabel
            // 
            loginLabel.AutoSize = true;
            loginLabel.Location = new System.Drawing.Point(12, 162);
            loginLabel.Name = "loginLabel";
            loginLabel.Size = new System.Drawing.Size(41, 13);
            loginLabel.TabIndex = 3;
            loginLabel.Text = "Логин:";
            // 
            // passwordLabel
            // 
            passwordLabel.AutoSize = true;
            passwordLabel.Location = new System.Drawing.Point(12, 204);
            passwordLabel.Name = "passwordLabel";
            passwordLabel.Size = new System.Drawing.Size(48, 13);
            passwordLabel.TabIndex = 5;
            passwordLabel.Text = "Пароль:";
            // 
            // famLabel
            // 
            famLabel.AutoSize = true;
            famLabel.Location = new System.Drawing.Point(12, 298);
            famLabel.Name = "famLabel";
            famLabel.Size = new System.Drawing.Size(59, 13);
            famLabel.TabIndex = 7;
            famLabel.Text = "Фамилия:";
            // 
            // nameLabel
            // 
            nameLabel.AutoSize = true;
            nameLabel.Location = new System.Drawing.Point(12, 331);
            nameLabel.Name = "nameLabel";
            nameLabel.Size = new System.Drawing.Size(32, 13);
            nameLabel.TabIndex = 9;
            nameLabel.Text = "Имя:";
            // 
            // otchLabel
            // 
            otchLabel.AutoSize = true;
            otchLabel.Location = new System.Drawing.Point(12, 376);
            otchLabel.Name = "otchLabel";
            otchLabel.Size = new System.Drawing.Size(57, 13);
            otchLabel.TabIndex = 11;
            otchLabel.Text = "Отчество:";
            // 
            // phoneLabel
            // 
            phoneLabel.AutoSize = true;
            phoneLabel.Location = new System.Drawing.Point(12, 411);
            phoneLabel.Name = "phoneLabel";
            phoneLabel.Size = new System.Drawing.Size(55, 13);
            phoneLabel.TabIndex = 13;
            phoneLabel.Text = "Телефон:";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(797, 128);
            this.panel1.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(221, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(371, 37);
            this.label1.TabIndex = 1;
            this.label1.Text = "Регистрация заказчика";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Left;
            this.pictureBox1.Image = global::SUBD_ShvejnayaFabrika.Properties.Resources.fabric_logo;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(167, 128);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // Btn_Reg
            // 
            this.Btn_Reg.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(26)))));
            this.Btn_Reg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Btn_Reg.Location = new System.Drawing.Point(629, 340);
            this.Btn_Reg.Name = "Btn_Reg";
            this.Btn_Reg.Size = new System.Drawing.Size(149, 46);
            this.Btn_Reg.TabIndex = 2;
            this.Btn_Reg.Text = "Зарегистрировать";
            this.Btn_Reg.UseVisualStyleBackColor = false;
            this.Btn_Reg.Click += new System.EventHandler(this.Btn_Reg_Click);
            // 
            // btn_Cansel
            // 
            this.btn_Cansel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(26)))));
            this.btn_Cansel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btn_Cansel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_Cansel.Location = new System.Drawing.Point(629, 392);
            this.btn_Cansel.Name = "btn_Cansel";
            this.btn_Cansel.Size = new System.Drawing.Size(149, 46);
            this.btn_Cansel.TabIndex = 3;
            this.btn_Cansel.Text = "Отмена";
            this.btn_Cansel.UseVisualStyleBackColor = false;
            this.btn_Cansel.Click += new System.EventHandler(this.btn_Cansel_Click);
            // 
            // u37_15DataSet1
            // 
            this.u37_15DataSet1.DataSetName = "u37_15DataSet";
            this.u37_15DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bsPolzovatel
            // 
            this.bsPolzovatel.DataMember = "Polzovateli";
            this.bsPolzovatel.DataSource = this.u37_15DataSet1;
            // 
            // polzovateliTableAdapter
            // 
            this.polzovateliTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.FurnituraTableAdapter = null;
            this.tableAdapterManager.IzdeliyaTableAdapter = null;
            this.tableAdapterManager.PolzovateliTableAdapter = this.polzovateliTableAdapter;
            this.tableAdapterManager.TkaniTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = SUBD_ShvejnayaFabrika.u37_15DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.ZakazyTableAdapter = null;
            // 
            // LoginTextBox
            // 
            this.LoginTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsPolzovatel, "Login", true));
            this.LoginTextBox.Location = new System.Drawing.Point(67, 159);
            this.LoginTextBox.Name = "LoginTextBox";
            this.LoginTextBox.Size = new System.Drawing.Size(183, 20);
            this.LoginTextBox.TabIndex = 4;
            // 
            // PasswordTextBox
            // 
            this.PasswordTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsPolzovatel, "Password", true));
            this.PasswordTextBox.Location = new System.Drawing.Point(67, 201);
            this.PasswordTextBox.Name = "PasswordTextBox";
            this.PasswordTextBox.Size = new System.Drawing.Size(183, 20);
            this.PasswordTextBox.TabIndex = 6;
            this.PasswordTextBox.UseSystemPasswordChar = true;
            // 
            // FamTextBox
            // 
            this.FamTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsPolzovatel, "Fam", true));
            this.FamTextBox.Location = new System.Drawing.Point(77, 295);
            this.FamTextBox.Name = "FamTextBox";
            this.FamTextBox.Size = new System.Drawing.Size(173, 20);
            this.FamTextBox.TabIndex = 8;
            // 
            // NameTextBox
            // 
            this.NameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsPolzovatel, "Name", true));
            this.NameTextBox.Location = new System.Drawing.Point(67, 331);
            this.NameTextBox.Name = "NameTextBox";
            this.NameTextBox.Size = new System.Drawing.Size(183, 20);
            this.NameTextBox.TabIndex = 10;
            // 
            // OtchTextBox
            // 
            this.OtchTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsPolzovatel, "Otch", true));
            this.OtchTextBox.Location = new System.Drawing.Point(75, 373);
            this.OtchTextBox.Name = "OtchTextBox";
            this.OtchTextBox.Size = new System.Drawing.Size(175, 20);
            this.OtchTextBox.TabIndex = 12;
            // 
            // tbxPhone
            // 
            this.tbxPhone.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsPolzovatel, "Phone", true));
            this.tbxPhone.Location = new System.Drawing.Point(75, 408);
            this.tbxPhone.Mask = "+0(000) 000-00-00";
            this.tbxPhone.Name = "tbxPhone";
            this.tbxPhone.Size = new System.Drawing.Size(175, 20);
            this.tbxPhone.TabIndex = 15;
            // 
            // tbxProverkaPass
            // 
            this.tbxProverkaPass.Location = new System.Drawing.Point(115, 228);
            this.tbxProverkaPass.Name = "tbxProverkaPass";
            this.tbxProverkaPass.Size = new System.Drawing.Size(135, 20);
            this.tbxProverkaPass.TabIndex = 16;
            this.tbxProverkaPass.UseSystemPasswordChar = true;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(12, 231);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(99, 13);
            label2.TabIndex = 17;
            label2.Text = "Проверка пароля:";
            // 
            // lblRole
            // 
            this.lblRole.AutoSize = true;
            this.lblRole.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsPolzovatel, "Role", true));
            this.lblRole.Location = new System.Drawing.Point(912, 208);
            this.lblRole.Name = "lblRole";
            this.lblRole.Size = new System.Drawing.Size(35, 13);
            this.lblRole.TabIndex = 18;
            this.lblRole.Text = "label3";
            this.lblRole.Click += new System.EventHandler(this.lblRole_Click);
            // 
            // cbxShowPass
            // 
            this.cbxShowPass.AutoSize = true;
            this.cbxShowPass.Location = new System.Drawing.Point(115, 254);
            this.cbxShowPass.Name = "cbxShowPass";
            this.cbxShowPass.Size = new System.Drawing.Size(114, 17);
            this.cbxShowPass.TabIndex = 19;
            this.cbxShowPass.Text = "Показать пароль";
            this.cbxShowPass.UseVisualStyleBackColor = true;
            this.cbxShowPass.CheckedChanged += new System.EventHandler(this.cbxShowPass_CheckedChanged);
            // 
            // FormRegistryZakazchka
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(797, 450);
            this.Controls.Add(this.cbxShowPass);
            this.Controls.Add(this.lblRole);
            this.Controls.Add(label2);
            this.Controls.Add(this.tbxProverkaPass);
            this.Controls.Add(this.tbxPhone);
            this.Controls.Add(phoneLabel);
            this.Controls.Add(otchLabel);
            this.Controls.Add(this.OtchTextBox);
            this.Controls.Add(nameLabel);
            this.Controls.Add(this.NameTextBox);
            this.Controls.Add(famLabel);
            this.Controls.Add(this.FamTextBox);
            this.Controls.Add(passwordLabel);
            this.Controls.Add(this.PasswordTextBox);
            this.Controls.Add(loginLabel);
            this.Controls.Add(this.LoginTextBox);
            this.Controls.Add(this.btn_Cansel);
            this.Controls.Add(this.Btn_Reg);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormRegistryZakazchka";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SUBD_ShvejnayaFabrika";
            this.Load += new System.EventHandler(this.FormRegistryZakazchka_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.u37_15DataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsPolzovatel)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button Btn_Reg;
        private System.Windows.Forms.Button btn_Cansel;
        private u37_15DataSet u37_15DataSet1;
        private System.Windows.Forms.BindingSource bsPolzovatel;
        private u37_15DataSetTableAdapters.PolzovateliTableAdapter polzovateliTableAdapter;
        private u37_15DataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.TextBox LoginTextBox;
        private System.Windows.Forms.TextBox PasswordTextBox;
        private System.Windows.Forms.TextBox FamTextBox;
        private System.Windows.Forms.TextBox NameTextBox;
        private System.Windows.Forms.TextBox OtchTextBox;
        private System.Windows.Forms.MaskedTextBox tbxPhone;
        private System.Windows.Forms.TextBox tbxProverkaPass;
        private System.Windows.Forms.Label lblRole;
        private System.Windows.Forms.CheckBox cbxShowPass;
    }
}