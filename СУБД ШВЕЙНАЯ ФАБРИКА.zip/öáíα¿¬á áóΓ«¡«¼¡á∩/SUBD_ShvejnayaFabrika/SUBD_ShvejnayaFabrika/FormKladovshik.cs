﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SUBD_ShvejnayaFabrika
{
    public partial class FormKladovshik : Form
    {
        public FormKladovshik()
        {
            InitializeComponent();
        }

        string idTkan = "", idFur = "";

        List<Tkani> lstTkani = new List<Tkani>();

        public struct Tkani
        {
            public string nazvanie, cvet, primech, id, shirina, dlina;

            public Image PhotoTkan;
        }

        List<Furnitura> lstFurnitura = new List<Furnitura>();

        public struct Furnitura
        {
            public string namefur, counfur, id;

            public Image PhotoFurnitura;
        }

        void FillListZakaz()
        {
            SqlConnection con = new SqlConnection(Properties.Settings.Default.u37_15ConnectionString);

            con.Open();

            SqlCommand q1 = new SqlCommand(string.Format(@"SELECT        Izdeliya.NazvanieIzdeliya as izd,
				Zakazy.KolichIzdelij as countizd,
				Tkani.NazvanieTkan as nazvtkan,
				Furnitura.namefur as nazvfur,
				Zakazy.KolichFurnitura as countfur,
				manajer.Fam as manajer,
				zakazchik.Fam as zakazchik
				
FROM   Zakazy, Polzovateli as manajer, Polzovateli as zakazchik,
			Tkani, Furnitura, Izdeliya         						 

where 
		manajer.idPolzovatel = Zakazy.idManajer
		and zakazchik.idPolzovatel = Zakazy.idZakazchik
		and Tkani.idTkan = Zakazy.idTkan
		and Furnitura.idfur = Zakazy.idFurnitura
		and Izdeliya.idIzdeliya = Zakazy.idIzdeliya", lblIDUser.Text), con);

            SqlDataReader res = q1.ExecuteReader();

            while (res.Read())
            {
                dgvZakazy.Rows.Add(res["izd"], res["countizd"], res["nazvtkan"],
                    res["nazvfur"], res["countfur"], res["manajer"], res["zakazchik"]);
            }

            con.Close();
        }

        void GetFurnFromDB()
        {
            SqlConnection con = new SqlConnection(Properties.Settings.Default.u37_15ConnectionString);

            con.Open();

            SqlCommand q1 = new SqlCommand("Select * from Furnitura where countfur > 0", con);

            SqlDataReader data = q1.ExecuteReader();

            while (data.Read())
            {
                Furnitura FR = new Furnitura();

                FR.id = data["idfur"].ToString();
                FR.namefur = data["namefur"].ToString();
                FR.counfur = data["countfur"].ToString();

                try
                {
                    byte[] PhoteByte = (byte[])data["photo"];

                    ImageConverter imc = new ImageConverter();

                    FR.PhotoFurnitura = (Bitmap)imc.ConvertFrom(PhoteByte);
                }
                catch
                {
                    FR.PhotoFurnitura = Properties.Resources.tmp;
                }
                lstFurnitura.Add(FR);
            }

            con.Close();
        }

        void GetTkanFromDB()
        {
            SqlConnection con = new SqlConnection(Properties.Settings.Default.u37_15ConnectionString);

            con.Open();

            SqlCommand q1 = new SqlCommand("Select * from Tkani where dlina > 0", con);

            SqlDataReader data = q1.ExecuteReader();

            while (data.Read())
            {
                Tkani TK = new Tkani();

                TK.id = data["idTkan"].ToString();
                TK.nazvanie = data["NazvanieTkan"].ToString();
                TK.shirina = data["Shirina"].ToString();
                TK.dlina = data["Dlina"].ToString();
                TK.cvet = data["ColorTkan"].ToString();
                TK.primech = data["Primechanie"].ToString();


                try
                {
                    byte[] PhoteByte = (byte[])data["Photo"];

                    ImageConverter imc = new ImageConverter();

                    TK.PhotoTkan = (Bitmap)imc.ConvertFrom(PhoteByte);
                }
                catch
                {
                    TK.PhotoTkan = Properties.Resources.tmp;
                }
                lstTkani.Add(TK);
            }

            con.Close();
        }

        void fillLVTkani()
        {
            LVTkan.Items.Clear();
            imageList1.Images.Clear();
            foreach (Tkani tk in lstTkani)
            {
                ListViewItem lv = new ListViewItem(tk.nazvanie);
                imageList1.Images.Add(tk.PhotoTkan);

                lv.ImageIndex = imageList1.Images.Count - 1;

                LVTkan.Items.Add(lv);
            }
        }

        void fillLVFurnitura()
        {
            LVFurnitura.Items.Clear();
            imageListFur.Images.Clear();
            foreach (Furnitura FR in lstFurnitura)
            {
                ListViewItem lv = new ListViewItem(FR.namefur);
                imageListFur.Images.Add(FR.PhotoFurnitura);

                lv.ImageIndex = imageListFur.Images.Count - 1;

                LVFurnitura.Items.Add(lv);
            }
        }

        private void FormKladovshik_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'u37_15DataSet1.Tkani' table. You can move, or remove it, as needed.
            this.tkaniTableAdapter.Fill(this.u37_15DataSet1.Tkani);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "u37_15DataSet1.Polzovateli". При необходимости она может быть перемещена или удалена.
            this.polzovateliTableAdapter.Fill(this.u37_15DataSet1.Polzovateli);

            FillListZakaz();

            GetTkanFromDB();
            fillLVTkani();

            GetFurnFromDB();
            fillLVFurnitura();
        }

        private void btnProfilPolzovatel_Click(object sender, EventArgs e)
        {
            FormProfile frmprof = new FormProfile();
            frmprof.bsPolzovatel.Filter = this.bsPolzovatel.Filter;
            if (frmprof.ShowDialog() == DialogResult.OK)
            {
                this.polzovateliTableAdapter.Fill(this.u37_15DataSet1.Polzovateli);
            }
        }

        private void btnPrintatMaterial_Click(object sender, EventArgs e)
        {
            FormGetMaterial frm = new FormGetMaterial();

            if (frm.ShowDialog() == DialogResult.OK)
            {
                GetTkanFromDB();
                GetFurnFromDB();

                fillLVFurnitura();
                fillLVTkani();
            }
        }

        private void btnSpisMaterial_Click(object sender, EventArgs e)
        {
            FormSpisatMaterial frm = new FormSpisatMaterial();

            if(frm.ShowDialog() == DialogResult.OK)
            {
                GetTkanFromDB();
                GetFurnFromDB();

                fillLVFurnitura();
                fillLVTkani();
            }
            
        }

        private void LVFurnitura_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (LVFurnitura.SelectedItems.Count > 0)//есть выделенные элементы
            {
                int num = LVFurnitura.SelectedIndices[0];//номер выделенного элемента

                tbxNazvFurnitura.Text = lstFurnitura[num].namefur;

                tbxKolVoFurnitura.Text = lstFurnitura[num].counfur;

                idFur = lstFurnitura[num].id;
            }
            else //нет выделенных элементов
            {
                tbxKolVoFurnitura.Text = "";

                tbxNazvFurnitura.Text = "";

                idFur = "";
            }
        }

        private void LVTkan_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (LVTkan.SelectedItems.Count > 0)//есть выделенные элементы
            {
                int num = LVTkan.SelectedIndices[0];//номер выделенного элемента

                nazvanieTkanTextBox.Text = lstTkani[num].nazvanie;

                colorTkanTextBox.Text = lstTkani[num].cvet;

                shirinaTextBox.Text = lstTkani[num].shirina;

                dlinaTextBox.Text = lstTkani[num].dlina;

                primechanieTextBox.Text = lstTkani[num].primech;

                idTkan = lstTkani[num].id;
            }
            else //нет выделенных элементов
            {
                nazvanieTkanTextBox.Text = "";

                colorTkanTextBox.Text = "";

                shirinaTextBox.Text = "";

                dlinaTextBox.Text = "";

                primechanieTextBox.Text = "";

                idTkan = "";
            }
        }
    }
}
