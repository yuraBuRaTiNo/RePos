﻿namespace SUBD_ShvejnayaFabrika
{
    partial class FormAutorization
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormAutorization));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tbxLogin = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbxPassword = new System.Windows.Forms.TextBox();
            this.cmbAutorization = new System.Windows.Forms.ComboBox();
            this.cbxShowPass = new System.Windows.Forms.CheckBox();
            this.btnVxod = new System.Windows.Forms.Button();
            this.lblNewReg = new System.Windows.Forms.Label();
            this.bsPolzovatel = new System.Windows.Forms.BindingSource(this.components);
            this.u37_15DataSet1 = new SUBD_ShvejnayaFabrika.u37_15DataSet();
            this.polzovateliTableAdapter = new SUBD_ShvejnayaFabrika.u37_15DataSetTableAdapters.PolzovateliTableAdapter();
            this.lblCapcha = new System.Windows.Forms.Label();
            this.tbxCapcha = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsPolzovatel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.u37_15DataSet1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(409, 128);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(191, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(211, 37);
            this.label1.TabIndex = 1;
            this.label1.Text = "Авторизация";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Left;
            this.pictureBox1.Image = global::SUBD_ShvejnayaFabrika.Properties.Resources.fabric_logo;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(167, 128);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(89, 166);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(152, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Выберите, кто авторизуется";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(89, 229);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Логин";
            // 
            // tbxLogin
            // 
            this.tbxLogin.Location = new System.Drawing.Point(89, 248);
            this.tbxLogin.Name = "tbxLogin";
            this.tbxLogin.Size = new System.Drawing.Size(277, 20);
            this.tbxLogin.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(89, 287);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Пароль";
            // 
            // tbxPassword
            // 
            this.tbxPassword.Location = new System.Drawing.Point(89, 306);
            this.tbxPassword.Name = "tbxPassword";
            this.tbxPassword.Size = new System.Drawing.Size(277, 20);
            this.tbxPassword.TabIndex = 5;
            this.tbxPassword.UseSystemPasswordChar = true;
            // 
            // cmbAutorization
            // 
            this.cmbAutorization.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAutorization.FormattingEnabled = true;
            this.cmbAutorization.Items.AddRange(new object[] {
            "кладовщик",
            "заказчик",
            "менеджер"});
            this.cmbAutorization.Location = new System.Drawing.Point(89, 182);
            this.cmbAutorization.Name = "cmbAutorization";
            this.cmbAutorization.Size = new System.Drawing.Size(277, 21);
            this.cmbAutorization.TabIndex = 7;
            // 
            // cbxShowPass
            // 
            this.cbxShowPass.AutoSize = true;
            this.cbxShowPass.Location = new System.Drawing.Point(89, 332);
            this.cbxShowPass.Name = "cbxShowPass";
            this.cbxShowPass.Size = new System.Drawing.Size(114, 17);
            this.cbxShowPass.TabIndex = 8;
            this.cbxShowPass.Text = "Показать пароль";
            this.cbxShowPass.UseVisualStyleBackColor = true;
            this.cbxShowPass.CheckedChanged += new System.EventHandler(this.cbxShowPass_CheckedChanged);
            // 
            // btnVxod
            // 
            this.btnVxod.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(156)))), ((int)(((byte)(26)))));
            this.btnVxod.Location = new System.Drawing.Point(128, 425);
            this.btnVxod.Name = "btnVxod";
            this.btnVxod.Size = new System.Drawing.Size(135, 48);
            this.btnVxod.TabIndex = 9;
            this.btnVxod.Text = "Вход";
            this.btnVxod.UseVisualStyleBackColor = false;
            this.btnVxod.Click += new System.EventHandler(this.btnVxod_Click);
            // 
            // lblNewReg
            // 
            this.lblNewReg.AutoSize = true;
            this.lblNewReg.BackColor = System.Drawing.Color.White;
            this.lblNewReg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblNewReg.ForeColor = System.Drawing.Color.Blue;
            this.lblNewReg.Location = new System.Drawing.Point(86, 481);
            this.lblNewReg.Name = "lblNewReg";
            this.lblNewReg.Size = new System.Drawing.Size(214, 16);
            this.lblNewReg.TabIndex = 10;
            this.lblNewReg.Text = "Регитсрация нового заказчика";
            this.lblNewReg.Click += new System.EventHandler(this.lblNewReg_Click);
            // 
            // bsPolzovatel
            // 
            this.bsPolzovatel.DataMember = "Polzovateli";
            this.bsPolzovatel.DataSource = this.u37_15DataSet1;
            // 
            // u37_15DataSet1
            // 
            this.u37_15DataSet1.DataSetName = "u37_15DataSet";
            this.u37_15DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // polzovateliTableAdapter
            // 
            this.polzovateliTableAdapter.ClearBeforeFill = true;
            // 
            // lblCapcha
            // 
            this.lblCapcha.AutoSize = true;
            this.lblCapcha.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(225)))));
            this.lblCapcha.Font = new System.Drawing.Font("Ravie", 27.75F, ((System.Drawing.FontStyle)((((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline) 
                | System.Drawing.FontStyle.Strikeout))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCapcha.Location = new System.Drawing.Point(80, 358);
            this.lblCapcha.Name = "lblCapcha";
            this.lblCapcha.Size = new System.Drawing.Size(175, 50);
            this.lblCapcha.TabIndex = 11;
            this.lblCapcha.Text = "label5";
            this.lblCapcha.Paint += new System.Windows.Forms.PaintEventHandler(this.lblCapcha_Paint);
            // 
            // tbxCapcha
            // 
            this.tbxCapcha.Location = new System.Drawing.Point(265, 377);
            this.tbxCapcha.Name = "tbxCapcha";
            this.tbxCapcha.Size = new System.Drawing.Size(100, 20);
            this.tbxCapcha.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(265, 358);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(83, 13);
            this.label6.TabIndex = 13;
            this.label6.Text = "Введите капчу:";
            // 
            // FormAutorization
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(409, 511);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.tbxCapcha);
            this.Controls.Add(this.lblCapcha);
            this.Controls.Add(this.lblNewReg);
            this.Controls.Add(this.btnVxod);
            this.Controls.Add(this.cbxShowPass);
            this.Controls.Add(this.cmbAutorization);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tbxPassword);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbxLogin);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormAutorization";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SUBD_ShvejnayaFabrika";
            this.Load += new System.EventHandler(this.FormAutorization_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsPolzovatel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.u37_15DataSet1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbxLogin;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbxPassword;
        private System.Windows.Forms.ComboBox cmbAutorization;
        private System.Windows.Forms.CheckBox cbxShowPass;
        private System.Windows.Forms.Button btnVxod;
        private System.Windows.Forms.Label lblNewReg;
        private u37_15DataSet u37_15DataSet1;
        private System.Windows.Forms.BindingSource bsPolzovatel;
        private u37_15DataSetTableAdapters.PolzovateliTableAdapter polzovateliTableAdapter;
        private System.Windows.Forms.Label lblCapcha;
        private System.Windows.Forms.TextBox tbxCapcha;
        private System.Windows.Forms.Label label6;
    }
}

