﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SUBD_ShvejnayaFabrika
{
    public partial class FormPoiskLewen : Form
    {
        List<string> lstTkani = new List<string>();

        public FormPoiskLewen()
        {
            InitializeComponent();
        }

        public static int Levenshtejn(string t1, string t2)
        {
            int CntLev = 0;

            CntLev += Math.Abs(t1.Length - t2.Length);

            for (int i = 0; i <= Math.Min(t1.Length, t2.Length) - 1; i++)
            {
                if (t1[i] != t2[i])
                {
                    CntLev++;
                }
            }
            return CntLev;
        }

        private void btnNechetPoisk_Click(object sender, EventArgs e)
        {
            dgvTkani.Rows.Clear();


            for (int i = 0; i <= lstTkani.Count-1; i++)
            {
                int lev = Levenshtejn(tbxLevenshtejn.Text, lstTkani[i]);
                if (lev <= 3)
                    dgvTkani.Rows.Add(lstTkani[i]);
            }
        }
        /// <summary>
        /// на момент открытия формы сформировать список с названиями тканей 
        /// и заполнить DataGridView
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FormPoiskLewen_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(Properties.Settings.Default.u37_15ConnectionString);

            con.Open();

            SqlCommand q1 = new SqlCommand(string.Format(@"SELECT NazvanieTkan 
                                                                    from tkani"), con);

            SqlDataReader res = q1.ExecuteReader();

            while (res.Read())
            {
                lstTkani.Add(res["NazvanieTkan"].ToString());
                dgvTkani.Rows.Add(res["NazvanieTkan"]);
            }

            con.Close();

            
        }

        private void ShowAll_Click(object sender, EventArgs e)
        {
            dgvTkani.Rows.Clear();
            for (int i = 0; i <= lstTkani.Count-1; i++)
            {
                    dgvTkani.Rows.Add(lstTkani[i]);
            }
        }
    }
}
