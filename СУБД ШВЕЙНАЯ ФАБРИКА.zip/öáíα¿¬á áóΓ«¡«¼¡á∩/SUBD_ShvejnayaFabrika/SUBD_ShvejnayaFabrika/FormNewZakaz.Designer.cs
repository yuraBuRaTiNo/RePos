﻿namespace SUBD_ShvejnayaFabrika
{
    partial class FormNewZakaz
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label nazvanieTkanLabel;
            System.Windows.Forms.Label colorTkanLabel;
            System.Windows.Forms.Label shirinaLabel;
            System.Windows.Forms.Label dlinaLabel;
            System.Windows.Forms.Label primechanieLabel;
            System.Windows.Forms.Label label2;
            System.Windows.Forms.Label label6;
            System.Windows.Forms.Label label3;
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tbxCountIzd = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.dgvIzd = new System.Windows.Forms.DataGridView();
            this.nazvanieIzdeliyaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dlinaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.shirinaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bsIzdelie = new System.Windows.Forms.BindingSource(this.components);
            this.u37_15DataSet1 = new SUBD_ShvejnayaFabrika.u37_15DataSet();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.primechanieTextBox = new System.Windows.Forms.TextBox();
            this.dlinaTextBox = new System.Windows.Forms.TextBox();
            this.shirinaTextBox = new System.Windows.Forms.TextBox();
            this.colorTkanTextBox = new System.Windows.Forms.TextBox();
            this.nazvanieTkanTextBox = new System.Windows.Forms.TextBox();
            this.LvTkan = new System.Windows.Forms.ListView();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tbxFurnForIzdelie = new System.Windows.Forms.TextBox();
            this.tbxNazvFurnitura = new System.Windows.Forms.TextBox();
            this.tbxKolVoFurnitura = new System.Windows.Forms.TextBox();
            this.LVFurnitura = new System.Windows.Forms.ListView();
            this.imageListFur = new System.Windows.Forms.ImageList(this.components);
            this.bsTkan = new System.Windows.Forms.BindingSource(this.components);
            this.izdeliyaTableAdapter = new SUBD_ShvejnayaFabrika.u37_15DataSetTableAdapters.IzdeliyaTableAdapter();
            this.tkaniTableAdapter = new SUBD_ShvejnayaFabrika.u37_15DataSetTableAdapters.TkaniTableAdapter();
            this.tableAdapterManager = new SUBD_ShvejnayaFabrika.u37_15DataSetTableAdapters.TableAdapterManager();
            this.btnSformirZakaz = new System.Windows.Forms.Button();
            this.btnCansel = new System.Windows.Forms.Button();
            this.lblidIzd = new System.Windows.Forms.Label();
            this.polzovateliBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.polzovateliTableAdapter = new SUBD_ShvejnayaFabrika.u37_15DataSetTableAdapters.PolzovateliTableAdapter();
            nazvanieTkanLabel = new System.Windows.Forms.Label();
            colorTkanLabel = new System.Windows.Forms.Label();
            shirinaLabel = new System.Windows.Forms.Label();
            dlinaLabel = new System.Windows.Forms.Label();
            primechanieLabel = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            label6 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvIzd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsIzdelie)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.u37_15DataSet1)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bsTkan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.polzovateliBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // nazvanieTkanLabel
            // 
            nazvanieTkanLabel.AutoSize = true;
            nazvanieTkanLabel.Location = new System.Drawing.Point(598, 9);
            nazvanieTkanLabel.Name = "nazvanieTkanLabel";
            nazvanieTkanLabel.Size = new System.Drawing.Size(92, 13);
            nazvanieTkanLabel.TabIndex = 1;
            nazvanieTkanLabel.Text = "Название ткани:";
            // 
            // colorTkanLabel
            // 
            colorTkanLabel.AutoSize = true;
            colorTkanLabel.Location = new System.Drawing.Point(598, 56);
            colorTkanLabel.Name = "colorTkanLabel";
            colorTkanLabel.Size = new System.Drawing.Size(67, 13);
            colorTkanLabel.TabIndex = 3;
            colorTkanLabel.Text = "Цвет ткани:";
            // 
            // shirinaLabel
            // 
            shirinaLabel.AutoSize = true;
            shirinaLabel.Location = new System.Drawing.Point(598, 100);
            shirinaLabel.Name = "shirinaLabel";
            shirinaLabel.Size = new System.Drawing.Size(49, 13);
            shirinaLabel.TabIndex = 5;
            shirinaLabel.Text = "Ширина:";
            // 
            // dlinaLabel
            // 
            dlinaLabel.AutoSize = true;
            dlinaLabel.Location = new System.Drawing.Point(598, 144);
            dlinaLabel.Name = "dlinaLabel";
            dlinaLabel.Size = new System.Drawing.Size(43, 13);
            dlinaLabel.TabIndex = 7;
            dlinaLabel.Text = "Длина:";
            // 
            // primechanieLabel
            // 
            primechanieLabel.AutoSize = true;
            primechanieLabel.Location = new System.Drawing.Point(598, 190);
            primechanieLabel.Name = "primechanieLabel";
            primechanieLabel.Size = new System.Drawing.Size(73, 13);
            primechanieLabel.TabIndex = 9;
            primechanieLabel.Text = "Примечание:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(585, 73);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(102, 13);
            label2.TabIndex = 16;
            label2.Text = "Кол-во фурнитуры:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new System.Drawing.Point(585, 28);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(118, 13);
            label6.TabIndex = 18;
            label6.Text = "Название фурнитуры:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new System.Drawing.Point(585, 128);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(168, 13);
            label3.TabIndex = 21;
            label3.Text = "Кол-во фурнитуры для изделия:";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(904, 128);
            this.panel1.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(221, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(423, 37);
            this.label1.TabIndex = 1;
            this.label1.Text = "Добавление нового заказа";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Left;
            this.pictureBox1.Image = global::SUBD_ShvejnayaFabrika.Properties.Resources.fabric_logo;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(169, 128);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(12, 141);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(859, 385);
            this.tabControl1.TabIndex = 4;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.tbxCountIzd);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.dgvIzd);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(851, 359);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Изделие";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tbxCountIzd
            // 
            this.tbxCountIzd.Location = new System.Drawing.Point(7, 261);
            this.tbxCountIzd.Name = "tbxCountIzd";
            this.tbxCountIzd.Size = new System.Drawing.Size(146, 20);
            this.tbxCountIzd.TabIndex = 1;
            this.tbxCountIzd.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbxCountIzd_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 245);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(171, 13);
            this.label5.TabIndex = 21;
            this.label5.Text = "Количество изделий для заказа\r\n";
            // 
            // dgvIzd
            // 
            this.dgvIzd.AllowUserToAddRows = false;
            this.dgvIzd.AllowUserToDeleteRows = false;
            this.dgvIzd.AutoGenerateColumns = false;
            this.dgvIzd.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvIzd.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.nazvanieIzdeliyaDataGridViewTextBoxColumn,
            this.dlinaDataGridViewTextBoxColumn,
            this.shirinaDataGridViewTextBoxColumn});
            this.dgvIzd.DataSource = this.bsIzdelie;
            this.dgvIzd.Location = new System.Drawing.Point(7, 7);
            this.dgvIzd.Name = "dgvIzd";
            this.dgvIzd.ReadOnly = true;
            this.dgvIzd.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvIzd.Size = new System.Drawing.Size(454, 217);
            this.dgvIzd.TabIndex = 0;
            // 
            // nazvanieIzdeliyaDataGridViewTextBoxColumn
            // 
            this.nazvanieIzdeliyaDataGridViewTextBoxColumn.DataPropertyName = "NazvanieIzdeliya";
            this.nazvanieIzdeliyaDataGridViewTextBoxColumn.HeaderText = "Название";
            this.nazvanieIzdeliyaDataGridViewTextBoxColumn.Name = "nazvanieIzdeliyaDataGridViewTextBoxColumn";
            this.nazvanieIzdeliyaDataGridViewTextBoxColumn.ReadOnly = true;
            this.nazvanieIzdeliyaDataGridViewTextBoxColumn.Width = 200;
            // 
            // dlinaDataGridViewTextBoxColumn
            // 
            this.dlinaDataGridViewTextBoxColumn.DataPropertyName = "Dlina";
            this.dlinaDataGridViewTextBoxColumn.HeaderText = "Длина";
            this.dlinaDataGridViewTextBoxColumn.Name = "dlinaDataGridViewTextBoxColumn";
            this.dlinaDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // shirinaDataGridViewTextBoxColumn
            // 
            this.shirinaDataGridViewTextBoxColumn.DataPropertyName = "Shirina";
            this.shirinaDataGridViewTextBoxColumn.HeaderText = "Ширина";
            this.shirinaDataGridViewTextBoxColumn.Name = "shirinaDataGridViewTextBoxColumn";
            this.shirinaDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // bsIzdelie
            // 
            this.bsIzdelie.DataMember = "Izdeliya";
            this.bsIzdelie.DataSource = this.u37_15DataSet1;
            // 
            // u37_15DataSet1
            // 
            this.u37_15DataSet1.DataSetName = "u37_15DataSet";
            this.u37_15DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tabPage2
            // 
            this.tabPage2.AutoScroll = true;
            this.tabPage2.Controls.Add(primechanieLabel);
            this.tabPage2.Controls.Add(this.primechanieTextBox);
            this.tabPage2.Controls.Add(dlinaLabel);
            this.tabPage2.Controls.Add(this.dlinaTextBox);
            this.tabPage2.Controls.Add(shirinaLabel);
            this.tabPage2.Controls.Add(this.shirinaTextBox);
            this.tabPage2.Controls.Add(colorTkanLabel);
            this.tabPage2.Controls.Add(this.colorTkanTextBox);
            this.tabPage2.Controls.Add(nazvanieTkanLabel);
            this.tabPage2.Controls.Add(this.nazvanieTkanTextBox);
            this.tabPage2.Controls.Add(this.LvTkan);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(851, 359);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Ткань";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // primechanieTextBox
            // 
            this.primechanieTextBox.Location = new System.Drawing.Point(696, 187);
            this.primechanieTextBox.Name = "primechanieTextBox";
            this.primechanieTextBox.ReadOnly = true;
            this.primechanieTextBox.Size = new System.Drawing.Size(130, 20);
            this.primechanieTextBox.TabIndex = 10;
            // 
            // dlinaTextBox
            // 
            this.dlinaTextBox.Location = new System.Drawing.Point(696, 144);
            this.dlinaTextBox.Name = "dlinaTextBox";
            this.dlinaTextBox.ReadOnly = true;
            this.dlinaTextBox.Size = new System.Drawing.Size(130, 20);
            this.dlinaTextBox.TabIndex = 8;
            // 
            // shirinaTextBox
            // 
            this.shirinaTextBox.Location = new System.Drawing.Point(696, 97);
            this.shirinaTextBox.Name = "shirinaTextBox";
            this.shirinaTextBox.ReadOnly = true;
            this.shirinaTextBox.Size = new System.Drawing.Size(130, 20);
            this.shirinaTextBox.TabIndex = 6;
            // 
            // colorTkanTextBox
            // 
            this.colorTkanTextBox.Location = new System.Drawing.Point(696, 49);
            this.colorTkanTextBox.Name = "colorTkanTextBox";
            this.colorTkanTextBox.ReadOnly = true;
            this.colorTkanTextBox.Size = new System.Drawing.Size(130, 20);
            this.colorTkanTextBox.TabIndex = 4;
            // 
            // nazvanieTkanTextBox
            // 
            this.nazvanieTkanTextBox.Location = new System.Drawing.Point(696, 6);
            this.nazvanieTkanTextBox.Name = "nazvanieTkanTextBox";
            this.nazvanieTkanTextBox.ReadOnly = true;
            this.nazvanieTkanTextBox.Size = new System.Drawing.Size(130, 20);
            this.nazvanieTkanTextBox.TabIndex = 2;
            // 
            // LvTkan
            // 
            this.LvTkan.Dock = System.Windows.Forms.DockStyle.Left;
            this.LvTkan.LargeImageList = this.imageList1;
            this.LvTkan.Location = new System.Drawing.Point(3, 3);
            this.LvTkan.Name = "LvTkan";
            this.LvTkan.Size = new System.Drawing.Size(576, 353);
            this.LvTkan.TabIndex = 0;
            this.LvTkan.UseCompatibleStateImageBehavior = false;
            this.LvTkan.SelectedIndexChanged += new System.EventHandler(this.LvTkan_SelectedIndexChanged);
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(100, 100);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(label3);
            this.tabPage3.Controls.Add(this.tbxFurnForIzdelie);
            this.tabPage3.Controls.Add(label6);
            this.tabPage3.Controls.Add(this.tbxNazvFurnitura);
            this.tabPage3.Controls.Add(label2);
            this.tabPage3.Controls.Add(this.tbxKolVoFurnitura);
            this.tabPage3.Controls.Add(this.LVFurnitura);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(851, 359);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Фурнитура";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // tbxFurnForIzdelie
            // 
            this.tbxFurnForIzdelie.Location = new System.Drawing.Point(588, 144);
            this.tbxFurnForIzdelie.Name = "tbxFurnForIzdelie";
            this.tbxFurnForIzdelie.Size = new System.Drawing.Size(165, 20);
            this.tbxFurnForIzdelie.TabIndex = 20;
            this.tbxFurnForIzdelie.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbxFurnForIzdelie_KeyPress);
            // 
            // tbxNazvFurnitura
            // 
            this.tbxNazvFurnitura.Location = new System.Drawing.Point(709, 25);
            this.tbxNazvFurnitura.Name = "tbxNazvFurnitura";
            this.tbxNazvFurnitura.ReadOnly = true;
            this.tbxNazvFurnitura.Size = new System.Drawing.Size(130, 20);
            this.tbxNazvFurnitura.TabIndex = 19;
            // 
            // tbxKolVoFurnitura
            // 
            this.tbxKolVoFurnitura.Location = new System.Drawing.Point(709, 70);
            this.tbxKolVoFurnitura.Name = "tbxKolVoFurnitura";
            this.tbxKolVoFurnitura.ReadOnly = true;
            this.tbxKolVoFurnitura.Size = new System.Drawing.Size(130, 20);
            this.tbxKolVoFurnitura.TabIndex = 17;
            // 
            // LVFurnitura
            // 
            this.LVFurnitura.Dock = System.Windows.Forms.DockStyle.Left;
            this.LVFurnitura.LargeImageList = this.imageListFur;
            this.LVFurnitura.Location = new System.Drawing.Point(3, 3);
            this.LVFurnitura.Name = "LVFurnitura";
            this.LVFurnitura.Size = new System.Drawing.Size(576, 353);
            this.LVFurnitura.TabIndex = 11;
            this.LVFurnitura.UseCompatibleStateImageBehavior = false;
            this.LVFurnitura.SelectedIndexChanged += new System.EventHandler(this.LVFurnitura_SelectedIndexChanged);
            // 
            // imageListFur
            // 
            this.imageListFur.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
            this.imageListFur.ImageSize = new System.Drawing.Size(100, 100);
            this.imageListFur.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // bsTkan
            // 
            this.bsTkan.DataMember = "Tkani";
            this.bsTkan.DataSource = this.u37_15DataSet1;
            // 
            // izdeliyaTableAdapter
            // 
            this.izdeliyaTableAdapter.ClearBeforeFill = true;
            // 
            // tkaniTableAdapter
            // 
            this.tkaniTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.FurnituraTableAdapter = null;
            this.tableAdapterManager.IzdeliyaTableAdapter = this.izdeliyaTableAdapter;
            this.tableAdapterManager.PolzovateliTableAdapter = null;
            this.tableAdapterManager.TkaniTableAdapter = this.tkaniTableAdapter;
            this.tableAdapterManager.UpdateOrder = SUBD_ShvejnayaFabrika.u37_15DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.ZakazyTableAdapter = null;
            // 
            // btnSformirZakaz
            // 
            this.btnSformirZakaz.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(156)))), ((int)(((byte)(26)))));
            this.btnSformirZakaz.Location = new System.Drawing.Point(16, 532);
            this.btnSformirZakaz.Name = "btnSformirZakaz";
            this.btnSformirZakaz.Size = new System.Drawing.Size(154, 48);
            this.btnSformirZakaz.TabIndex = 19;
            this.btnSformirZakaz.Text = "Сформировать заказ\r\n";
            this.btnSformirZakaz.UseVisualStyleBackColor = false;
            this.btnSformirZakaz.Click += new System.EventHandler(this.btnSformirZakaz_Click);
            // 
            // btnCansel
            // 
            this.btnCansel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(156)))), ((int)(((byte)(26)))));
            this.btnCansel.Location = new System.Drawing.Point(201, 532);
            this.btnCansel.Name = "btnCansel";
            this.btnCansel.Size = new System.Drawing.Size(154, 48);
            this.btnCansel.TabIndex = 20;
            this.btnCansel.Text = "Отмена";
            this.btnCansel.UseVisualStyleBackColor = false;
            // 
            // lblidIzd
            // 
            this.lblidIzd.AutoSize = true;
            this.lblidIzd.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsIzdelie, "idIzdeliya", true));
            this.lblidIzd.Location = new System.Drawing.Point(1060, 357);
            this.lblidIzd.Name = "lblidIzd";
            this.lblidIzd.Size = new System.Drawing.Size(29, 13);
            this.lblidIzd.TabIndex = 3;
            this.lblidIzd.Text = "idIzd";
            // 
            // polzovateliBindingSource
            // 
            this.polzovateliBindingSource.DataMember = "Polzovateli";
            this.polzovateliBindingSource.DataSource = this.u37_15DataSet1;
            // 
            // polzovateliTableAdapter
            // 
            this.polzovateliTableAdapter.ClearBeforeFill = true;
            // 
            // FormNewZakaz
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(904, 592);
            this.Controls.Add(this.lblidIzd);
            this.Controls.Add(this.btnCansel);
            this.Controls.Add(this.btnSformirZakaz);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormNewZakaz";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormNewZakaz";
            this.Load += new System.EventHandler(this.FormNewZakaz_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvIzd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsIzdelie)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.u37_15DataSet1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bsTkan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.polzovateliBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private u37_15DataSet u37_15DataSet1;
        private System.Windows.Forms.BindingSource bsIzdelie;
        private u37_15DataSetTableAdapters.IzdeliyaTableAdapter izdeliyaTableAdapter;
        private System.Windows.Forms.DataGridView dgvIzd;
        private System.Windows.Forms.DataGridViewTextBoxColumn nazvanieIzdeliyaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dlinaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn shirinaDataGridViewTextBoxColumn;
        private System.Windows.Forms.ListView LvTkan;
        private System.Windows.Forms.BindingSource bsTkan;
        private u37_15DataSetTableAdapters.TkaniTableAdapter tkaniTableAdapter;
        private System.Windows.Forms.TextBox primechanieTextBox;
        private System.Windows.Forms.TextBox colorTkanTextBox;
        private System.Windows.Forms.TextBox nazvanieTkanTextBox;
        private u37_15DataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.TextBox tbxNazvFurnitura;
        private System.Windows.Forms.TextBox tbxKolVoFurnitura;
        private System.Windows.Forms.ListView LVFurnitura;
        private System.Windows.Forms.ImageList imageListFur;
        private System.Windows.Forms.TextBox tbxFurnForIzdelie;
        private System.Windows.Forms.TextBox tbxCountIzd;
        private System.Windows.Forms.Button btnSformirZakaz;
        private System.Windows.Forms.Button btnCansel;
        public System.Windows.Forms.Label lblidIzd;
        public System.Windows.Forms.TextBox dlinaTextBox;
        public System.Windows.Forms.TextBox shirinaTextBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.BindingSource polzovateliBindingSource;
        private u37_15DataSetTableAdapters.PolzovateliTableAdapter polzovateliTableAdapter;
    }
}