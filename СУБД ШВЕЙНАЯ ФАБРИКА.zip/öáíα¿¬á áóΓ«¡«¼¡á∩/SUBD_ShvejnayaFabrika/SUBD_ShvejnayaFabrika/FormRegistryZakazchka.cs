﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using ClassLibrary1;


namespace SUBD_ShvejnayaFabrika
{
    public partial class FormRegistryZakazchka : Form
    {
        public FormRegistryZakazchka()
        {
            InitializeComponent();
        }

        private void FormRegistryZakazchka_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'u37_15DataSet1.Polzovateli' table. You can move, or remove it, as needed.
            this.polzovateliTableAdapter.Fill(this.u37_15DataSet1.Polzovateli);
            bsPolzovatel.AddNew();
            lblRole.Text = "заказчик";
        }

        private void Btn_Reg_Click(object sender, EventArgs e)
        {
            if(PasswordTextBox.Text != tbxProverkaPass.Text)
            {
                MessageBox.Show("Введенные пароли не совпадают или не соответствуют требованиям", "",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            try
            {
                bsPolzovatel.EndEdit();
                this.polzovateliTableAdapter.Update(this.u37_15DataSet1.Polzovateli);
                MessageBox.Show("Новая запись добавлена");
            }
            catch
            {
                MessageBox.Show("В базе данных уже есть пользователь с таким логином, введите уникальный логин", "", 
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoginTextBox.Focus();
            }

            this.DialogResult = DialogResult.OK;
            Close();
        }

        private void btn_Cansel_Click(object sender, EventArgs e)
        {

        }

        private void lblRole_Click(object sender, EventArgs e)
        {

        }

        private void cbxShowPass_CheckedChanged(object sender, EventArgs e)
        {
            PasswordTextBox.UseSystemPasswordChar = !cbxShowPass.Checked;

            tbxProverkaPass.UseSystemPasswordChar = !cbxShowPass.Checked;
        }
    }
}
