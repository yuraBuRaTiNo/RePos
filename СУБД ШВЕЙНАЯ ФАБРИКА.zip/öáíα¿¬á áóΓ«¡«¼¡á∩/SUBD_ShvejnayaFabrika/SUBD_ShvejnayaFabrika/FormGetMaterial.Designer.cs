﻿namespace SUBD_ShvejnayaFabrika
{
    partial class FormGetMaterial
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnDelTkanDock = new System.Windows.Forms.Button();
            this.dgvDock = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnClearPhoto = new System.Windows.Forms.Button();
            this.btnLoadPhoto = new System.Windows.Forms.Button();
            this.btnAddTkanDokyment = new System.Windows.Forms.Button();
            this.pbxPhoto = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tbxOpisanie = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tbxDlinaTkan = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbxCvetTkan = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbxShirinaTkan = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbxNameTkan = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnDelFurDock = new System.Windows.Forms.Button();
            this.dgvDockFur = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnAddFurDock = new System.Windows.Forms.Button();
            this.btnClearPhotoFur = new System.Windows.Forms.Button();
            this.btnLoadPhotoFur = new System.Windows.Forms.Button();
            this.pbxPhotoFur = new System.Windows.Forms.PictureBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tbxCountFur = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.tbxNameFur = new System.Windows.Forms.TextBox();
            this.btnPrinyatDockYchet = new System.Windows.Forms.Button();
            this.btnCansel = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDock)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPhoto)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDockFur)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPhotoFur)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(920, 128);
            this.panel1.TabIndex = 14;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(221, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(440, 37);
            this.label1.TabIndex = 1;
            this.label1.Text = "Форма принятия материала\r\n";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Left;
            this.pictureBox1.Image = global::SUBD_ShvejnayaFabrika.Properties.Resources.fabric_logo;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(169, 128);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(0, 152);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(800, 498);
            this.tabControl1.TabIndex = 15;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btnDelTkanDock);
            this.tabPage1.Controls.Add(this.dgvDock);
            this.tabPage1.Controls.Add(this.btnClearPhoto);
            this.tabPage1.Controls.Add(this.btnLoadPhoto);
            this.tabPage1.Controls.Add(this.btnAddTkanDokyment);
            this.tabPage1.Controls.Add(this.pbxPhoto);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.tbxOpisanie);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.tbxDlinaTkan);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.tbxCvetTkan);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.tbxShirinaTkan);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.tbxNameTkan);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(792, 472);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Добавить в документ ткани ";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btnDelTkanDock
            // 
            this.btnDelTkanDock.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(156)))), ((int)(((byte)(26)))));
            this.btnDelTkanDock.Location = new System.Drawing.Point(15, 418);
            this.btnDelTkanDock.Name = "btnDelTkanDock";
            this.btnDelTkanDock.Size = new System.Drawing.Size(223, 48);
            this.btnDelTkanDock.TabIndex = 23;
            this.btnDelTkanDock.Text = "Удалить эту ткань из документ ";
            this.btnDelTkanDock.UseVisualStyleBackColor = false;
            this.btnDelTkanDock.Click += new System.EventHandler(this.btnDelTkanDock_Click);
            // 
            // dgvDock
            // 
            this.dgvDock.AllowUserToAddRows = false;
            this.dgvDock.AllowUserToDeleteRows = false;
            this.dgvDock.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDock.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column3,
            this.Column2,
            this.Column4,
            this.Column5});
            this.dgvDock.Location = new System.Drawing.Point(15, 263);
            this.dgvDock.Name = "dgvDock";
            this.dgvDock.ReadOnly = true;
            this.dgvDock.RowHeadersVisible = false;
            this.dgvDock.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDock.Size = new System.Drawing.Size(650, 150);
            this.dgvDock.TabIndex = 22;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Название";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 150;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Ширина";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Цвет";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Длина";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "Описание";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            this.Column5.Width = 150;
            // 
            // btnClearPhoto
            // 
            this.btnClearPhoto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(156)))), ((int)(((byte)(26)))));
            this.btnClearPhoto.Location = new System.Drawing.Point(477, 110);
            this.btnClearPhoto.Name = "btnClearPhoto";
            this.btnClearPhoto.Size = new System.Drawing.Size(188, 48);
            this.btnClearPhoto.TabIndex = 21;
            this.btnClearPhoto.Text = "очистить фото";
            this.btnClearPhoto.UseVisualStyleBackColor = false;
            this.btnClearPhoto.Click += new System.EventHandler(this.btnClearPhoto_Click);
            // 
            // btnLoadPhoto
            // 
            this.btnLoadPhoto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(156)))), ((int)(((byte)(26)))));
            this.btnLoadPhoto.Location = new System.Drawing.Point(477, 22);
            this.btnLoadPhoto.Name = "btnLoadPhoto";
            this.btnLoadPhoto.Size = new System.Drawing.Size(188, 48);
            this.btnLoadPhoto.TabIndex = 20;
            this.btnLoadPhoto.Text = "Загрузить фото";
            this.btnLoadPhoto.UseVisualStyleBackColor = false;
            this.btnLoadPhoto.Click += new System.EventHandler(this.btnLoadPhoto_Click);
            // 
            // btnAddTkanDokyment
            // 
            this.btnAddTkanDokyment.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(156)))), ((int)(((byte)(26)))));
            this.btnAddTkanDokyment.Location = new System.Drawing.Point(15, 209);
            this.btnAddTkanDokyment.Name = "btnAddTkanDokyment";
            this.btnAddTkanDokyment.Size = new System.Drawing.Size(223, 48);
            this.btnAddTkanDokyment.TabIndex = 19;
            this.btnAddTkanDokyment.Text = "Добавить эту ткань в документ ";
            this.btnAddTkanDokyment.UseVisualStyleBackColor = false;
            this.btnAddTkanDokyment.Click += new System.EventHandler(this.btnAddTkanDokyment_Click);
            // 
            // pbxPhoto
            // 
            this.pbxPhoto.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbxPhoto.Location = new System.Drawing.Point(301, 22);
            this.pbxPhoto.Name = "pbxPhoto";
            this.pbxPhoto.Size = new System.Drawing.Size(170, 136);
            this.pbxPhoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxPhoto.TabIndex = 10;
            this.pbxPhoto.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 186);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(60, 13);
            this.label6.TabIndex = 9;
            this.label6.Text = "Описание:";
            // 
            // tbxOpisanie
            // 
            this.tbxOpisanie.Location = new System.Drawing.Point(82, 183);
            this.tbxOpisanie.Name = "tbxOpisanie";
            this.tbxOpisanie.Size = new System.Drawing.Size(156, 20);
            this.tbxOpisanie.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 141);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "Длина:";
            // 
            // tbxDlinaTkan
            // 
            this.tbxDlinaTkan.Location = new System.Drawing.Point(82, 138);
            this.tbxDlinaTkan.Name = "tbxDlinaTkan";
            this.tbxDlinaTkan.Size = new System.Drawing.Size(156, 20);
            this.tbxDlinaTkan.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 99);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Цвет:";
            // 
            // tbxCvetTkan
            // 
            this.tbxCvetTkan.Location = new System.Drawing.Point(82, 96);
            this.tbxCvetTkan.Name = "tbxCvetTkan";
            this.tbxCvetTkan.Size = new System.Drawing.Size(156, 20);
            this.tbxCvetTkan.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 61);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Ширина:";
            // 
            // tbxShirinaTkan
            // 
            this.tbxShirinaTkan.Location = new System.Drawing.Point(82, 58);
            this.tbxShirinaTkan.Name = "tbxShirinaTkan";
            this.tbxShirinaTkan.Size = new System.Drawing.Size(156, 20);
            this.tbxShirinaTkan.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Название:";
            // 
            // tbxNameTkan
            // 
            this.tbxNameTkan.Location = new System.Drawing.Point(82, 22);
            this.tbxNameTkan.Name = "tbxNameTkan";
            this.tbxNameTkan.Size = new System.Drawing.Size(156, 20);
            this.tbxNameTkan.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.btnDelFurDock);
            this.tabPage2.Controls.Add(this.dgvDockFur);
            this.tabPage2.Controls.Add(this.btnAddFurDock);
            this.tabPage2.Controls.Add(this.btnClearPhotoFur);
            this.tabPage2.Controls.Add(this.btnLoadPhotoFur);
            this.tabPage2.Controls.Add(this.pbxPhotoFur);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.tbxCountFur);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.tbxNameFur);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(792, 472);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Добавить в документ фурнитуру";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // btnDelFurDock
            // 
            this.btnDelFurDock.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(156)))), ((int)(((byte)(26)))));
            this.btnDelFurDock.Location = new System.Drawing.Point(8, 323);
            this.btnDelFurDock.Name = "btnDelFurDock";
            this.btnDelFurDock.Size = new System.Drawing.Size(223, 48);
            this.btnDelFurDock.TabIndex = 33;
            this.btnDelFurDock.Text = "Удалить эту Фурнитуру из документ ";
            this.btnDelFurDock.UseVisualStyleBackColor = false;
            this.btnDelFurDock.Click += new System.EventHandler(this.btnDelFurDock_Click);
            // 
            // dgvDockFur
            // 
            this.dgvDockFur.AllowUserToAddRows = false;
            this.dgvDockFur.AllowUserToDeleteRows = false;
            this.dgvDockFur.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDockFur.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2});
            this.dgvDockFur.Location = new System.Drawing.Point(8, 168);
            this.dgvDockFur.MultiSelect = false;
            this.dgvDockFur.Name = "dgvDockFur";
            this.dgvDockFur.ReadOnly = true;
            this.dgvDockFur.RowHeadersVisible = false;
            this.dgvDockFur.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDockFur.Size = new System.Drawing.Size(256, 150);
            this.dgvDockFur.TabIndex = 32;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "Название";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 150;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "количество";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // btnAddFurDock
            // 
            this.btnAddFurDock.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(156)))), ((int)(((byte)(26)))));
            this.btnAddFurDock.Location = new System.Drawing.Point(8, 114);
            this.btnAddFurDock.Name = "btnAddFurDock";
            this.btnAddFurDock.Size = new System.Drawing.Size(223, 48);
            this.btnAddFurDock.TabIndex = 31;
            this.btnAddFurDock.Text = "Добавить эту фурнитуру в документ ";
            this.btnAddFurDock.UseVisualStyleBackColor = false;
            this.btnAddFurDock.Click += new System.EventHandler(this.btnAddFurDock_Click);
            // 
            // btnClearPhotoFur
            // 
            this.btnClearPhotoFur.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(156)))), ((int)(((byte)(26)))));
            this.btnClearPhotoFur.Location = new System.Drawing.Point(469, 114);
            this.btnClearPhotoFur.Name = "btnClearPhotoFur";
            this.btnClearPhotoFur.Size = new System.Drawing.Size(188, 48);
            this.btnClearPhotoFur.TabIndex = 30;
            this.btnClearPhotoFur.Text = "очистить фото";
            this.btnClearPhotoFur.UseVisualStyleBackColor = false;
            this.btnClearPhotoFur.Click += new System.EventHandler(this.btnClearPhotoFur_Click);
            // 
            // btnLoadPhotoFur
            // 
            this.btnLoadPhotoFur.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(156)))), ((int)(((byte)(26)))));
            this.btnLoadPhotoFur.Location = new System.Drawing.Point(469, 26);
            this.btnLoadPhotoFur.Name = "btnLoadPhotoFur";
            this.btnLoadPhotoFur.Size = new System.Drawing.Size(188, 48);
            this.btnLoadPhotoFur.TabIndex = 29;
            this.btnLoadPhotoFur.Text = "Загрузить фото";
            this.btnLoadPhotoFur.UseVisualStyleBackColor = false;
            this.btnLoadPhotoFur.Click += new System.EventHandler(this.btnLoadPhotoFur_Click);
            // 
            // pbxPhotoFur
            // 
            this.pbxPhotoFur.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbxPhotoFur.Location = new System.Drawing.Point(293, 26);
            this.pbxPhotoFur.Name = "pbxPhotoFur";
            this.pbxPhotoFur.Size = new System.Drawing.Size(170, 136);
            this.pbxPhotoFur.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxPhotoFur.TabIndex = 28;
            this.pbxPhotoFur.TabStop = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(4, 65);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(69, 13);
            this.label8.TabIndex = 25;
            this.label8.Text = "Количество:";
            // 
            // tbxCountFur
            // 
            this.tbxCountFur.Location = new System.Drawing.Point(74, 62);
            this.tbxCountFur.Name = "tbxCountFur";
            this.tbxCountFur.Size = new System.Drawing.Size(156, 20);
            this.tbxCountFur.TabIndex = 24;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(4, 26);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(60, 13);
            this.label9.TabIndex = 23;
            this.label9.Text = "Название:";
            // 
            // tbxNameFur
            // 
            this.tbxNameFur.Location = new System.Drawing.Point(74, 26);
            this.tbxNameFur.Name = "tbxNameFur";
            this.tbxNameFur.Size = new System.Drawing.Size(156, 20);
            this.tbxNameFur.TabIndex = 22;
            // 
            // btnPrinyatDockYchet
            // 
            this.btnPrinyatDockYchet.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(156)))), ((int)(((byte)(26)))));
            this.btnPrinyatDockYchet.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnPrinyatDockYchet.Location = new System.Drawing.Point(12, 656);
            this.btnPrinyatDockYchet.Name = "btnPrinyatDockYchet";
            this.btnPrinyatDockYchet.Size = new System.Drawing.Size(223, 48);
            this.btnPrinyatDockYchet.TabIndex = 20;
            this.btnPrinyatDockYchet.Text = "Принять документ к учету";
            this.btnPrinyatDockYchet.UseVisualStyleBackColor = false;
            this.btnPrinyatDockYchet.Click += new System.EventHandler(this.btnPrinyatDockYchet_Click);
            // 
            // btnCansel
            // 
            this.btnCansel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(156)))), ((int)(((byte)(26)))));
            this.btnCansel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCansel.Location = new System.Drawing.Point(252, 656);
            this.btnCansel.Name = "btnCansel";
            this.btnCansel.Size = new System.Drawing.Size(223, 48);
            this.btnCansel.TabIndex = 21;
            this.btnCansel.Text = "Отмена";
            this.btnCansel.UseVisualStyleBackColor = false;
            // 
            // FormGetMaterial
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(920, 720);
            this.Controls.Add(this.btnCansel);
            this.Controls.Add(this.btnPrinyatDockYchet);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormGetMaterial";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "FormGetMaterial";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDock)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPhoto)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDockFur)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPhotoFur)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbxOpisanie;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbxDlinaTkan;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbxCvetTkan;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbxShirinaTkan;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbxNameTkan;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.PictureBox pbxPhoto;
        private System.Windows.Forms.DataGridView dgvDock;
        private System.Windows.Forms.Button btnClearPhoto;
        private System.Windows.Forms.Button btnLoadPhoto;
        private System.Windows.Forms.Button btnAddTkanDokyment;
        private System.Windows.Forms.Button btnDelTkanDock;
        private System.Windows.Forms.Button btnPrinyatDockYchet;
        private System.Windows.Forms.Button btnCansel;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.Button btnDelFurDock;
        private System.Windows.Forms.DataGridView dgvDockFur;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.Button btnAddFurDock;
        private System.Windows.Forms.Button btnClearPhotoFur;
        private System.Windows.Forms.Button btnLoadPhotoFur;
        private System.Windows.Forms.PictureBox pbxPhotoFur;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tbxCountFur;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tbxNameFur;
    }
}