﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Word = Microsoft.Office.Interop.Word;

namespace SUBD_ShvejnayaFabrika
{
    public partial class FormManajer : Form
    {
        public FormManajer()
        {
            InitializeComponent();
        }

        string idTkan = "", idFur = "";

        List<Tkani> lstTkani = new List<Tkani>();

        public struct Tkani
        {
            public string nazvanie, cvet, primech, id, shirina, dlina;

            public Image PhotoTkan;
        }

        List<Furnitura> lstFurnitura = new List<Furnitura>();

        public struct Furnitura
        {
            public string namefur, counfur, id;

            public Image PhotoFurnitura;
        }

        void FillListZakaz()
        {
            SqlConnection con = new SqlConnection(Properties.Settings.Default.u37_15ConnectionString);

            con.Open();

            SqlCommand q1 = new SqlCommand(string.Format(@"SELECT        Izdeliya.NazvanieIzdeliya as izd,
				Zakazy.KolichIzdelij as countizd,
				Tkani.NazvanieTkan as nazvtkan,
				Furnitura.namefur as nazvfur,
				Zakazy.KolichFurnitura as countfur,
				
				zakazchik.Fam as zakazchik
				
FROM   Zakazy, Polzovateli as manajer, Polzovateli as zakazchik,
			Tkani, Furnitura, Izdeliya         						 

where 
		
		 zakazchik.idPolzovatel = Zakazy.idZakazchik
		and Tkani.idTkan = Zakazy.idTkan
		and Furnitura.idfur = Zakazy.idFurnitura
		and Izdeliya.idIzdeliya = Zakazy.idIzdeliya", lblIdUser.Text), con);

            SqlDataReader res = q1.ExecuteReader();

            while (res.Read())
            {
                dgvZakazy.Rows.Add(res["izd"], res["countizd"], res["nazvtkan"],
                    res["nazvfur"], res["countfur"], res["zakazchik"]);
            }

            con.Close();
        }

        void GetTkanFromDB()
        {
            SqlConnection con = new SqlConnection(Properties.Settings.Default.u37_15ConnectionString);

            con.Open();

            SqlCommand q1 = new SqlCommand("Select * from Tkani where dlina > 0", con);

            SqlDataReader data = q1.ExecuteReader();

            while (data.Read())
            {
                Tkani TK = new Tkani();

                TK.id = data["idTkan"].ToString();
                TK.nazvanie = data["NazvanieTkan"].ToString();
                TK.shirina = data["Shirina"].ToString();
                TK.dlina = data["Dlina"].ToString();
                TK.cvet = data["ColorTkan"].ToString();
                TK.primech = data["Primechanie"].ToString();


                try
                {
                    byte[] PhoteByte = (byte[])data["Photo"];

                    ImageConverter imc = new ImageConverter();

                    TK.PhotoTkan = (Bitmap)imc.ConvertFrom(PhoteByte);
                }
                catch
                {
                    TK.PhotoTkan = Properties.Resources.tmp;
                }
                lstTkani.Add(TK);
            }

            con.Close();
        }

        void GetFurnFromDB()
        {
            SqlConnection con = new SqlConnection(Properties.Settings.Default.u37_15ConnectionString);

            con.Open();

            SqlCommand q1 = new SqlCommand("Select * from Furnitura where countfur > 0", con);

            SqlDataReader data = q1.ExecuteReader();

            while (data.Read())
            {
                Furnitura FR = new Furnitura();

                FR.id = data["idfur"].ToString();
                FR.namefur = data["namefur"].ToString();
                FR.counfur = data["countfur"].ToString();

                try
                {
                    byte[] PhoteByte = (byte[])data["photo"];

                    ImageConverter imc = new ImageConverter();

                    FR.PhotoFurnitura = (Bitmap)imc.ConvertFrom(PhoteByte);
                }
                catch
                {
                    FR.PhotoFurnitura = Properties.Resources.tmp;
                }
                lstFurnitura.Add(FR);
            }

            con.Close();
        }

        void fillLVTkani()
        {
            LVTkani.Items.Clear();
            imageList1.Images.Clear();
            foreach (Tkani tk in lstTkani)
            {
                ListViewItem lv = new ListViewItem(tk.nazvanie);
                imageList1.Images.Add(tk.PhotoTkan);

                lv.ImageIndex = imageList1.Images.Count - 1;

                LVTkani.Items.Add(lv);
            }
        }

        void fillLVFurnitura()
        {
            LVFurnitura.Items.Clear();
            imageListFur.Images.Clear();
            foreach (Furnitura FR in lstFurnitura)
            {
                ListViewItem lv = new ListViewItem(FR.namefur);
                imageListFur.Images.Add(FR.PhotoFurnitura);

                lv.ImageIndex = imageListFur.Images.Count - 1;

                LVFurnitura.Items.Add(lv);
            }
        }


        private void FormManajer_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'u37_15DataSet1.Zakazy' table. You can move, or remove it, as needed.
            this.zakazyTableAdapter.Fill(this.u37_15DataSet1.Zakazy);
            // TODO: This line of code loads data into the 'u37_15DataSet1.Izdeliya' table. You can move, or remove it, as needed.
            this.izdeliyaTableAdapter.Fill(this.u37_15DataSet1.Izdeliya);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "u37_15DataSet1.Polzovateli". При необходимости она может быть перемещена или удалена.
            this.polzovateliTableAdapter.Fill(this.u37_15DataSet1.Polzovateli);

            FillListZakaz();


            GetTkanFromDB();
            fillLVTkani();

            GetFurnFromDB();
            fillLVFurnitura();
        }

        

        private void btnProfilPolzovatel_Click(object sender, EventArgs e)
        {
            FormProfile frmprof = new FormProfile();
            frmprof.bsPolzovatel.Filter = this.bsPolzovatel.Filter;
            if (frmprof.ShowDialog() == DialogResult.OK)
            {
                this.polzovateliTableAdapter.Fill(this.u37_15DataSet1.Polzovateli);
            }
        }

        private void btnRedakt_Click(object sender, EventArgs e)
        {
            nazvanieIzdeliyaTextBox.ReadOnly = false;

            dlinaTextBox.ReadOnly = false;

            shirinaTextBox.ReadOnly = false;

            btnnDobavit.Enabled = false;

            btnRedakt.Enabled = false;

            btnSave.Enabled = true;
        }

        private void btnnDobavit_Click(object sender, EventArgs e)
        {
            nazvanieIzdeliyaTextBox.ReadOnly = false;

            dlinaTextBox.ReadOnly = false;

            shirinaTextBox.ReadOnly = false;

            btnnDobavit.Enabled = false;

            btnRedakt.Enabled = false;

            btnSave.Enabled = true;

            bsIzdeliya.AddNew();
        }

        private void LVTkani_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (LVTkani.SelectedItems.Count > 0)//есть выделенные элементы
            {
                int num = LVTkani.SelectedIndices[0];//номер выделенного элемента

                nazvanieTkanTextBox.Text = lstTkani[num].nazvanie;

                colorTkanTextBox.Text = lstTkani[num].cvet;

                tbxShirina.Text = lstTkani[num].shirina;

                tbxDlina.Text = lstTkani[num].dlina;

                primechanieTextBox.Text = lstTkani[num].primech;

                idTkan = lstTkani[num].id;
            }
            else //нет выделенных элементов
            {
                nazvanieTkanTextBox.Text = "";

                colorTkanTextBox.Text = "";

                tbxShirina.Text = "";

                tbxDlina.Text = "";

                primechanieTextBox.Text = "";

                idTkan = "";
            }
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void LVFurnitura_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (LVFurnitura.SelectedItems.Count > 0)//есть выделенные элементы
            {
                int num = LVFurnitura.SelectedIndices[0];//номер выделенного элемента

                tbxNazvFurnitura.Text = lstFurnitura[num].namefur;

                tbxKolVoFurnitura.Text = lstFurnitura[num].counfur;

                idFur = lstFurnitura[num].id;
            }
            else //нет выделенных элементов
            {
                tbxKolVoFurnitura.Text = "";

                tbxNazvFurnitura.Text = "";

                idFur = "";
            }
        }

        private void btnEksportAll_Click(object sender, EventArgs e)
        {
            if(rbtWord.Checked)
            {
                Word.Application app = new Word.Application();

                app.Visible = true;

                Word.Document doc = app.Documents.Open(Application.StartupPath + "\\f.docx", null, true);

                Word.Bookmarks wbm = doc.Bookmarks; //закладки из документа

                wbm["man"].Range.Text = famLabel1.Text + " " + nameLabel1.Text + " " + otchLabel1.Text + " ";

                string num = "";

                string izd = ""; //название всех изделий

                string kolizd = "";

                string tkan = "";

                string fur = "";

                string kolFur = "";

                string zakazchik = "";

                //перебор записей таблицы
                for (int i = 0; i <= dgvZakazy.RowCount - 1; i++)
                {
                    num += (i + 1) + "\r\n";

                    izd += dgvZakazy.Rows[i].Cells[0].Value + "\r\n";

                    kolizd += dgvZakazy.Rows[i].Cells[1].Value + "\r\n";

                    tkan += dgvZakazy.Rows[i].Cells[2].Value + "\r\n";

                    fur += dgvZakazy.Rows[i].Cells[3].Value + "\r\n";

                    kolFur += dgvZakazy.Rows[i].Cells[4].Value + "\r\n";

                    zakazchik += dgvZakazy.Rows[i].Cells[5].Value + "\r\n";
                }

                wbm["num"].Range.Text = num.Trim();

                wbm["izd"].Range.Text = izd.Trim();

                wbm["kolvoizd"].Range.Text = kolizd.Trim();

                wbm["tkan"].Range.Text = tkan.Trim();

                wbm["fur"].Range.Text = fur.Trim();

                wbm["kolFur"].Range.Text = kolFur.Trim();

                wbm["Zakazchik"].Range.Text = zakazchik.Trim();
            }

            else
            {
                if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    StreamWriter sw = new StreamWriter(saveFileDialog1.FileName);

                    string t = "izd;kolvoizd;tkan;fur;kolFur;Zakazchik";
                    sw.WriteLine(t);

                    for (int i = 0; i <= dgvZakazy.RowCount - 1; i++)
                    {
                        t = "";

                        t += dgvZakazy.Rows[i].Cells[0].Value + ";";

                        t += dgvZakazy.Rows[i].Cells[1].Value + ";";

                        t += dgvZakazy.Rows[i].Cells[2].Value + ";";

                        t += dgvZakazy.Rows[i].Cells[3].Value + ";";

                        t += dgvZakazy.Rows[i].Cells[4].Value + ";";

                        t += dgvZakazy.Rows[i].Cells[5].Value;

                        sw.WriteLine(t);
                    }
                    sw.Close();
                }
            }

        }

        private void btnEksportNeAll_Click(object sender, EventArgs e)
        {
            if(rbtWord.Checked)
            {
                Word.Application app = new Word.Application();

                app.Visible = true;

                Word.Document doc = app.Documents.Open(Application.StartupPath + "\\f.docx", null, true);

                Word.Bookmarks wbm = doc.Bookmarks; //закладки из документа

                wbm["man"].Range.Text = famLabel1.Text + " " + nameLabel1.Text + " " + otchLabel1.Text + " ";

                string num = "";

                string izd = ""; //название всех изделий

                string kolizd = "";

                string tkan = "";

                string fur = "";

                string kolFur = "";

                string zakazchik = "";

                for (int i = 0; i <= dgvZakazy.SelectedRows.Count - 1; i++)
                {
                    num += (i + 1) + "\r\n";

                    izd += dgvZakazy.SelectedRows[i].Cells[0].Value + "\r\n";

                    kolizd += dgvZakazy.SelectedRows[i].Cells[1].Value + "\r\n";

                    tkan += dgvZakazy.SelectedRows[i].Cells[2].Value + "\r\n";

                    fur += dgvZakazy.SelectedRows[i].Cells[3].Value + "\r\n";

                    kolFur += dgvZakazy.SelectedRows[i].Cells[4].Value + "\r\n";

                    zakazchik += dgvZakazy.SelectedRows[i].Cells[5].Value + "\r\n";
                }

                wbm["num"].Range.Text = num.Trim();

                wbm["izd"].Range.Text = izd.Trim();

                wbm["kolvoizd"].Range.Text = kolizd.Trim();

                wbm["tkan"].Range.Text = tkan.Trim();

                wbm["fur"].Range.Text = fur.Trim();

                wbm["kolFur"].Range.Text = kolFur.Trim();

                wbm["Zakazchik"].Range.Text = zakazchik.Trim();
            }

            else
            {
                if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    StreamWriter sw = new StreamWriter(saveFileDialog1.FileName);

                    string t = "izd;kolvoizd;tkan;fur;kolFur;Zakazchik";
                    sw.WriteLine(t);

                    for (int i = 0; i <= dgvZakazy.SelectedRows.Count - 1; i++)
                    {
                        t = "";

                        t += dgvZakazy.SelectedRows[i].Cells[0].Value + ";";

                        t += dgvZakazy.SelectedRows[i].Cells[1].Value + ";";

                        t += dgvZakazy.SelectedRows[i].Cells[2].Value + ";";

                        t += dgvZakazy.SelectedRows[i].Cells[3].Value + ";";

                        t += dgvZakazy.SelectedRows[i].Cells[4].Value + ";";

                        t += dgvZakazy.SelectedRows[i].Cells[5].Value;

                        sw.WriteLine(t);
                    }
                    sw.Close();
                }
            }


        }

        private void nazvanieIzdeliyaTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar))
                e.Handled = true;
            if (e.KeyChar == (char)Keys.Back)
                e.Handled = false;
        }

        private void dlinaTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar))
                e.Handled = true;
            if (e.KeyChar == (char)Keys.Back)
                e.Handled = false;
        }

        private void shirinaTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar))
                e.Handled = true;
            if (e.KeyChar == (char)Keys.Back)
                e.Handled = false;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if(dlinaTextBox.Text == "0" || shirinaTextBox.Text == "0" || dlinaTextBox.Text == "" || shirinaTextBox.Text == "")
            {
                MessageBox.Show("Длина или ширина не может равняться 0");
                return;
            }

            if(nazvanieIzdeliyaTextBox.Text == "")
            {
                MessageBox.Show("Название изделия не может быть пустым");

            }

            bsIzdeliya.EndEdit();
            this.izdeliyaTableAdapter.Update(this.u37_15DataSet1.Izdeliya);

            nazvanieIzdeliyaTextBox.ReadOnly = true;

            dlinaTextBox.ReadOnly = true;

            shirinaTextBox.ReadOnly = true;

            btnnDobavit.Enabled = true;

            btnRedakt.Enabled = true;

            btnSave.Enabled = false;
        }
    }
}
