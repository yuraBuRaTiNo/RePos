﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SUBD_ShvejnayaFabrika
{
    public partial class FormZakazchik : Form
    {
        public FormZakazchik()
        {
            InitializeComponent();
        }

        /// <summary>
        /// заполнение DataGridView с заказами текущего заказчика
        /// </summary>
        void FillListZakaz()
        {
            SqlConnection con = new SqlConnection(Properties.Settings.Default.u37_15ConnectionString);

            con.Open();

            SqlCommand q1 = new SqlCommand(string.Format(@"SELECT        Izdeliya.NazvanieIzdeliya, Zakazy.KolichIzdelij, 
Tkani.NazvanieTkan, Furnitura.namefur, Furnitura.countfur,  Polzovateli.Fam as idManajer
FROM            Furnitura INNER JOIN
                         Zakazy ON Furnitura.idfur = Zakazy.idFurnitura INNER JOIN
                         Izdeliya ON Zakazy.idIzdeliya = Izdeliya.idIzdeliya INNER JOIN
                         Polzovateli ON Zakazy.idManajer = Polzovateli.idPolzovatel INNER JOIN
                         Tkani ON Zakazy.idTkan = Tkani.idTkan
						 where Zakazy.idZakazchik = {0}", lblIdUser.Text), con);

            SqlDataReader res = q1.ExecuteReader();

            while(res.Read())
            {
                dgvZakazy.Rows.Add(res["NazvanieIzdeliya"], res["KolichIzdelij"], res["NazvanieTkan"], 
                    res["namefur"], res["countfur"], res["idManajer"]);
            }

            con.Close();
        }

        private void FormZakazchik_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'u37_15DataSet1.Polzovateli' table. You can move, or remove it, as needed.
            this.polzovateliTableAdapter.Fill(this.u37_15DataSet1.Polzovateli);
            // TODO: This line of code loads data into the 'u37_15DataSet1.Tkani' table. You can move, or remove it, as needed.

            FillListZakaz();
        }

        /// <summary>
        /// открыть форму для нечеткого поиска
        /// </summary>
        private void btnProfilPolzovatel_Click(object sender, EventArgs e)
        {
            FormProfile frmprof = new FormProfile();
            frmprof.bsPolzovatel.Filter = this.bsPolzovatel.Filter;
            if(frmprof.ShowDialog() == DialogResult.OK)
            {
                this.polzovateliTableAdapter.Fill(this.u37_15DataSet1.Polzovateli);
            }
        }

        private void btnNechetPoisk_Click(object sender, EventArgs e)
        {
            FormPoiskLewen frmLeven = new FormPoiskLewen();

            frmLeven.ShowDialog();
        }

        private void btnNewZakaz_Click(object sender, EventArgs e)
        {
            FormNewZakaz frm = new FormNewZakaz();

            frm.idZakazchik = lblIdUser.Text;

            if(frm.ShowDialog() == DialogResult.OK)
            {
                FillListZakaz();
            }
        }
    }
}
