﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using ClassLibrary1;

namespace SUBD_ShvejnayaFabrika
{
    public partial class FormProfile : Form
    {
        public FormProfile()
        {
            InitializeComponent();
        }

        private void FormProfile_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'u37_15DataSet1.Polzovateli' table. You can move, or remove it, as needed.
            this.polzovateliTableAdapter.Fill(this.u37_15DataSet1.Polzovateli);

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if(tbxOldPass.Text != labelPass.Text)
            {
                MessageBox.Show("Вы ввели не верный текущий пароль", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if(tbxNewPass.Text != "")
            {
                if (!ClassCheckPass.CheckPass(tbxNewPass.Text))
                {
                    MessageBox.Show("Пароль не соответствует требованиям", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                labelPass.Text = tbxNewPass.Text;
            }

            bsPolzovatel.EndEdit();
            this.polzovateliTableAdapter.Update(this.u37_15DataSet1.Polzovateli);

            this.DialogResult = DialogResult.OK;



            Close();
        }

        private void cbxShowPass_CheckedChanged(object sender, EventArgs e)
        {
            tbxNewPass.UseSystemPasswordChar = !cbxShowPass.Checked;

            tbxOldPass.UseSystemPasswordChar = !cbxShowPass.Checked;
        }
    }
}
