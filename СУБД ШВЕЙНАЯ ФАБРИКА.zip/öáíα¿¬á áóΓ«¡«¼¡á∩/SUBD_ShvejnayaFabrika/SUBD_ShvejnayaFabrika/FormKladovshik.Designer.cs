﻿namespace SUBD_ShvejnayaFabrika
{
    partial class FormKladovshik
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label famLabel;
            System.Windows.Forms.Label nameLabel;
            System.Windows.Forms.Label otchLabel;
            System.Windows.Forms.Label label6;
            System.Windows.Forms.Label label2;
            System.Windows.Forms.Label primechanieLabel;
            System.Windows.Forms.Label dlinaLabel;
            System.Windows.Forms.Label shirinaLabel;
            System.Windows.Forms.Label colorTkanLabel;
            System.Windows.Forms.Label nazvanieTkanLabel;
            System.Windows.Forms.Label idTkanLabel;
            this.btnProfilPolzovatel = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.u37_15DataSet1 = new SUBD_ShvejnayaFabrika.u37_15DataSet();
            this.bsPolzovatel = new System.Windows.Forms.BindingSource(this.components);
            this.polzovateliTableAdapter = new SUBD_ShvejnayaFabrika.u37_15DataSetTableAdapters.PolzovateliTableAdapter();
            this.tableAdapterManager = new SUBD_ShvejnayaFabrika.u37_15DataSetTableAdapters.TableAdapterManager();
            this.famLabel1 = new System.Windows.Forms.Label();
            this.nameLabel1 = new System.Windows.Forms.Label();
            this.otchLabel1 = new System.Windows.Forms.Label();
            this.btnPrintatMaterial = new System.Windows.Forms.Button();
            this.btnSpisMaterial = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.dgvZakazy = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LVFurnitura = new System.Windows.Forms.ListView();
            this.LVTkan = new System.Windows.Forms.ListView();
            this.tbxNazvFurnitura = new System.Windows.Forms.TextBox();
            this.tbxKolVoFurnitura = new System.Windows.Forms.TextBox();
            this.primechanieTextBox = new System.Windows.Forms.TextBox();
            this.dlinaTextBox = new System.Windows.Forms.TextBox();
            this.shirinaTextBox = new System.Windows.Forms.TextBox();
            this.colorTkanTextBox = new System.Windows.Forms.TextBox();
            this.nazvanieTkanTextBox = new System.Windows.Forms.TextBox();
            this.lblIDUser = new System.Windows.Forms.Label();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.imageListFur = new System.Windows.Forms.ImageList(this.components);
            this.tkaniBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tkaniTableAdapter = new SUBD_ShvejnayaFabrika.u37_15DataSetTableAdapters.TkaniTableAdapter();
            famLabel = new System.Windows.Forms.Label();
            nameLabel = new System.Windows.Forms.Label();
            otchLabel = new System.Windows.Forms.Label();
            label6 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            primechanieLabel = new System.Windows.Forms.Label();
            dlinaLabel = new System.Windows.Forms.Label();
            shirinaLabel = new System.Windows.Forms.Label();
            colorTkanLabel = new System.Windows.Forms.Label();
            nazvanieTkanLabel = new System.Windows.Forms.Label();
            idTkanLabel = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.u37_15DataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsPolzovatel)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvZakazy)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tkaniBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // famLabel
            // 
            famLabel.AutoSize = true;
            famLabel.Location = new System.Drawing.Point(27, 151);
            famLabel.Name = "famLabel";
            famLabel.Size = new System.Drawing.Size(0, 13);
            famLabel.TabIndex = 18;
            // 
            // nameLabel
            // 
            nameLabel.AutoSize = true;
            nameLabel.Location = new System.Drawing.Point(36, 185);
            nameLabel.Name = "nameLabel";
            nameLabel.Size = new System.Drawing.Size(0, 13);
            nameLabel.TabIndex = 19;
            // 
            // otchLabel
            // 
            otchLabel.AutoSize = true;
            otchLabel.Location = new System.Drawing.Point(49, 221);
            otchLabel.Name = "otchLabel";
            otchLabel.Size = new System.Drawing.Size(0, 13);
            otchLabel.TabIndex = 20;
            // 
            // btnProfilPolzovatel
            // 
            this.btnProfilPolzovatel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(156)))), ((int)(((byte)(26)))));
            this.btnProfilPolzovatel.Location = new System.Drawing.Point(314, 134);
            this.btnProfilPolzovatel.Name = "btnProfilPolzovatel";
            this.btnProfilPolzovatel.Size = new System.Drawing.Size(154, 48);
            this.btnProfilPolzovatel.TabIndex = 18;
            this.btnProfilPolzovatel.Text = "Профиль пользователя";
            this.btnProfilPolzovatel.UseVisualStyleBackColor = false;
            this.btnProfilPolzovatel.Click += new System.EventHandler(this.btnProfilPolzovatel_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1077, 128);
            this.panel1.TabIndex = 13;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(221, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(437, 37);
            this.label1.TabIndex = 1;
            this.label1.Text = "Рабочее место кладовщика";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Left;
            this.pictureBox1.Image = global::SUBD_ShvejnayaFabrika.Properties.Resources.fabric_logo;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(169, 128);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // u37_15DataSet1
            // 
            this.u37_15DataSet1.DataSetName = "u37_15DataSet";
            this.u37_15DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bsPolzovatel
            // 
            this.bsPolzovatel.DataMember = "Polzovateli";
            this.bsPolzovatel.DataSource = this.u37_15DataSet1;
            // 
            // polzovateliTableAdapter
            // 
            this.polzovateliTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.FurnituraTableAdapter = null;
            this.tableAdapterManager.IzdeliyaTableAdapter = null;
            this.tableAdapterManager.PolzovateliTableAdapter = this.polzovateliTableAdapter;
            this.tableAdapterManager.TkaniTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = SUBD_ShvejnayaFabrika.u37_15DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.ZakazyTableAdapter = null;
            // 
            // famLabel1
            // 
            this.famLabel1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsPolzovatel, "Fam", true));
            this.famLabel1.Location = new System.Drawing.Point(12, 151);
            this.famLabel1.Name = "famLabel1";
            this.famLabel1.Size = new System.Drawing.Size(100, 23);
            this.famLabel1.TabIndex = 19;
            this.famLabel1.Text = "label2";
            // 
            // nameLabel1
            // 
            this.nameLabel1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsPolzovatel, "Name", true));
            this.nameLabel1.Location = new System.Drawing.Point(69, 151);
            this.nameLabel1.Name = "nameLabel1";
            this.nameLabel1.Size = new System.Drawing.Size(100, 23);
            this.nameLabel1.TabIndex = 20;
            this.nameLabel1.Text = "label2";
            // 
            // otchLabel1
            // 
            this.otchLabel1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsPolzovatel, "Otch", true));
            this.otchLabel1.Location = new System.Drawing.Point(131, 151);
            this.otchLabel1.Name = "otchLabel1";
            this.otchLabel1.Size = new System.Drawing.Size(100, 23);
            this.otchLabel1.TabIndex = 21;
            this.otchLabel1.Text = "label2";
            // 
            // btnPrintatMaterial
            // 
            this.btnPrintatMaterial.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(156)))), ((int)(((byte)(26)))));
            this.btnPrintatMaterial.Location = new System.Drawing.Point(474, 134);
            this.btnPrintatMaterial.Name = "btnPrintatMaterial";
            this.btnPrintatMaterial.Size = new System.Drawing.Size(154, 48);
            this.btnPrintatMaterial.TabIndex = 22;
            this.btnPrintatMaterial.Text = "Принять материалы\r\n";
            this.btnPrintatMaterial.UseVisualStyleBackColor = false;
            this.btnPrintatMaterial.Click += new System.EventHandler(this.btnPrintatMaterial_Click);
            // 
            // btnSpisMaterial
            // 
            this.btnSpisMaterial.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(156)))), ((int)(((byte)(26)))));
            this.btnSpisMaterial.Location = new System.Drawing.Point(634, 134);
            this.btnSpisMaterial.Name = "btnSpisMaterial";
            this.btnSpisMaterial.Size = new System.Drawing.Size(154, 48);
            this.btnSpisMaterial.TabIndex = 23;
            this.btnSpisMaterial.Text = "Списать материалы\r\n";
            this.btnSpisMaterial.UseVisualStyleBackColor = false;
            this.btnSpisMaterial.Click += new System.EventHandler(this.btnSpisMaterial_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(15, 200);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(892, 363);
            this.tabControl1.TabIndex = 24;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dgvZakazy);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(884, 337);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Заказы";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.AutoScroll = true;
            this.tabPage2.Controls.Add(primechanieLabel);
            this.tabPage2.Controls.Add(this.primechanieTextBox);
            this.tabPage2.Controls.Add(dlinaLabel);
            this.tabPage2.Controls.Add(this.dlinaTextBox);
            this.tabPage2.Controls.Add(shirinaLabel);
            this.tabPage2.Controls.Add(this.shirinaTextBox);
            this.tabPage2.Controls.Add(colorTkanLabel);
            this.tabPage2.Controls.Add(this.colorTkanTextBox);
            this.tabPage2.Controls.Add(nazvanieTkanLabel);
            this.tabPage2.Controls.Add(this.nazvanieTkanTextBox);
            this.tabPage2.Controls.Add(this.LVTkan);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(884, 337);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Ткани ";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(label6);
            this.tabPage3.Controls.Add(this.tbxNazvFurnitura);
            this.tabPage3.Controls.Add(label2);
            this.tabPage3.Controls.Add(this.tbxKolVoFurnitura);
            this.tabPage3.Controls.Add(this.LVFurnitura);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(884, 337);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Фурнитура";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // dgvZakazy
            // 
            this.dgvZakazy.AllowUserToAddRows = false;
            this.dgvZakazy.AllowUserToDeleteRows = false;
            this.dgvZakazy.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvZakazy.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Column7});
            this.dgvZakazy.Location = new System.Drawing.Point(11, 8);
            this.dgvZakazy.Name = "dgvZakazy";
            this.dgvZakazy.ReadOnly = true;
            this.dgvZakazy.RowHeadersVisible = false;
            this.dgvZakazy.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvZakazy.Size = new System.Drawing.Size(716, 276);
            this.dgvZakazy.TabIndex = 12;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Изделие";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Кол-во изделий";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Ткань";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Фурнитура";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "Кол-во фурнитуры";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "Менеджер";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            // 
            // Column7
            // 
            this.Column7.HeaderText = "Заказчик";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            // 
            // LVFurnitura
            // 
            this.LVFurnitura.Dock = System.Windows.Forms.DockStyle.Left;
            this.LVFurnitura.LargeImageList = this.imageListFur;
            this.LVFurnitura.Location = new System.Drawing.Point(3, 3);
            this.LVFurnitura.Name = "LVFurnitura";
            this.LVFurnitura.Size = new System.Drawing.Size(576, 331);
            this.LVFurnitura.TabIndex = 12;
            this.LVFurnitura.UseCompatibleStateImageBehavior = false;
            this.LVFurnitura.SelectedIndexChanged += new System.EventHandler(this.LVFurnitura_SelectedIndexChanged);
            // 
            // LVTkan
            // 
            this.LVTkan.Dock = System.Windows.Forms.DockStyle.Left;
            this.LVTkan.LargeImageList = this.imageList1;
            this.LVTkan.Location = new System.Drawing.Point(3, 3);
            this.LVTkan.Name = "LVTkan";
            this.LVTkan.Size = new System.Drawing.Size(576, 331);
            this.LVTkan.TabIndex = 12;
            this.LVTkan.UseCompatibleStateImageBehavior = false;
            this.LVTkan.SelectedIndexChanged += new System.EventHandler(this.LVTkan_SelectedIndexChanged);
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new System.Drawing.Point(624, 20);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(118, 13);
            label6.TabIndex = 22;
            label6.Text = "Название фурнитуры:";
            // 
            // tbxNazvFurnitura
            // 
            this.tbxNazvFurnitura.Location = new System.Drawing.Point(748, 17);
            this.tbxNazvFurnitura.Name = "tbxNazvFurnitura";
            this.tbxNazvFurnitura.ReadOnly = true;
            this.tbxNazvFurnitura.Size = new System.Drawing.Size(130, 20);
            this.tbxNazvFurnitura.TabIndex = 23;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(624, 65);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(102, 13);
            label2.TabIndex = 20;
            label2.Text = "Кол-во фурнитуры:";
            // 
            // tbxKolVoFurnitura
            // 
            this.tbxKolVoFurnitura.Location = new System.Drawing.Point(748, 62);
            this.tbxKolVoFurnitura.Name = "tbxKolVoFurnitura";
            this.tbxKolVoFurnitura.ReadOnly = true;
            this.tbxKolVoFurnitura.Size = new System.Drawing.Size(130, 20);
            this.tbxKolVoFurnitura.TabIndex = 21;
            // 
            // primechanieLabel
            // 
            primechanieLabel.AutoSize = true;
            primechanieLabel.Location = new System.Drawing.Point(618, 203);
            primechanieLabel.Name = "primechanieLabel";
            primechanieLabel.Size = new System.Drawing.Size(73, 13);
            primechanieLabel.TabIndex = 21;
            primechanieLabel.Text = "Примечание:";
            // 
            // primechanieTextBox
            // 
            this.primechanieTextBox.Location = new System.Drawing.Point(716, 200);
            this.primechanieTextBox.Name = "primechanieTextBox";
            this.primechanieTextBox.ReadOnly = true;
            this.primechanieTextBox.Size = new System.Drawing.Size(130, 20);
            this.primechanieTextBox.TabIndex = 22;
            // 
            // dlinaLabel
            // 
            dlinaLabel.AutoSize = true;
            dlinaLabel.Location = new System.Drawing.Point(618, 157);
            dlinaLabel.Name = "dlinaLabel";
            dlinaLabel.Size = new System.Drawing.Size(43, 13);
            dlinaLabel.TabIndex = 19;
            dlinaLabel.Text = "Длина:";
            // 
            // dlinaTextBox
            // 
            this.dlinaTextBox.Location = new System.Drawing.Point(716, 157);
            this.dlinaTextBox.Name = "dlinaTextBox";
            this.dlinaTextBox.ReadOnly = true;
            this.dlinaTextBox.Size = new System.Drawing.Size(130, 20);
            this.dlinaTextBox.TabIndex = 20;
            // 
            // shirinaLabel
            // 
            shirinaLabel.AutoSize = true;
            shirinaLabel.Location = new System.Drawing.Point(618, 113);
            shirinaLabel.Name = "shirinaLabel";
            shirinaLabel.Size = new System.Drawing.Size(49, 13);
            shirinaLabel.TabIndex = 17;
            shirinaLabel.Text = "Ширина:";
            // 
            // shirinaTextBox
            // 
            this.shirinaTextBox.Location = new System.Drawing.Point(716, 110);
            this.shirinaTextBox.Name = "shirinaTextBox";
            this.shirinaTextBox.ReadOnly = true;
            this.shirinaTextBox.Size = new System.Drawing.Size(130, 20);
            this.shirinaTextBox.TabIndex = 18;
            // 
            // colorTkanLabel
            // 
            colorTkanLabel.AutoSize = true;
            colorTkanLabel.Location = new System.Drawing.Point(618, 69);
            colorTkanLabel.Name = "colorTkanLabel";
            colorTkanLabel.Size = new System.Drawing.Size(67, 13);
            colorTkanLabel.TabIndex = 15;
            colorTkanLabel.Text = "Цвет ткани:";
            // 
            // colorTkanTextBox
            // 
            this.colorTkanTextBox.Location = new System.Drawing.Point(716, 62);
            this.colorTkanTextBox.Name = "colorTkanTextBox";
            this.colorTkanTextBox.ReadOnly = true;
            this.colorTkanTextBox.Size = new System.Drawing.Size(130, 20);
            this.colorTkanTextBox.TabIndex = 16;
            // 
            // nazvanieTkanLabel
            // 
            nazvanieTkanLabel.AutoSize = true;
            nazvanieTkanLabel.Location = new System.Drawing.Point(618, 22);
            nazvanieTkanLabel.Name = "nazvanieTkanLabel";
            nazvanieTkanLabel.Size = new System.Drawing.Size(92, 13);
            nazvanieTkanLabel.TabIndex = 13;
            nazvanieTkanLabel.Text = "Название ткани:";
            // 
            // nazvanieTkanTextBox
            // 
            this.nazvanieTkanTextBox.Location = new System.Drawing.Point(716, 19);
            this.nazvanieTkanTextBox.Name = "nazvanieTkanTextBox";
            this.nazvanieTkanTextBox.ReadOnly = true;
            this.nazvanieTkanTextBox.Size = new System.Drawing.Size(130, 20);
            this.nazvanieTkanTextBox.TabIndex = 14;
            // 
            // lblIDUser
            // 
            this.lblIDUser.AutoSize = true;
            this.lblIDUser.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsPolzovatel, "idPolzovatel", true));
            this.lblIDUser.Location = new System.Drawing.Point(940, 222);
            this.lblIDUser.Name = "lblIDUser";
            this.lblIDUser.Size = new System.Drawing.Size(44, 13);
            this.lblIDUser.TabIndex = 25;
            this.lblIDUser.Text = "sadfdas";
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(100, 100);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // imageListFur
            // 
            this.imageListFur.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
            this.imageListFur.ImageSize = new System.Drawing.Size(100, 100);
            this.imageListFur.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // tkaniBindingSource
            // 
            this.tkaniBindingSource.DataMember = "Tkani";
            this.tkaniBindingSource.DataSource = this.u37_15DataSet1;
            // 
            // tkaniTableAdapter
            // 
            this.tkaniTableAdapter.ClearBeforeFill = true;
            // 
            // idTkanLabel
            // 
            idTkanLabel.AutoSize = true;
            idTkanLabel.Location = new System.Drawing.Point(925, 398);
            idTkanLabel.Name = "idTkanLabel";
            idTkanLabel.Size = new System.Drawing.Size(10, 13);
            idTkanLabel.TabIndex = 22;
            idTkanLabel.Text = " ";
            // 
            // FormKladovshik
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1077, 575);
            this.Controls.Add(idTkanLabel);
            this.Controls.Add(this.lblIDUser);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.btnSpisMaterial);
            this.Controls.Add(this.btnPrintatMaterial);
            this.Controls.Add(otchLabel);
            this.Controls.Add(this.otchLabel1);
            this.Controls.Add(nameLabel);
            this.Controls.Add(this.nameLabel1);
            this.Controls.Add(famLabel);
            this.Controls.Add(this.famLabel1);
            this.Controls.Add(this.btnProfilPolzovatel);
            this.Controls.Add(this.panel1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormKladovshik";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Рабочее место кладовщика";
            this.Load += new System.EventHandler(this.FormKladovshik_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.u37_15DataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsPolzovatel)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvZakazy)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tkaniBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnProfilPolzovatel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private u37_15DataSet u37_15DataSet1;
        private u37_15DataSetTableAdapters.PolzovateliTableAdapter polzovateliTableAdapter;
        private u37_15DataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.Label famLabel1;
        private System.Windows.Forms.Label nameLabel1;
        private System.Windows.Forms.Label otchLabel1;
        public System.Windows.Forms.BindingSource bsPolzovatel;
        private System.Windows.Forms.Button btnPrintatMaterial;
        private System.Windows.Forms.Button btnSpisMaterial;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView dgvZakazy;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.ListView LVTkan;
        private System.Windows.Forms.ListView LVFurnitura;
        private System.Windows.Forms.TextBox tbxNazvFurnitura;
        private System.Windows.Forms.TextBox tbxKolVoFurnitura;
        private System.Windows.Forms.TextBox primechanieTextBox;
        public System.Windows.Forms.TextBox dlinaTextBox;
        public System.Windows.Forms.TextBox shirinaTextBox;
        private System.Windows.Forms.TextBox colorTkanTextBox;
        private System.Windows.Forms.TextBox nazvanieTkanTextBox;
        private System.Windows.Forms.Label lblIDUser;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.ImageList imageListFur;
        private System.Windows.Forms.BindingSource tkaniBindingSource;
        private u37_15DataSetTableAdapters.TkaniTableAdapter tkaniTableAdapter;
    }
}