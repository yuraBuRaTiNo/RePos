﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SUBD_ShvejnayaFabrika
{
    public partial class FormGetMaterial : Form
    {
        public FormGetMaterial()
        {
            InitializeComponent();
        }

        List<Tkani> lstTkani = new List<Tkani>();

        public struct Tkani
        {
            public string nazvanie, cvet, primech, shirina, dlina;

            public Image PhotoTkan;
        }

        List<Furnitura> lstFurnitura = new List<Furnitura>();

        public struct Furnitura
        {
            public string namefur, counfur;

            public Image PhotoFurnitura;
        }

        private void btnLoadPhoto_Click(object sender, EventArgs e)
        {
            try
            {
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                    pbxPhoto.Image = Image.FromFile(openFileDialog1.FileName);
            }
            catch
            {

            }
        }

        private void btnClearPhoto_Click(object sender, EventArgs e)
        {
            DialogResult res = MessageBox.Show("Очистить фото?", "Внимание!", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (res == DialogResult.Yes)
                pbxPhoto.Image = null;
        }

        private void btnAddTkanDokyment_Click(object sender, EventArgs e)
        {
            Tkani tk = new Tkani();

            tk.nazvanie = tbxNameTkan.Text;
            tk.dlina = tbxDlinaTkan.Text;
            tk.cvet = tbxCvetTkan.Text;
            tk.shirina = tbxShirinaTkan.Text;
            tk.primech = tbxOpisanie.Text;

            if(pbxPhoto.Image != null)
            {
                tk.PhotoTkan = pbxPhoto.Image;
            }
            else
            {
                tk.PhotoTkan = Properties.Resources.tmp;
            }

            lstTkani.Add(tk);

            dgvDock.Rows.Add(tbxNameTkan.Text, tbxShirinaTkan.Text, tbxCvetTkan.Text, tbxDlinaTkan.Text,  tbxOpisanie.Text );
        }

        private void btnDelTkanDock_Click(object sender, EventArgs e)
        {
            int cr = -1;

            if(dgvDock.MultiSelect)
            {
                foreach (DataGridViewRow dgw in dgvDock.SelectedRows)
                {
                    MessageBox.Show("Удалить записи?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    dgvDock.Rows.Remove(dgw);
                }
            }
            else
            {
                try
                {
                    cr = dgvDock.CurrentRow.Index;
                }
                catch
                {
                    if (cr == -1)
                    {
                        MessageBox.Show("Не выбрана ни одно ткань");
                        return;
                    }
                }

                MessageBox.Show("Удалить запись?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question);


                lstTkani.RemoveAt(cr);

                dgvDock.Rows.RemoveAt(cr);
            }


           
        }

        private void btnPrinyatDockYchet_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(Properties.Settings.Default.u37_15ConnectionString);

            foreach(Tkani tk1 in lstTkani)
            {
                con.Open();

                //добавить в таблицу ткани очередную ткань


                string t = string.Format(@"insert into Tkani(nazvanietkan, colortkan, shirina, dlina, primechanie, photo)
                                                    values('{0}','{1}', '{2}', '{3}', '{4}', @photo)",  
                                                    tk1.nazvanie, tk1.cvet, tk1.shirina, tk1.dlina, tk1.primech);

                SqlCommand q1 = new SqlCommand(t, con);

                MemoryStream ms = new MemoryStream();

                tk1.PhotoTkan.Save(ms, ImageFormat.Jpeg);

                q1.Parameters.AddWithValue("@photo", ms.ToArray());

                q1.ExecuteNonQuery();

                con.Close();
            }

            foreach(Furnitura FR in lstFurnitura)
            {
                con.Open();

                string t = string.Format(@"insert into furnitura(namefur, countfur, photo)
                                                    values('{0}','{1}', @photo)",
                                                    FR.namefur, FR.counfur);

                SqlCommand q1 = new SqlCommand(t, con);

                MemoryStream ms = new MemoryStream();

                FR.PhotoFurnitura.Save(ms, ImageFormat.Jpeg);

                q1.Parameters.AddWithValue("@photo", ms.ToArray());

                q1.ExecuteNonQuery();

                con.Close();
            }

            MessageBox.Show("Документ принят к учету", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close();
        }

        //фурнитура
        private void btnLoadPhotoFur_Click(object sender, EventArgs e)
        {
            try
            {
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                    pbxPhotoFur.Image = Image.FromFile(openFileDialog1.FileName);
            }
            catch
            {

            }
        }

        private void btnClearPhotoFur_Click(object sender, EventArgs e)
        {
            DialogResult res = MessageBox.Show("Очистить фото?", "Внимание!", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (res == DialogResult.Yes)
                pbxPhotoFur.Image = null;
        }

        private void btnAddFurDock_Click(object sender, EventArgs e)
        {
            Furnitura FR= new Furnitura();

            FR.namefur = tbxNameFur.Text;
            FR.counfur = tbxCountFur.Text;
           

            if (pbxPhotoFur.Image != null)
            {
                FR.PhotoFurnitura = pbxPhotoFur.Image;
            }
            else
            {
                FR.PhotoFurnitura = Properties.Resources.tmp;
            }

            lstFurnitura.Add(FR);

            dgvDockFur.Rows.Add(tbxNameFur.Text, tbxCountFur.Text);
        }

        private void btnDelFurDock_Click(object sender, EventArgs e)
        {
            int cr = -1;

            try
            {
                cr = dgvDockFur.CurrentRow.Index;
            }
            catch
            {
                if (cr == -1)
                {
                    MessageBox.Show("Не выбрана ни одно ткань");
                    return;
                }
            }

            MessageBox.Show("Удалить запись?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question);


            lstFurnitura.RemoveAt(cr);

            dgvDockFur.Rows.RemoveAt(cr);
        }
    }
}
