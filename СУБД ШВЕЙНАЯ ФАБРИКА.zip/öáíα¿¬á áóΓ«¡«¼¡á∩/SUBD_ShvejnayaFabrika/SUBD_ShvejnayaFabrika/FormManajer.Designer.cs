﻿namespace SUBD_ShvejnayaFabrika
{
    partial class FormManajer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label famLabel;
            System.Windows.Forms.Label nameLabel;
            System.Windows.Forms.Label otchLabel;
            System.Windows.Forms.Label nazvanieIzdeliyaLabel;
            System.Windows.Forms.Label dlinaLabel;
            System.Windows.Forms.Label shirinaLabel;
            System.Windows.Forms.Label primechanieLabel;
            System.Windows.Forms.Label colorTkanLabel;
            System.Windows.Forms.Label nazvanieTkanLabel;
            System.Windows.Forms.Label label6;
            System.Windows.Forms.Label label4;
            System.Windows.Forms.Label label2;
            System.Windows.Forms.Label label3;
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnProfilPolzovatel = new System.Windows.Forms.Button();
            this.u37_15DataSet1 = new SUBD_ShvejnayaFabrika.u37_15DataSet();
            this.bsPolzovatel = new System.Windows.Forms.BindingSource(this.components);
            this.polzovateliTableAdapter = new SUBD_ShvejnayaFabrika.u37_15DataSetTableAdapters.PolzovateliTableAdapter();
            this.tableAdapterManager = new SUBD_ShvejnayaFabrika.u37_15DataSetTableAdapters.TableAdapterManager();
            this.famLabel1 = new System.Windows.Forms.Label();
            this.nameLabel1 = new System.Windows.Forms.Label();
            this.otchLabel1 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dgvZakazy = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnEksportNeAll = new System.Windows.Forms.Button();
            this.btnEksportAll = new System.Windows.Forms.Button();
            this.rbtCSV = new System.Windows.Forms.RadioButton();
            this.rbtWord = new System.Windows.Forms.RadioButton();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tbxDlina = new System.Windows.Forms.TextBox();
            this.tbxShirina = new System.Windows.Forms.TextBox();
            this.primechanieTextBox = new System.Windows.Forms.TextBox();
            this.colorTkanTextBox = new System.Windows.Forms.TextBox();
            this.nazvanieTkanTextBox = new System.Windows.Forms.TextBox();
            this.LVTkani = new System.Windows.Forms.ListView();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tbxNazvFurnitura = new System.Windows.Forms.TextBox();
            this.tbxKolVoFurnitura = new System.Windows.Forms.TextBox();
            this.LVFurnitura = new System.Windows.Forms.ListView();
            this.imageListFur = new System.Windows.Forms.ImageList(this.components);
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnRedakt = new System.Windows.Forms.Button();
            this.btnnDobavit = new System.Windows.Forms.Button();
            this.shirinaTextBox = new System.Windows.Forms.TextBox();
            this.bsIzdeliya = new System.Windows.Forms.BindingSource(this.components);
            this.dlinaTextBox = new System.Windows.Forms.TextBox();
            this.nazvanieIzdeliyaTextBox = new System.Windows.Forms.TextBox();
            this.dgvIzdeliya = new System.Windows.Forms.DataGridView();
            this.NazvanieIzdeliya = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idIzdeliyaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nazvanieIzdeliyaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dlinaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.shirinaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.izdeliyaTableAdapter = new SUBD_ShvejnayaFabrika.u37_15DataSetTableAdapters.IzdeliyaTableAdapter();
            this.u3715DataSet1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.zakazyBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.zakazyTableAdapter = new SUBD_ShvejnayaFabrika.u37_15DataSetTableAdapters.ZakazyTableAdapter();
            this.lblIdUser = new System.Windows.Forms.Label();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            famLabel = new System.Windows.Forms.Label();
            nameLabel = new System.Windows.Forms.Label();
            otchLabel = new System.Windows.Forms.Label();
            nazvanieIzdeliyaLabel = new System.Windows.Forms.Label();
            dlinaLabel = new System.Windows.Forms.Label();
            shirinaLabel = new System.Windows.Forms.Label();
            primechanieLabel = new System.Windows.Forms.Label();
            colorTkanLabel = new System.Windows.Forms.Label();
            nazvanieTkanLabel = new System.Windows.Forms.Label();
            label6 = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.u37_15DataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsPolzovatel)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvZakazy)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bsIzdeliya)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvIzdeliya)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.u3715DataSet1BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zakazyBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // famLabel
            // 
            famLabel.AutoSize = true;
            famLabel.Location = new System.Drawing.Point(33, 146);
            famLabel.Name = "famLabel";
            famLabel.Size = new System.Drawing.Size(0, 13);
            famLabel.TabIndex = 13;
            // 
            // nameLabel
            // 
            nameLabel.AutoSize = true;
            nameLabel.Location = new System.Drawing.Point(40, 186);
            nameLabel.Name = "nameLabel";
            nameLabel.Size = new System.Drawing.Size(0, 13);
            nameLabel.TabIndex = 14;
            // 
            // otchLabel
            // 
            otchLabel.AutoSize = true;
            otchLabel.Location = new System.Drawing.Point(51, 228);
            otchLabel.Name = "otchLabel";
            otchLabel.Size = new System.Drawing.Size(0, 13);
            otchLabel.TabIndex = 15;
            // 
            // nazvanieIzdeliyaLabel
            // 
            nazvanieIzdeliyaLabel.AutoSize = true;
            nazvanieIzdeliyaLabel.Location = new System.Drawing.Point(248, 48);
            nazvanieIzdeliyaLabel.Name = "nazvanieIzdeliyaLabel";
            nazvanieIzdeliyaLabel.Size = new System.Drawing.Size(105, 13);
            nazvanieIzdeliyaLabel.TabIndex = 1;
            nazvanieIzdeliyaLabel.Text = "Название изделия:";
            // 
            // dlinaLabel
            // 
            dlinaLabel.AutoSize = true;
            dlinaLabel.Location = new System.Drawing.Point(248, 91);
            dlinaLabel.Name = "dlinaLabel";
            dlinaLabel.Size = new System.Drawing.Size(43, 13);
            dlinaLabel.TabIndex = 3;
            dlinaLabel.Text = "Длина:";
            // 
            // shirinaLabel
            // 
            shirinaLabel.AutoSize = true;
            shirinaLabel.Location = new System.Drawing.Point(248, 133);
            shirinaLabel.Name = "shirinaLabel";
            shirinaLabel.Size = new System.Drawing.Size(49, 13);
            shirinaLabel.TabIndex = 5;
            shirinaLabel.Text = "Ширина:";
            // 
            // primechanieLabel
            // 
            primechanieLabel.AutoSize = true;
            primechanieLabel.Location = new System.Drawing.Point(614, 206);
            primechanieLabel.Name = "primechanieLabel";
            primechanieLabel.Size = new System.Drawing.Size(73, 13);
            primechanieLabel.TabIndex = 31;
            primechanieLabel.Text = "Примечание:";
            // 
            // colorTkanLabel
            // 
            colorTkanLabel.AutoSize = true;
            colorTkanLabel.Location = new System.Drawing.Point(614, 72);
            colorTkanLabel.Name = "colorTkanLabel";
            colorTkanLabel.Size = new System.Drawing.Size(67, 13);
            colorTkanLabel.TabIndex = 25;
            colorTkanLabel.Text = "Цвет ткани:";
            // 
            // nazvanieTkanLabel
            // 
            nazvanieTkanLabel.AutoSize = true;
            nazvanieTkanLabel.Location = new System.Drawing.Point(614, 25);
            nazvanieTkanLabel.Name = "nazvanieTkanLabel";
            nazvanieTkanLabel.Size = new System.Drawing.Size(92, 13);
            nazvanieTkanLabel.TabIndex = 23;
            nazvanieTkanLabel.Text = "Название ткани:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new System.Drawing.Point(588, 25);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(118, 13);
            label6.TabIndex = 26;
            label6.Text = "Название фурнитуры:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new System.Drawing.Point(588, 70);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(102, 13);
            label4.TabIndex = 24;
            label4.Text = "Кол-во фурнитуры:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(614, 153);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(43, 13);
            label2.TabIndex = 35;
            label2.Text = "Длина:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new System.Drawing.Point(614, 109);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(49, 13);
            label3.TabIndex = 33;
            label3.Text = "Ширина:";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(883, 128);
            this.panel1.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(221, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(429, 37);
            this.label1.TabIndex = 1;
            this.label1.Text = "Рабочее место менеджера";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Left;
            this.pictureBox1.Image = global::SUBD_ShvejnayaFabrika.Properties.Resources.fabric_logo;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(169, 128);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // btnProfilPolzovatel
            // 
            this.btnProfilPolzovatel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(156)))), ((int)(((byte)(26)))));
            this.btnProfilPolzovatel.Location = new System.Drawing.Point(15, 168);
            this.btnProfilPolzovatel.Name = "btnProfilPolzovatel";
            this.btnProfilPolzovatel.Size = new System.Drawing.Size(157, 48);
            this.btnProfilPolzovatel.TabIndex = 12;
            this.btnProfilPolzovatel.Text = "Профиль пользователя";
            this.btnProfilPolzovatel.UseVisualStyleBackColor = false;
            this.btnProfilPolzovatel.Click += new System.EventHandler(this.btnProfilPolzovatel_Click);
            // 
            // u37_15DataSet1
            // 
            this.u37_15DataSet1.DataSetName = "u37_15DataSet";
            this.u37_15DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bsPolzovatel
            // 
            this.bsPolzovatel.DataMember = "Polzovateli";
            this.bsPolzovatel.DataSource = this.u37_15DataSet1;
            // 
            // polzovateliTableAdapter
            // 
            this.polzovateliTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.FurnituraTableAdapter = null;
            this.tableAdapterManager.IzdeliyaTableAdapter = null;
            this.tableAdapterManager.PolzovateliTableAdapter = this.polzovateliTableAdapter;
            this.tableAdapterManager.TkaniTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = SUBD_ShvejnayaFabrika.u37_15DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.ZakazyTableAdapter = null;
            // 
            // famLabel1
            // 
            this.famLabel1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsPolzovatel, "Fam", true));
            this.famLabel1.Location = new System.Drawing.Point(12, 136);
            this.famLabel1.Name = "famLabel1";
            this.famLabel1.Size = new System.Drawing.Size(100, 23);
            this.famLabel1.TabIndex = 14;
            this.famLabel1.Text = "label2";
            // 
            // nameLabel1
            // 
            this.nameLabel1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsPolzovatel, "Name", true));
            this.nameLabel1.Location = new System.Drawing.Point(100, 136);
            this.nameLabel1.Name = "nameLabel1";
            this.nameLabel1.Size = new System.Drawing.Size(100, 23);
            this.nameLabel1.TabIndex = 15;
            this.nameLabel1.Text = "label2";
            // 
            // otchLabel1
            // 
            this.otchLabel1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsPolzovatel, "Otch", true));
            this.otchLabel1.Location = new System.Drawing.Point(194, 136);
            this.otchLabel1.Name = "otchLabel1";
            this.otchLabel1.Size = new System.Drawing.Size(100, 23);
            this.otchLabel1.TabIndex = 16;
            this.otchLabel1.Text = "label2";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Location = new System.Drawing.Point(13, 228);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(858, 334);
            this.tabControl1.TabIndex = 17;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dgvZakazy);
            this.tabPage1.Controls.Add(this.btnEksportNeAll);
            this.tabPage1.Controls.Add(this.btnEksportAll);
            this.tabPage1.Controls.Add(this.rbtCSV);
            this.tabPage1.Controls.Add(this.rbtWord);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(850, 308);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Заказы ";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // dgvZakazy
            // 
            this.dgvZakazy.AllowUserToAddRows = false;
            this.dgvZakazy.AllowUserToDeleteRows = false;
            this.dgvZakazy.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvZakazy.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6});
            this.dgvZakazy.Location = new System.Drawing.Point(182, 6);
            this.dgvZakazy.Name = "dgvZakazy";
            this.dgvZakazy.ReadOnly = true;
            this.dgvZakazy.RowHeadersVisible = false;
            this.dgvZakazy.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvZakazy.Size = new System.Drawing.Size(660, 296);
            this.dgvZakazy.TabIndex = 15;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Изделие";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Кол-во изделий";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Ткань";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Фурнитура";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "Кол-во фурнитуры";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "Заказчик";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            // 
            // btnEksportNeAll
            // 
            this.btnEksportNeAll.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(156)))), ((int)(((byte)(26)))));
            this.btnEksportNeAll.Location = new System.Drawing.Point(19, 171);
            this.btnEksportNeAll.Name = "btnEksportNeAll";
            this.btnEksportNeAll.Size = new System.Drawing.Size(157, 48);
            this.btnEksportNeAll.TabIndex = 14;
            this.btnEksportNeAll.Text = "Экспортировать выделенные заказы";
            this.btnEksportNeAll.UseVisualStyleBackColor = false;
            this.btnEksportNeAll.Click += new System.EventHandler(this.btnEksportNeAll_Click);
            // 
            // btnEksportAll
            // 
            this.btnEksportAll.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(156)))), ((int)(((byte)(26)))));
            this.btnEksportAll.Location = new System.Drawing.Point(19, 117);
            this.btnEksportAll.Name = "btnEksportAll";
            this.btnEksportAll.Size = new System.Drawing.Size(157, 48);
            this.btnEksportAll.TabIndex = 13;
            this.btnEksportAll.Text = "Экспортировать все заказы";
            this.btnEksportAll.UseVisualStyleBackColor = false;
            this.btnEksportAll.Click += new System.EventHandler(this.btnEksportAll_Click);
            // 
            // rbtCSV
            // 
            this.rbtCSV.AutoSize = true;
            this.rbtCSV.Location = new System.Drawing.Point(19, 74);
            this.rbtCSV.Name = "rbtCSV";
            this.rbtCSV.Size = new System.Drawing.Size(55, 17);
            this.rbtCSV.TabIndex = 1;
            this.rbtCSV.Text = "в CSV";
            this.rbtCSV.UseVisualStyleBackColor = true;
            // 
            // rbtWord
            // 
            this.rbtWord.AutoSize = true;
            this.rbtWord.Checked = true;
            this.rbtWord.Location = new System.Drawing.Point(19, 38);
            this.rbtWord.Name = "rbtWord";
            this.rbtWord.Size = new System.Drawing.Size(60, 17);
            this.rbtWord.TabIndex = 0;
            this.rbtWord.TabStop = true;
            this.rbtWord.Text = "в Word";
            this.rbtWord.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(label2);
            this.tabPage2.Controls.Add(this.tbxDlina);
            this.tabPage2.Controls.Add(label3);
            this.tabPage2.Controls.Add(this.tbxShirina);
            this.tabPage2.Controls.Add(primechanieLabel);
            this.tabPage2.Controls.Add(this.primechanieTextBox);
            this.tabPage2.Controls.Add(colorTkanLabel);
            this.tabPage2.Controls.Add(this.colorTkanTextBox);
            this.tabPage2.Controls.Add(nazvanieTkanLabel);
            this.tabPage2.Controls.Add(this.nazvanieTkanTextBox);
            this.tabPage2.Controls.Add(this.LVTkani);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(850, 308);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Ткани ";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tbxDlina
            // 
            this.tbxDlina.Location = new System.Drawing.Point(712, 153);
            this.tbxDlina.Name = "tbxDlina";
            this.tbxDlina.ReadOnly = true;
            this.tbxDlina.Size = new System.Drawing.Size(130, 20);
            this.tbxDlina.TabIndex = 36;
            // 
            // tbxShirina
            // 
            this.tbxShirina.Location = new System.Drawing.Point(712, 106);
            this.tbxShirina.Name = "tbxShirina";
            this.tbxShirina.ReadOnly = true;
            this.tbxShirina.Size = new System.Drawing.Size(130, 20);
            this.tbxShirina.TabIndex = 34;
            // 
            // primechanieTextBox
            // 
            this.primechanieTextBox.Location = new System.Drawing.Point(712, 203);
            this.primechanieTextBox.Name = "primechanieTextBox";
            this.primechanieTextBox.ReadOnly = true;
            this.primechanieTextBox.Size = new System.Drawing.Size(130, 20);
            this.primechanieTextBox.TabIndex = 32;
            // 
            // colorTkanTextBox
            // 
            this.colorTkanTextBox.Location = new System.Drawing.Point(712, 65);
            this.colorTkanTextBox.Name = "colorTkanTextBox";
            this.colorTkanTextBox.ReadOnly = true;
            this.colorTkanTextBox.Size = new System.Drawing.Size(130, 20);
            this.colorTkanTextBox.TabIndex = 26;
            // 
            // nazvanieTkanTextBox
            // 
            this.nazvanieTkanTextBox.Location = new System.Drawing.Point(712, 22);
            this.nazvanieTkanTextBox.Name = "nazvanieTkanTextBox";
            this.nazvanieTkanTextBox.ReadOnly = true;
            this.nazvanieTkanTextBox.Size = new System.Drawing.Size(130, 20);
            this.nazvanieTkanTextBox.TabIndex = 24;
            // 
            // LVTkani
            // 
            this.LVTkani.LargeImageList = this.imageList1;
            this.LVTkani.Location = new System.Drawing.Point(4, 7);
            this.LVTkani.Name = "LVTkani";
            this.LVTkani.Size = new System.Drawing.Size(596, 295);
            this.LVTkani.TabIndex = 0;
            this.LVTkani.UseCompatibleStateImageBehavior = false;
            this.LVTkani.SelectedIndexChanged += new System.EventHandler(this.LVTkani_SelectedIndexChanged);
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(100, 100);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(label6);
            this.tabPage3.Controls.Add(this.tbxNazvFurnitura);
            this.tabPage3.Controls.Add(label4);
            this.tabPage3.Controls.Add(this.tbxKolVoFurnitura);
            this.tabPage3.Controls.Add(this.LVFurnitura);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(850, 308);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Фурнитура ";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // tbxNazvFurnitura
            // 
            this.tbxNazvFurnitura.Location = new System.Drawing.Point(712, 22);
            this.tbxNazvFurnitura.Name = "tbxNazvFurnitura";
            this.tbxNazvFurnitura.ReadOnly = true;
            this.tbxNazvFurnitura.Size = new System.Drawing.Size(130, 20);
            this.tbxNazvFurnitura.TabIndex = 27;
            // 
            // tbxKolVoFurnitura
            // 
            this.tbxKolVoFurnitura.Location = new System.Drawing.Point(712, 67);
            this.tbxKolVoFurnitura.Name = "tbxKolVoFurnitura";
            this.tbxKolVoFurnitura.ReadOnly = true;
            this.tbxKolVoFurnitura.Size = new System.Drawing.Size(130, 20);
            this.tbxKolVoFurnitura.TabIndex = 25;
            // 
            // LVFurnitura
            // 
            this.LVFurnitura.LargeImageList = this.imageListFur;
            this.LVFurnitura.Location = new System.Drawing.Point(4, 7);
            this.LVFurnitura.Name = "LVFurnitura";
            this.LVFurnitura.Size = new System.Drawing.Size(578, 295);
            this.LVFurnitura.TabIndex = 0;
            this.LVFurnitura.UseCompatibleStateImageBehavior = false;
            this.LVFurnitura.SelectedIndexChanged += new System.EventHandler(this.LVFurnitura_SelectedIndexChanged);
            // 
            // imageListFur
            // 
            this.imageListFur.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit;
            this.imageListFur.ImageSize = new System.Drawing.Size(100, 100);
            this.imageListFur.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.btnSave);
            this.tabPage4.Controls.Add(this.btnRedakt);
            this.tabPage4.Controls.Add(this.btnnDobavit);
            this.tabPage4.Controls.Add(shirinaLabel);
            this.tabPage4.Controls.Add(this.shirinaTextBox);
            this.tabPage4.Controls.Add(dlinaLabel);
            this.tabPage4.Controls.Add(this.dlinaTextBox);
            this.tabPage4.Controls.Add(nazvanieIzdeliyaLabel);
            this.tabPage4.Controls.Add(this.nazvanieIzdeliyaTextBox);
            this.tabPage4.Controls.Add(this.dgvIzdeliya);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(850, 308);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Изделия ";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(156)))), ((int)(((byte)(26)))));
            this.btnSave.Enabled = false;
            this.btnSave.Location = new System.Drawing.Point(404, 183);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(157, 48);
            this.btnSave.TabIndex = 15;
            this.btnSave.Text = "Сохранить ";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnRedakt
            // 
            this.btnRedakt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(156)))), ((int)(((byte)(26)))));
            this.btnRedakt.Location = new System.Drawing.Point(241, 210);
            this.btnRedakt.Name = "btnRedakt";
            this.btnRedakt.Size = new System.Drawing.Size(157, 48);
            this.btnRedakt.TabIndex = 14;
            this.btnRedakt.Text = "Редактировать ";
            this.btnRedakt.UseVisualStyleBackColor = false;
            this.btnRedakt.Click += new System.EventHandler(this.btnRedakt_Click);
            // 
            // btnnDobavit
            // 
            this.btnnDobavit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(156)))), ((int)(((byte)(26)))));
            this.btnnDobavit.Location = new System.Drawing.Point(241, 156);
            this.btnnDobavit.Name = "btnnDobavit";
            this.btnnDobavit.Size = new System.Drawing.Size(157, 48);
            this.btnnDobavit.TabIndex = 13;
            this.btnnDobavit.Text = "Добавить ";
            this.btnnDobavit.UseVisualStyleBackColor = false;
            this.btnnDobavit.Click += new System.EventHandler(this.btnnDobavit_Click);
            // 
            // shirinaTextBox
            // 
            this.shirinaTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsIzdeliya, "Shirina", true));
            this.shirinaTextBox.Location = new System.Drawing.Point(303, 130);
            this.shirinaTextBox.Name = "shirinaTextBox";
            this.shirinaTextBox.ReadOnly = true;
            this.shirinaTextBox.Size = new System.Drawing.Size(258, 20);
            this.shirinaTextBox.TabIndex = 6;
            this.shirinaTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.shirinaTextBox_KeyPress);
            // 
            // bsIzdeliya
            // 
            this.bsIzdeliya.DataMember = "Izdeliya";
            this.bsIzdeliya.DataSource = this.u37_15DataSet1;
            // 
            // dlinaTextBox
            // 
            this.dlinaTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsIzdeliya, "Dlina", true));
            this.dlinaTextBox.Location = new System.Drawing.Point(303, 88);
            this.dlinaTextBox.Name = "dlinaTextBox";
            this.dlinaTextBox.ReadOnly = true;
            this.dlinaTextBox.Size = new System.Drawing.Size(258, 20);
            this.dlinaTextBox.TabIndex = 4;
            this.dlinaTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dlinaTextBox_KeyPress);
            // 
            // nazvanieIzdeliyaTextBox
            // 
            this.nazvanieIzdeliyaTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsIzdeliya, "NazvanieIzdeliya", true));
            this.nazvanieIzdeliyaTextBox.Location = new System.Drawing.Point(359, 45);
            this.nazvanieIzdeliyaTextBox.Name = "nazvanieIzdeliyaTextBox";
            this.nazvanieIzdeliyaTextBox.ReadOnly = true;
            this.nazvanieIzdeliyaTextBox.Size = new System.Drawing.Size(202, 20);
            this.nazvanieIzdeliyaTextBox.TabIndex = 2;
            this.nazvanieIzdeliyaTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.nazvanieIzdeliyaTextBox_KeyPress);
            // 
            // dgvIzdeliya
            // 
            this.dgvIzdeliya.AllowUserToAddRows = false;
            this.dgvIzdeliya.AllowUserToDeleteRows = false;
            this.dgvIzdeliya.AllowUserToResizeColumns = false;
            this.dgvIzdeliya.AllowUserToResizeRows = false;
            this.dgvIzdeliya.AutoGenerateColumns = false;
            this.dgvIzdeliya.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvIzdeliya.ColumnHeadersVisible = false;
            this.dgvIzdeliya.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.NazvanieIzdeliya,
            this.idIzdeliyaDataGridViewTextBoxColumn,
            this.nazvanieIzdeliyaDataGridViewTextBoxColumn,
            this.dlinaDataGridViewTextBoxColumn,
            this.shirinaDataGridViewTextBoxColumn});
            this.dgvIzdeliya.DataSource = this.bsIzdeliya;
            this.dgvIzdeliya.Location = new System.Drawing.Point(7, 43);
            this.dgvIzdeliya.Name = "dgvIzdeliya";
            this.dgvIzdeliya.ReadOnly = true;
            this.dgvIzdeliya.RowHeadersVisible = false;
            this.dgvIzdeliya.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvIzdeliya.Size = new System.Drawing.Size(228, 215);
            this.dgvIzdeliya.TabIndex = 0;
            // 
            // NazvanieIzdeliya
            // 
            this.NazvanieIzdeliya.DataPropertyName = "NazvanieIzdeliya";
            this.NazvanieIzdeliya.HeaderText = "NazvanieIzdeliya";
            this.NazvanieIzdeliya.Name = "NazvanieIzdeliya";
            this.NazvanieIzdeliya.ReadOnly = true;
            // 
            // idIzdeliyaDataGridViewTextBoxColumn
            // 
            this.idIzdeliyaDataGridViewTextBoxColumn.DataPropertyName = "idIzdeliya";
            this.idIzdeliyaDataGridViewTextBoxColumn.HeaderText = "idIzdeliya";
            this.idIzdeliyaDataGridViewTextBoxColumn.Name = "idIzdeliyaDataGridViewTextBoxColumn";
            this.idIzdeliyaDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nazvanieIzdeliyaDataGridViewTextBoxColumn
            // 
            this.nazvanieIzdeliyaDataGridViewTextBoxColumn.DataPropertyName = "NazvanieIzdeliya";
            this.nazvanieIzdeliyaDataGridViewTextBoxColumn.HeaderText = "NazvanieIzdeliya";
            this.nazvanieIzdeliyaDataGridViewTextBoxColumn.Name = "nazvanieIzdeliyaDataGridViewTextBoxColumn";
            this.nazvanieIzdeliyaDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // dlinaDataGridViewTextBoxColumn
            // 
            this.dlinaDataGridViewTextBoxColumn.DataPropertyName = "Dlina";
            this.dlinaDataGridViewTextBoxColumn.HeaderText = "Dlina";
            this.dlinaDataGridViewTextBoxColumn.Name = "dlinaDataGridViewTextBoxColumn";
            this.dlinaDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // shirinaDataGridViewTextBoxColumn
            // 
            this.shirinaDataGridViewTextBoxColumn.DataPropertyName = "Shirina";
            this.shirinaDataGridViewTextBoxColumn.HeaderText = "Shirina";
            this.shirinaDataGridViewTextBoxColumn.Name = "shirinaDataGridViewTextBoxColumn";
            this.shirinaDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // izdeliyaTableAdapter
            // 
            this.izdeliyaTableAdapter.ClearBeforeFill = true;
            // 
            // u3715DataSet1BindingSource
            // 
            this.u3715DataSet1BindingSource.DataSource = this.u37_15DataSet1;
            this.u3715DataSet1BindingSource.Position = 0;
            // 
            // zakazyBindingSource
            // 
            this.zakazyBindingSource.DataMember = "Zakazy";
            this.zakazyBindingSource.DataSource = this.u3715DataSet1BindingSource;
            // 
            // zakazyTableAdapter
            // 
            this.zakazyTableAdapter.ClearBeforeFill = true;
            // 
            // lblIdUser
            // 
            this.lblIdUser.AutoSize = true;
            this.lblIdUser.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsPolzovatel, "idPolzovatel", true));
            this.lblIdUser.Location = new System.Drawing.Point(1069, 256);
            this.lblIdUser.Name = "lblIdUser";
            this.lblIdUser.Size = new System.Drawing.Size(35, 13);
            this.lblIdUser.TabIndex = 18;
            this.lblIdUser.Text = "label2";
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.DefaultExt = "CSV";
            this.saveFileDialog1.Filter = "Файлы CSV|*.CSV|Все файлы|*.*";
            // 
            // FormManajer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(883, 574);
            this.Controls.Add(this.lblIdUser);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(otchLabel);
            this.Controls.Add(this.otchLabel1);
            this.Controls.Add(nameLabel);
            this.Controls.Add(this.nameLabel1);
            this.Controls.Add(famLabel);
            this.Controls.Add(this.famLabel1);
            this.Controls.Add(this.btnProfilPolzovatel);
            this.Controls.Add(this.panel1);
            this.Name = "FormManajer";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Рабочее место Менеджера";
            this.Load += new System.EventHandler(this.FormManajer_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.u37_15DataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsPolzovatel)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvZakazy)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bsIzdeliya)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvIzdeliya)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.u3715DataSet1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zakazyBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnProfilPolzovatel;
        private u37_15DataSet u37_15DataSet1;
        private u37_15DataSetTableAdapters.PolzovateliTableAdapter polzovateliTableAdapter;
        private u37_15DataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.Label famLabel1;
        private System.Windows.Forms.Label nameLabel1;
        private System.Windows.Forms.Label otchLabel1;
        public System.Windows.Forms.BindingSource bsPolzovatel;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Button btnEksportNeAll;
        private System.Windows.Forms.Button btnEksportAll;
        private System.Windows.Forms.RadioButton rbtCSV;
        private System.Windows.Forms.RadioButton rbtWord;
        private System.Windows.Forms.BindingSource bsIzdeliya;
        private u37_15DataSetTableAdapters.IzdeliyaTableAdapter izdeliyaTableAdapter;
        private System.Windows.Forms.DataGridView dgvIzdeliya;
        private System.Windows.Forms.DataGridViewTextBoxColumn NazvanieIzdeliya;
        private System.Windows.Forms.TextBox shirinaTextBox;
        private System.Windows.Forms.TextBox dlinaTextBox;
        private System.Windows.Forms.TextBox nazvanieIzdeliyaTextBox;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnRedakt;
        private System.Windows.Forms.Button btnnDobavit;
        private System.Windows.Forms.DataGridViewTextBoxColumn idIzdeliyaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nazvanieIzdeliyaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dlinaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn shirinaDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource u3715DataSet1BindingSource;
        private System.Windows.Forms.BindingSource zakazyBindingSource;
        private u37_15DataSetTableAdapters.ZakazyTableAdapter zakazyTableAdapter;
        private System.Windows.Forms.DataGridView dgvZakazy;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.Label lblIdUser;
        private System.Windows.Forms.ListView LVTkani;
        private System.Windows.Forms.ListView LVFurnitura;
        private System.Windows.Forms.TextBox primechanieTextBox;
        private System.Windows.Forms.TextBox colorTkanTextBox;
        private System.Windows.Forms.TextBox nazvanieTkanTextBox;
        private System.Windows.Forms.TextBox tbxNazvFurnitura;
        private System.Windows.Forms.TextBox tbxKolVoFurnitura;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.ImageList imageListFur;
        public System.Windows.Forms.TextBox tbxDlina;
        public System.Windows.Forms.TextBox tbxShirina;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
    }
}