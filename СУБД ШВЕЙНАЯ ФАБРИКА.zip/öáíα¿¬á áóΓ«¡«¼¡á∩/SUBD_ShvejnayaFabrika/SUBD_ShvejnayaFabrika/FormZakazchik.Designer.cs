﻿namespace SUBD_ShvejnayaFabrika
{
    partial class FormZakazchik
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label famLabel;
            System.Windows.Forms.Label nameLabel;
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.u37_15DataSet1 = new SUBD_ShvejnayaFabrika.u37_15DataSet();
            this.bsPolzovatel = new System.Windows.Forms.BindingSource(this.components);
            this.polzovateliTableAdapter = new SUBD_ShvejnayaFabrika.u37_15DataSetTableAdapters.PolzovateliTableAdapter();
            this.tableAdapterManager = new SUBD_ShvejnayaFabrika.u37_15DataSetTableAdapters.TableAdapterManager();
            this.FamLabel1 = new System.Windows.Forms.Label();
            this.NameLabel1 = new System.Windows.Forms.Label();
            this.OtchLabel1 = new System.Windows.Forms.Label();
            this.btnProfilPolzovatel = new System.Windows.Forms.Button();
            this.dgvZakazy = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblIdUser = new System.Windows.Forms.Label();
            this.btnNechetPoisk = new System.Windows.Forms.Button();
            this.btnNewZakaz = new System.Windows.Forms.Button();
            famLabel = new System.Windows.Forms.Label();
            nameLabel = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.u37_15DataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsPolzovatel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvZakazy)).BeginInit();
            this.SuspendLayout();
            // 
            // famLabel
            // 
            famLabel.AutoSize = true;
            famLabel.Location = new System.Drawing.Point(32, 175);
            famLabel.Name = "famLabel";
            famLabel.Size = new System.Drawing.Size(0, 13);
            famLabel.TabIndex = 2;
            // 
            // nameLabel
            // 
            nameLabel.AutoSize = true;
            nameLabel.Location = new System.Drawing.Point(44, 225);
            nameLabel.Name = "nameLabel";
            nameLabel.Size = new System.Drawing.Size(0, 13);
            nameLabel.TabIndex = 3;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1143, 128);
            this.panel1.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(221, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(413, 37);
            this.label1.TabIndex = 1;
            this.label1.Text = "Рабочее место заказчика";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Left;
            this.pictureBox1.Image = global::SUBD_ShvejnayaFabrika.Properties.Resources.fabric_logo;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(169, 128);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // u37_15DataSet1
            // 
            this.u37_15DataSet1.DataSetName = "u37_15DataSet";
            this.u37_15DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bsPolzovatel
            // 
            this.bsPolzovatel.DataMember = "Polzovateli";
            this.bsPolzovatel.DataSource = this.u37_15DataSet1;
            // 
            // polzovateliTableAdapter
            // 
            this.polzovateliTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.FurnituraTableAdapter = null;
            this.tableAdapterManager.IzdeliyaTableAdapter = null;
            this.tableAdapterManager.PolzovateliTableAdapter = this.polzovateliTableAdapter;
            this.tableAdapterManager.TkaniTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = SUBD_ShvejnayaFabrika.u37_15DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.ZakazyTableAdapter = null;
            // 
            // FamLabel1
            // 
            this.FamLabel1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsPolzovatel, "Fam", true));
            this.FamLabel1.Location = new System.Drawing.Point(12, 147);
            this.FamLabel1.Name = "FamLabel1";
            this.FamLabel1.Size = new System.Drawing.Size(100, 23);
            this.FamLabel1.TabIndex = 3;
            this.FamLabel1.Text = "label2";
            // 
            // NameLabel1
            // 
            this.NameLabel1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsPolzovatel, "Name", true));
            this.NameLabel1.Location = new System.Drawing.Point(12, 187);
            this.NameLabel1.Name = "NameLabel1";
            this.NameLabel1.Size = new System.Drawing.Size(100, 23);
            this.NameLabel1.TabIndex = 4;
            this.NameLabel1.Text = "label2";
            // 
            // OtchLabel1
            // 
            this.OtchLabel1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsPolzovatel, "Otch", true));
            this.OtchLabel1.Location = new System.Drawing.Point(12, 225);
            this.OtchLabel1.Name = "OtchLabel1";
            this.OtchLabel1.Size = new System.Drawing.Size(100, 23);
            this.OtchLabel1.TabIndex = 6;
            this.OtchLabel1.Text = "label2";
            // 
            // btnProfilPolzovatel
            // 
            this.btnProfilPolzovatel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(156)))), ((int)(((byte)(26)))));
            this.btnProfilPolzovatel.Location = new System.Drawing.Point(15, 251);
            this.btnProfilPolzovatel.Name = "btnProfilPolzovatel";
            this.btnProfilPolzovatel.Size = new System.Drawing.Size(154, 48);
            this.btnProfilPolzovatel.TabIndex = 10;
            this.btnProfilPolzovatel.Text = "Профиль пользователя";
            this.btnProfilPolzovatel.UseVisualStyleBackColor = false;
            this.btnProfilPolzovatel.Click += new System.EventHandler(this.btnProfilPolzovatel_Click);
            // 
            // dgvZakazy
            // 
            this.dgvZakazy.AllowUserToAddRows = false;
            this.dgvZakazy.AllowUserToDeleteRows = false;
            this.dgvZakazy.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvZakazy.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6});
            this.dgvZakazy.Location = new System.Drawing.Point(175, 162);
            this.dgvZakazy.Name = "dgvZakazy";
            this.dgvZakazy.ReadOnly = true;
            this.dgvZakazy.RowHeadersVisible = false;
            this.dgvZakazy.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvZakazy.Size = new System.Drawing.Size(618, 276);
            this.dgvZakazy.TabIndex = 11;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Изделие";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Кол-во изделий";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Ткань";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Фурнитура";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "Кол-во фурнитуры";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "Менеджер";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            // 
            // lblIdUser
            // 
            this.lblIdUser.AutoSize = true;
            this.lblIdUser.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsPolzovatel, "idPolzovatel", true));
            this.lblIdUser.Location = new System.Drawing.Point(989, 175);
            this.lblIdUser.Name = "lblIdUser";
            this.lblIdUser.Size = new System.Drawing.Size(35, 13);
            this.lblIdUser.TabIndex = 12;
            this.lblIdUser.Text = "label2";
            // 
            // btnNechetPoisk
            // 
            this.btnNechetPoisk.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(156)))), ((int)(((byte)(26)))));
            this.btnNechetPoisk.Location = new System.Drawing.Point(15, 305);
            this.btnNechetPoisk.Name = "btnNechetPoisk";
            this.btnNechetPoisk.Size = new System.Drawing.Size(154, 48);
            this.btnNechetPoisk.TabIndex = 13;
            this.btnNechetPoisk.Text = "Нечеткий поиск";
            this.btnNechetPoisk.UseVisualStyleBackColor = false;
            this.btnNechetPoisk.Click += new System.EventHandler(this.btnNechetPoisk_Click);
            // 
            // btnNewZakaz
            // 
            this.btnNewZakaz.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(156)))), ((int)(((byte)(26)))));
            this.btnNewZakaz.Location = new System.Drawing.Point(15, 359);
            this.btnNewZakaz.Name = "btnNewZakaz";
            this.btnNewZakaz.Size = new System.Drawing.Size(154, 48);
            this.btnNewZakaz.TabIndex = 14;
            this.btnNewZakaz.Text = "Новый заказ";
            this.btnNewZakaz.UseVisualStyleBackColor = false;
            this.btnNewZakaz.Click += new System.EventHandler(this.btnNewZakaz_Click);
            // 
            // FormZakazchik
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1143, 450);
            this.Controls.Add(this.btnNewZakaz);
            this.Controls.Add(this.btnNechetPoisk);
            this.Controls.Add(this.lblIdUser);
            this.Controls.Add(this.dgvZakazy);
            this.Controls.Add(this.btnProfilPolzovatel);
            this.Controls.Add(this.OtchLabel1);
            this.Controls.Add(nameLabel);
            this.Controls.Add(this.NameLabel1);
            this.Controls.Add(famLabel);
            this.Controls.Add(this.FamLabel1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormZakazchik";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Рабочее место заказчика";
            this.Load += new System.EventHandler(this.FormZakazchik_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.u37_15DataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsPolzovatel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvZakazy)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private u37_15DataSet u37_15DataSet1;
        private u37_15DataSetTableAdapters.PolzovateliTableAdapter polzovateliTableAdapter;
        private u37_15DataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.Label FamLabel1;
        private System.Windows.Forms.Label NameLabel1;
        public System.Windows.Forms.BindingSource bsPolzovatel;
        private System.Windows.Forms.Label OtchLabel1;
        private System.Windows.Forms.Button btnProfilPolzovatel;
        private System.Windows.Forms.DataGridView dgvZakazy;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.Label lblIdUser;
        private System.Windows.Forms.Button btnNechetPoisk;
        private System.Windows.Forms.Button btnNewZakaz;
    }
}