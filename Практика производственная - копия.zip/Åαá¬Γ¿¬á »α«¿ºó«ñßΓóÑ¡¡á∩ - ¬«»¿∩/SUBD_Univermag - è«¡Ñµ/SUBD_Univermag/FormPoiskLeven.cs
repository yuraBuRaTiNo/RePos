﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SUBD_Univermag
{
    public partial class FormPoiskLeven : Form
    {
        List<string> lstTkani = new List<string>();


        public static int Levenshtejn(string t1, string t2)
        {
            int CntLev = 0;

            CntLev += Math.Abs(t1.Length - t2.Length);

            for (int i = 0; i <= Math.Min(t1.Length, t2.Length) - 1; i++)
            {
                if (t1[i] != t2[i])
                {
                    CntLev++;
                }
            }
            return CntLev;
        }

        public FormPoiskLeven()
        {
            InitializeComponent();
        }

        private void btnNechetPoisk_Click(object sender, EventArgs e)
        {
            dgvTkani.Rows.Clear();


            for (int i = 0; i <= lstTkani.Count - 1; i++)
            {
                int lev = Levenshtejn(tbxLevenshtejn.Text, lstTkani[i]);
                if (lev <= 3)
                    dgvTkani.Rows.Add(lstTkani[i]);
            }
        }

        private void FormPoiskLeven_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(Properties.Settings.Default.UnivermagConnectionString);

            con.Open();

            SqlCommand q1 = new SqlCommand(string.Format(@"SELECT NameTkan
                                                                    from TekstilnijMir"), con);

            SqlDataReader res = q1.ExecuteReader();

            while (res.Read())
            {
                lstTkani.Add(res["NameTkan"].ToString());
                dgvTkani.Rows.Add(res["NameTkan"]);
            }

            con.Close();

        }

        private void ShowAll_Click(object sender, EventArgs e)
        {
            dgvTkani.Rows.Clear();
            for (int i = 0; i <= lstTkani.Count - 1; i++)
            {
                dgvTkani.Rows.Add(lstTkani[i]);
            }
        }
    }
}
