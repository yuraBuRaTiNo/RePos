﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SUBD_Univermag
{
    public partial class FormAddMaterial : Form
    {
        public FormAddMaterial()
        {
            InitializeComponent();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if(tbxName.Text == "" || tbxDlina.Text == "" || tbxShirina.Text == "" || tbxColor.Text == "")
            {
                MessageBox.Show("Не заполнены все поля!", "Внимание!");
                return;
            }
        }

        private void FormAddMaterial_Load(object sender, EventArgs e)
        {

        }
    }
}
