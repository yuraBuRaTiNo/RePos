﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SUBD_Univermag
{
    public partial class FormRedaktZapisKnigi : Form
    {
        public FormRedaktZapisKnigi()
        {
            InitializeComponent();
        }

        private void knigiBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.knigiBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.univermagDataSet);

        }

        private void FormRedaktZapisKnigi_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "univermagDataSet.Knigi". При необходимости она может быть перемещена или удалена.
            this.knigiTableAdapter.Fill(this.univermagDataSet.Knigi);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if ( nazvanieKnigaTextBox.Text == "" || authorTextBox.Text == "")
            {
                MessageBox.Show("Заполните все поля!");
            }
            knigiBindingSource.EndEdit();

            this.knigiTableAdapter.Update(this.univermagDataSet.Knigi);

            this.Close();
        }
    }
}
