﻿namespace SUBD_Univermag
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tbxCapcha = new System.Windows.Forms.TextBox();
            this.lblCapcha = new System.Windows.Forms.Label();
            this.lblNewReg = new System.Windows.Forms.Label();
            this.btnVxod = new System.Windows.Forms.Button();
            this.cbxShowPass = new System.Windows.Forms.CheckBox();
            this.cmbAutorization = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbxPassword = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbxLogin = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.bsPolzovateli = new System.Windows.Forms.BindingSource(this.components);
            this.univermagDataSet1 = new SUBD_Univermag.UnivermagDataSet();
            this.polzovateliTableAdapter = new SUBD_Univermag.UnivermagDataSetTableAdapters.PolzovateliTableAdapter();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsPolzovateli)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.univermagDataSet1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(420, 128);
            this.panel1.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(191, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(211, 37);
            this.label1.TabIndex = 1;
            this.label1.Text = "Авторизация";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Left;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(167, 128);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(274, 344);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(83, 13);
            this.label6.TabIndex = 25;
            this.label6.Text = "Введите капчу:";
            // 
            // tbxCapcha
            // 
            this.tbxCapcha.Location = new System.Drawing.Point(274, 363);
            this.tbxCapcha.Name = "tbxCapcha";
            this.tbxCapcha.Size = new System.Drawing.Size(100, 20);
            this.tbxCapcha.TabIndex = 24;
            // 
            // lblCapcha
            // 
            this.lblCapcha.AutoSize = true;
            this.lblCapcha.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(225)))));
            this.lblCapcha.Font = new System.Drawing.Font("Ravie", 27.75F, ((System.Drawing.FontStyle)((((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline) 
                | System.Drawing.FontStyle.Strikeout))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCapcha.Location = new System.Drawing.Point(89, 344);
            this.lblCapcha.Name = "lblCapcha";
            this.lblCapcha.Size = new System.Drawing.Size(175, 50);
            this.lblCapcha.TabIndex = 23;
            this.lblCapcha.Text = "label5";
            // 
            // lblNewReg
            // 
            this.lblNewReg.AutoSize = true;
            this.lblNewReg.BackColor = System.Drawing.Color.White;
            this.lblNewReg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblNewReg.ForeColor = System.Drawing.Color.Blue;
            this.lblNewReg.Location = new System.Drawing.Point(95, 467);
            this.lblNewReg.Name = "lblNewReg";
            this.lblNewReg.Size = new System.Drawing.Size(199, 16);
            this.lblNewReg.TabIndex = 22;
            this.lblNewReg.Text = "Регитсрация нового стажера";
            this.lblNewReg.Click += new System.EventHandler(this.lblNewReg_Click);
            // 
            // btnVxod
            // 
            this.btnVxod.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(156)))), ((int)(((byte)(26)))));
            this.btnVxod.Location = new System.Drawing.Point(137, 411);
            this.btnVxod.Name = "btnVxod";
            this.btnVxod.Size = new System.Drawing.Size(135, 48);
            this.btnVxod.TabIndex = 21;
            this.btnVxod.Text = "Вход";
            this.btnVxod.UseVisualStyleBackColor = false;
            this.btnVxod.Click += new System.EventHandler(this.btnVxod_Click);
            // 
            // cbxShowPass
            // 
            this.cbxShowPass.AutoSize = true;
            this.cbxShowPass.Location = new System.Drawing.Point(98, 318);
            this.cbxShowPass.Name = "cbxShowPass";
            this.cbxShowPass.Size = new System.Drawing.Size(114, 17);
            this.cbxShowPass.TabIndex = 20;
            this.cbxShowPass.Text = "Показать пароль";
            this.cbxShowPass.UseVisualStyleBackColor = true;
            this.cbxShowPass.CheckedChanged += new System.EventHandler(this.cbxShowPass_CheckedChanged);
            // 
            // cmbAutorization
            // 
            this.cmbAutorization.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAutorization.FormattingEnabled = true;
            this.cmbAutorization.Items.AddRange(new object[] {
            "книги",
            "директор",
            "текстильный мир",
            "стажер"});
            this.cmbAutorization.Location = new System.Drawing.Point(98, 168);
            this.cmbAutorization.Name = "cmbAutorization";
            this.cmbAutorization.Size = new System.Drawing.Size(277, 21);
            this.cmbAutorization.TabIndex = 19;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(98, 273);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 13);
            this.label4.TabIndex = 18;
            this.label4.Text = "Пароль";
            // 
            // tbxPassword
            // 
            this.tbxPassword.Location = new System.Drawing.Point(98, 292);
            this.tbxPassword.Name = "tbxPassword";
            this.tbxPassword.Size = new System.Drawing.Size(277, 20);
            this.tbxPassword.TabIndex = 17;
            this.tbxPassword.UseSystemPasswordChar = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(98, 215);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 13);
            this.label3.TabIndex = 16;
            this.label3.Text = "Логин";
            // 
            // tbxLogin
            // 
            this.tbxLogin.Location = new System.Drawing.Point(98, 234);
            this.tbxLogin.Name = "tbxLogin";
            this.tbxLogin.Size = new System.Drawing.Size(277, 20);
            this.tbxLogin.TabIndex = 15;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(98, 152);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(152, 13);
            this.label2.TabIndex = 14;
            this.label2.Text = "Выберите, кто авторизуется";
            // 
            // bsPolzovateli
            // 
            this.bsPolzovateli.DataMember = "Polzovateli";
            this.bsPolzovateli.DataSource = this.univermagDataSet1;
            // 
            // univermagDataSet1
            // 
            this.univermagDataSet1.DataSetName = "UnivermagDataSet";
            this.univermagDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // polzovateliTableAdapter
            // 
            this.polzovateliTableAdapter.ClearBeforeFill = true;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(156)))), ((int)(((byte)(26)))));
            this.button1.Location = new System.Drawing.Point(137, 493);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(135, 48);
            this.button1.TabIndex = 26;
            this.button1.Text = "Справочник";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(420, 553);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.tbxCapcha);
            this.Controls.Add(this.lblCapcha);
            this.Controls.Add(this.lblNewReg);
            this.Controls.Add(this.btnVxod);
            this.Controls.Add(this.cbxShowPass);
            this.Controls.Add(this.cmbAutorization);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tbxPassword);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbxLogin);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsPolzovateli)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.univermagDataSet1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbxCapcha;
        private System.Windows.Forms.Label lblCapcha;
        private System.Windows.Forms.Button btnVxod;
        private System.Windows.Forms.CheckBox cbxShowPass;
        private System.Windows.Forms.ComboBox cmbAutorization;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbxPassword;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbxLogin;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.BindingSource bsPolzovateli;
        private UnivermagDataSet univermagDataSet1;
        private UnivermagDataSetTableAdapters.PolzovateliTableAdapter polzovateliTableAdapter;
        public System.Windows.Forms.Label lblNewReg;
        private System.Windows.Forms.Button button1;
    }
}

