﻿namespace SUBD_Univermag
{
    partial class FormStajer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnProfilPolzovatel = new System.Windows.Forms.Button();
            this.bsPolzovateli = new System.Windows.Forms.BindingSource(this.components);
            this.univermagDataSet = new SUBD_Univermag.UnivermagDataSet();
            this.bsPolzovatel = new System.Windows.Forms.BindingSource(this.components);
            this.univermagDataSet1 = new SUBD_Univermag.UnivermagDataSet();
            this.polzovateliTableAdapter = new SUBD_Univermag.UnivermagDataSetTableAdapters.PolzovateliTableAdapter();
            this.tableAdapterManager = new SUBD_Univermag.UnivermagDataSetTableAdapters.TableAdapterManager();
            this.otchLabel1 = new System.Windows.Forms.Label();
            this.nameLabel1 = new System.Windows.Forms.Label();
            this.famLabel1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsPolzovateli)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.univermagDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsPolzovatel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.univermagDataSet1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(800, 128);
            this.panel1.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(191, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(387, 37);
            this.label1.TabIndex = 1;
            this.label1.Text = "Рабочее место стажера";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Left;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(167, 128);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // btnProfilPolzovatel
            // 
            this.btnProfilPolzovatel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(156)))), ((int)(((byte)(26)))));
            this.btnProfilPolzovatel.Location = new System.Drawing.Point(13, 290);
            this.btnProfilPolzovatel.Name = "btnProfilPolzovatel";
            this.btnProfilPolzovatel.Size = new System.Drawing.Size(154, 48);
            this.btnProfilPolzovatel.TabIndex = 12;
            this.btnProfilPolzovatel.Text = "Профиль пользователя";
            this.btnProfilPolzovatel.UseVisualStyleBackColor = false;
            this.btnProfilPolzovatel.Click += new System.EventHandler(this.btnProfilPolzovatel_Click);
            // 
            // bsPolzovateli
            // 
            this.bsPolzovateli.DataMember = "Polzovateli";
            this.bsPolzovateli.DataSource = this.univermagDataSet;
            // 
            // univermagDataSet
            // 
            this.univermagDataSet.DataSetName = "UnivermagDataSet";
            this.univermagDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bsPolzovatel
            // 
            this.bsPolzovatel.DataMember = "Polzovateli";
            this.bsPolzovatel.DataSource = this.univermagDataSet1;
            // 
            // univermagDataSet1
            // 
            this.univermagDataSet1.DataSetName = "UnivermagDataSet";
            this.univermagDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // polzovateliTableAdapter
            // 
            this.polzovateliTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.DirectorTableAdapter = null;
            this.tableAdapterManager.KnigiTableAdapter = null;
            this.tableAdapterManager.PolzovateliTableAdapter = this.polzovateliTableAdapter;
            this.tableAdapterManager.TekstilnijMirTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = SUBD_Univermag.UnivermagDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // otchLabel1
            // 
            this.otchLabel1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsPolzovateli, "Otch", true));
            this.otchLabel1.Location = new System.Drawing.Point(67, 221);
            this.otchLabel1.Name = "otchLabel1";
            this.otchLabel1.Size = new System.Drawing.Size(100, 23);
            this.otchLabel1.TabIndex = 19;
            this.otchLabel1.Text = "label2";
            // 
            // nameLabel1
            // 
            this.nameLabel1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsPolzovateli, "Name", true));
            this.nameLabel1.Location = new System.Drawing.Point(67, 185);
            this.nameLabel1.Name = "nameLabel1";
            this.nameLabel1.Size = new System.Drawing.Size(100, 23);
            this.nameLabel1.TabIndex = 18;
            this.nameLabel1.Text = "label2";
            // 
            // famLabel1
            // 
            this.famLabel1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsPolzovateli, "Fam", true));
            this.famLabel1.Location = new System.Drawing.Point(67, 147);
            this.famLabel1.Name = "famLabel1";
            this.famLabel1.Size = new System.Drawing.Size(100, 23);
            this.famLabel1.TabIndex = 17;
            this.famLabel1.Text = "label2";
            // 
            // FormStajer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.otchLabel1);
            this.Controls.Add(this.nameLabel1);
            this.Controls.Add(this.famLabel1);
            this.Controls.Add(this.btnProfilPolzovatel);
            this.Controls.Add(this.panel1);
            this.Name = "FormStajer";
            this.Text = "FormStajer";
            this.Load += new System.EventHandler(this.FormStajer_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsPolzovateli)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.univermagDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsPolzovatel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.univermagDataSet1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnProfilPolzovatel;
        public System.Windows.Forms.BindingSource bsPolzovateli;
        private UnivermagDataSet univermagDataSet;
        public System.Windows.Forms.BindingSource bsPolzovatel;
        private UnivermagDataSet univermagDataSet1;
        private UnivermagDataSetTableAdapters.PolzovateliTableAdapter polzovateliTableAdapter;
        private UnivermagDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.Label otchLabel1;
        private System.Windows.Forms.Label nameLabel1;
        private System.Windows.Forms.Label famLabel1;
    }
}