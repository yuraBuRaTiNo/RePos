﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SUBD_Univermag
{
    public partial class FormPoiskKnigi : Form
    {
        List<string> lstKnigi = new List<string>();

        public FormPoiskKnigi()
        {
            InitializeComponent();
        }

        public static int Levenshtejn(string t1, string t2)
        {
            int CntLev = 0;

            CntLev += Math.Abs(t1.Length - t2.Length);

            for (int i = 0; i <= Math.Min(t1.Length, t2.Length) - 1; i++)
            {
                if (t1[i] != t2[i])
                {
                    CntLev++;
                }
            }
            return CntLev;
        }

        private void btnNechetPoisk_Click(object sender, EventArgs e)
        {
            dgvKnigi.Rows.Clear();


            for (int i = 0; i <= lstKnigi.Count - 1; i++)
            {
                int lev = Levenshtejn(tbxLevenshtejn.Text, lstKnigi[i]);
                if (lev <= 3)
                    dgvKnigi.Rows.Add(lstKnigi[i]);
            }
        }

        private void FormPoiskKnigi_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(Properties.Settings.Default.UnivermagConnectionString);

            con.Open();

            SqlCommand q1 = new SqlCommand(string.Format(@"SELECT NazvanieKniga 
                                                                    from Knigi"), con);

            SqlDataReader res = q1.ExecuteReader();

            while (res.Read())
            {
                lstKnigi.Add(res["NazvanieKniga"].ToString());
                dgvKnigi.Rows.Add(res["NazvanieKniga"]);
            }

            con.Close();


        }

        private void ShowAll_Click(object sender, EventArgs e)
        {

            dgvKnigi.Rows.Clear();
            for (int i = 0; i <= lstKnigi.Count - 1; i++)
            {
                dgvKnigi.Rows.Add(lstKnigi[i]);
            }
        }
    }
}
