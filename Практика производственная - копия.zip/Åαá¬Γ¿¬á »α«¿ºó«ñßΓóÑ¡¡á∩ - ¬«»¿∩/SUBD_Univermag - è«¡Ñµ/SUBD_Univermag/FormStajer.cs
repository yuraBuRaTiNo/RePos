﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SUBD_Univermag
{
    public partial class FormStajer : Form
    {
        public FormStajer()
        {
            InitializeComponent();
        }

        private void btnProfilPolzovatel_Click(object sender, EventArgs e)
        {
            FormProfile frmprof = new FormProfile();
            frmprof.bsPolzovateli.Filter = this.bsPolzovateli.Filter;
            if (frmprof.ShowDialog() == DialogResult.OK)
            {
                this.polzovateliTableAdapter.Fill(this.univermagDataSet.Polzovateli);
            }
        }

        private void FormStajer_Load(object sender, EventArgs e)
        {
            this.polzovateliTableAdapter.Fill(this.univermagDataSet.Polzovateli);
        }
    }
}
