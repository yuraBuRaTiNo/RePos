﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Diagnostics;

namespace SUBD_Univermag
{
    public partial class Form1 : Form
    {
     

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "univermagDataSet1.Polzovateli". При необходимости она может быть перемещена или удалена.
            this.polzovateliTableAdapter.Fill(this.univermagDataSet1.Polzovateli);

        }

        private void btnVxod_Click(object sender, EventArgs e)
        {
            string txtFilterForUsers = string.Format("login = '{0}'", tbxLogin.Text);

            bsPolzovateli.Filter = "Login = '" + tbxLogin.Text + "' and Password = '" + tbxPassword.Text + "' and Role = '" + cmbAutorization.Text + "'";
            if (bsPolzovateli.Count == 0)
            {
                MessageBox.Show("Неверный логин или пароль");
               
                return;
            }

            else
            {
                tbxLogin.Clear();
                tbxPassword.Clear();

                this.Visible = false;

                if (cmbAutorization.Text == "директор")
                {
                    FormDirector frmDir = new FormDirector();
                    frmDir.bsPolzovateli.Filter = bsPolzovateli.Filter;
                    frmDir.ShowDialog();
                }

               

                if (cmbAutorization.Text == "книги")
                {
                    FormKnigi frm = new FormKnigi();
                    frm.bsPolzovateli.Filter = bsPolzovateli.Filter;
                    frm.ShowDialog();
                }

                if (cmbAutorization.Text == "текстильный мир")
                {
                    FormTekstilnijMir frm = new FormTekstilnijMir();
                    frm.bsPolzovateli.Filter = bsPolzovateli.Filter;
                    frm.ShowDialog();
                }

                if (cmbAutorization.Text == "стажер")
                {
                    FormStajer frmStaj = new FormStajer();
                    frmStaj.bsPolzovateli.Filter = bsPolzovateli.Filter;
                    frmStaj.ShowDialog();
                }

                this.Visible = true;
                this.polzovateliTableAdapter.Fill(this.univermagDataSet1.Polzovateli);
                
                
            }

            
        }

        private void lblNewReg_Click(object sender, EventArgs e)
        {
            FormRegNewRab frm = new FormRegNewRab();

            frm.ShowDialog();
        }

        private void cbxShowPass_CheckedChanged(object sender, EventArgs e)
        {
            tbxPassword.UseSystemPasswordChar = !cbxShowPass.Checked;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Process.Start(Application.StartupPath + "\\help.chm");
        }
    }
}
