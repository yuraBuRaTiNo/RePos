﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SUBD_Univermag
{
    public partial class FormRegNewRab : Form
    {
        public FormRegNewRab()
        {
            InitializeComponent();
        }

        private void Btn_Reg_Click(object sender, EventArgs e)
        {
            if (PasswordTextBox.Text != tbxProverkaPass.Text)
            {
                MessageBox.Show("Введенные пароли не совпадают или не соответствуют требованиям", "",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            try
            {
                bsPolzovateli.EndEdit();
                this.polzovateliTableAdapter.Update(this.univermagDataSet.Polzovateli);
                MessageBox.Show("Новая запись добавлена");
            }
            catch
            {
                MessageBox.Show("В базе данных уже есть пользователь с таким логином, введите уникальный логин", "",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoginTextBox.Focus();
            }

            this.DialogResult = DialogResult.OK;
            Close();
        }

        private void FormRegNewRab_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "univermagDataSet.Polzovateli". При необходимости она может быть перемещена или удалена.
            this.polzovateliTableAdapter.Fill(this.univermagDataSet.Polzovateli);
            bsPolzovateli.AddNew();
            lblRole.Text = "стажер";
        }

        private void cbxShowPass_CheckedChanged(object sender, EventArgs e)
        {
            PasswordTextBox.UseSystemPasswordChar = !cbxShowPass.Checked;

            tbxProverkaPass.UseSystemPasswordChar = !cbxShowPass.Checked;
        }
    }
}
