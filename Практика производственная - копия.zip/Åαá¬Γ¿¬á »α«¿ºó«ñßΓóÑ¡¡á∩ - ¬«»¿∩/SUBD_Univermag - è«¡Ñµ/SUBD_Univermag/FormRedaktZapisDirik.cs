﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SUBD_Univermag
{
    public partial class FormRedaktZapisDirik : Form
    {
        public FormRedaktZapisDirik()
        {
            InitializeComponent();
        }

        private void polzovateliBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.polzovateliBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.univermagDataSet);

        }

        private void FormRedaktZapisDirik_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "univermagDataSet.Polzovateli". При необходимости она может быть перемещена или удалена.
            this.polzovateliTableAdapter.Fill(this.univermagDataSet.Polzovateli);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (famTextBox.Text == "" || nameTextBox.Text == "" || otchTextBox.Text == "" || phoneTextBox.Text == "" || loginTextBox.Text == "" || passwordTextBox.Text == "" || roleTextBox.Text == "")
            {
                MessageBox.Show("Заполните все поля!");
            }
            polzovateliBindingSource.EndEdit();

            this.polzovateliTableAdapter.Update(this.univermagDataSet.Polzovateli);

            this.Close();
        }
    }
}
