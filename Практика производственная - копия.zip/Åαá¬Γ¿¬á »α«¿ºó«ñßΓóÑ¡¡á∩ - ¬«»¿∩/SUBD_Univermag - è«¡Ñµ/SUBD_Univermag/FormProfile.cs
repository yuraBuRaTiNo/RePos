﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using ClassLibrary1;

namespace SUBD_Univermag
{
    public partial class FormProfile : Form
    {
        public FormProfile()
        {
            InitializeComponent();
        }


        private void FormProfile_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "univermagDataSet.Polzovateli". При необходимости она может быть перемещена или удалена.
            this.polzovateliTableAdapter.Fill(this.univermagDataSet.Polzovateli);

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (tbxOldPass.Text != labelPass.Text)
            {
                MessageBox.Show("Вы ввели не верный текущий пароль", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (tbxNewPass.Text != "")
            {
                if (!ClassCheckPass.CheckPass(tbxNewPass.Text))
                {
                    MessageBox.Show("Пароль не соответствует требованиям", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                labelPass.Text = tbxNewPass.Text;
            }

            bsPolzovateli.EndEdit();
            this.polzovateliTableAdapter.Update(this.univermagDataSet.Polzovateli);

            this.DialogResult = DialogResult.OK;



            Close();
        }

        private void cbxShowPass_CheckedChanged(object sender, EventArgs e)
        {
            tbxNewPass.UseSystemPasswordChar = !cbxShowPass.Checked;

            tbxOldPass.UseSystemPasswordChar = !cbxShowPass.Checked;
        }
    }
}
