﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Word = Microsoft.Office.Interop.Word;

namespace SUBD_Univermag
{
    public partial class FormTekstilnijMir : Form
    {
        public FormTekstilnijMir()
        {
            InitializeComponent();
        }

        private void FormTekstilnijMir_Load(object sender, EventArgs e)
        {
            this.polzovateliTableAdapter.Fill(this.univermagDataSet.Polzovateli);
            this.tekstilnijMirTableAdapter.Fill(this.univermagDataSet.TekstilnijMir);
        }

        private void btnProfilPolzovatel_Click(object sender, EventArgs e)
        {
            FormProfile frmprof = new FormProfile();
            frmprof.bsPolzovateli.Filter = this.bsPolzovateli.Filter;
            if (frmprof.ShowDialog() == DialogResult.OK)
            {
                this.polzovateliTableAdapter.Fill(this.univermagDataSet.Polzovateli);
            }
        }

        private void btnNechetPoisk_Click(object sender, EventArgs e)
        {
            FormPoiskLeven frm = new FormPoiskLeven();

            frm.ShowDialog();
        }

        private void btnSpisMaterial_Click(object sender, EventArgs e)
        {
            foreach(DataGridViewRow drw in dgvTkani.SelectedRows)
            {
                MessageBox.Show("Удалить выделенную запись?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                dgvTkani.Rows.Remove(drw);
                
            }

            this.tekstilnijMirTableAdapter.Update(this.univermagDataSet.TekstilnijMir);
        }

        private void btnAddZapis_Click(object sender, EventArgs e)
        {


            FormAddMaterial frm = new FormAddMaterial();

            if (frm.ShowDialog() == DialogResult.OK)
            {
                try
                {
                SqlConnection con = new SqlConnection(Properties.Settings.Default.UnivermagConnectionString);
                con.Open();

                SqlCommand query = new SqlCommand($@"Insert into TekstilnijMir values('{frm.tbxName.Text}','{frm.tbxDlina.Text}','{frm.tbxShirina.Text}','{frm.tbxColor.Text}','false', null)", con);
                query.ExecuteNonQuery();
                con.Close();
                dgvTkani.Rows.Clear();

                FormTekstilnijMir_Load(null, null);
                }
                catch
                {
                MessageBox.Show("упс, что-то пошло не так, попробуй еще раз!");
                }

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string idTkan = "-1";

            try
            {
                idTkan = dgvTkani.CurrentRow.Cells[0].Value.ToString();
            }

            catch { MessageBox.Show("Для редактирования выделите эелемент в таблице"); return; }

            FormRedaktZapisTekstMir frm = new FormRedaktZapisTekstMir();
           
                if(frm.ShowDialog() == DialogResult.OK)
            {
                dgvTkani.Rows.Clear();

                FormTekstilnijMir_Load(null, null);
            }

        }

        private void btnFormDoc_Click(object sender, EventArgs e)
        {
            FormFormirDockTkani frm = new FormFormirDockTkani();

            frm.ShowDialog();
        }
    }
}
