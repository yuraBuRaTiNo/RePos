﻿namespace SUBD_Univermag
{
    partial class FormRedaktZapisTekstMir
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label nameTkanLabel;
            System.Windows.Forms.Label dlinaLabel;
            System.Windows.Forms.Label shirinaLabel;
            System.Windows.Forms.Label colorLabel;
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.univermagDataSet = new SUBD_Univermag.UnivermagDataSet();
            this.tekstilnijMirBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tekstilnijMirTableAdapter = new SUBD_Univermag.UnivermagDataSetTableAdapters.TekstilnijMirTableAdapter();
            this.tableAdapterManager = new SUBD_Univermag.UnivermagDataSetTableAdapters.TableAdapterManager();
            this.nameTkanTextBox = new System.Windows.Forms.TextBox();
            this.dlinaTextBox = new System.Windows.Forms.TextBox();
            this.shirinaTextBox = new System.Windows.Forms.TextBox();
            this.colorTextBox = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            nameTkanLabel = new System.Windows.Forms.Label();
            dlinaLabel = new System.Windows.Forms.Label();
            shirinaLabel = new System.Windows.Forms.Label();
            colorLabel = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.univermagDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tekstilnijMirBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(800, 128);
            this.panel1.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(191, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(358, 37);
            this.label1.TabIndex = 1;
            this.label1.Text = "Редактировать запись";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Left;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(167, 128);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // univermagDataSet
            // 
            this.univermagDataSet.DataSetName = "UnivermagDataSet";
            this.univermagDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tekstilnijMirBindingSource
            // 
            this.tekstilnijMirBindingSource.DataMember = "TekstilnijMir";
            this.tekstilnijMirBindingSource.DataSource = this.univermagDataSet;
            // 
            // tekstilnijMirTableAdapter
            // 
            this.tekstilnijMirTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.DirectorTableAdapter = null;
            this.tableAdapterManager.KnigiTableAdapter = null;
            this.tableAdapterManager.PolzovateliTableAdapter = null;
            this.tableAdapterManager.TekstilnijMirTableAdapter = this.tekstilnijMirTableAdapter;
            this.tableAdapterManager.UpdateOrder = SUBD_Univermag.UnivermagDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // nameTkanLabel
            // 
            nameTkanLabel.AutoSize = true;
            nameTkanLabel.Location = new System.Drawing.Point(13, 168);
            nameTkanLabel.Name = "nameTkanLabel";
            nameTkanLabel.Size = new System.Drawing.Size(92, 13);
            nameTkanLabel.TabIndex = 3;
            nameTkanLabel.Text = "Название ткани:";
            // 
            // nameTkanTextBox
            // 
            this.nameTkanTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tekstilnijMirBindingSource, "NameTkan", true));
            this.nameTkanTextBox.Location = new System.Drawing.Point(111, 165);
            this.nameTkanTextBox.Name = "nameTkanTextBox";
            this.nameTkanTextBox.Size = new System.Drawing.Size(100, 20);
            this.nameTkanTextBox.TabIndex = 4;
            // 
            // dlinaLabel
            // 
            dlinaLabel.AutoSize = true;
            dlinaLabel.Location = new System.Drawing.Point(62, 208);
            dlinaLabel.Name = "dlinaLabel";
            dlinaLabel.Size = new System.Drawing.Size(43, 13);
            dlinaLabel.TabIndex = 4;
            dlinaLabel.Text = "Длина:";
            // 
            // dlinaTextBox
            // 
            this.dlinaTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tekstilnijMirBindingSource, "Dlina", true));
            this.dlinaTextBox.Location = new System.Drawing.Point(111, 208);
            this.dlinaTextBox.Name = "dlinaTextBox";
            this.dlinaTextBox.Size = new System.Drawing.Size(100, 20);
            this.dlinaTextBox.TabIndex = 5;
            // 
            // shirinaLabel
            // 
            shirinaLabel.AutoSize = true;
            shirinaLabel.Location = new System.Drawing.Point(56, 261);
            shirinaLabel.Name = "shirinaLabel";
            shirinaLabel.Size = new System.Drawing.Size(49, 13);
            shirinaLabel.TabIndex = 5;
            shirinaLabel.Text = "Ширина:";
            // 
            // shirinaTextBox
            // 
            this.shirinaTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tekstilnijMirBindingSource, "Shirina", true));
            this.shirinaTextBox.Location = new System.Drawing.Point(111, 258);
            this.shirinaTextBox.Name = "shirinaTextBox";
            this.shirinaTextBox.Size = new System.Drawing.Size(100, 20);
            this.shirinaTextBox.TabIndex = 6;
            // 
            // colorLabel
            // 
            colorLabel.AutoSize = true;
            colorLabel.Location = new System.Drawing.Point(70, 305);
            colorLabel.Name = "colorLabel";
            colorLabel.Size = new System.Drawing.Size(35, 13);
            colorLabel.TabIndex = 7;
            colorLabel.Text = "Цвет:";
            // 
            // colorTextBox
            // 
            this.colorTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tekstilnijMirBindingSource, "Color", true));
            this.colorTextBox.Location = new System.Drawing.Point(111, 302);
            this.colorTextBox.Name = "colorTextBox";
            this.colorTextBox.Size = new System.Drawing.Size(100, 20);
            this.colorTextBox.TabIndex = 8;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(23, 347);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 9;
            this.button1.Text = "ок";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(136, 346);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 10;
            this.button2.Text = "отмена";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // FormRedaktZapisTekstMir
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 503);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(colorLabel);
            this.Controls.Add(this.colorTextBox);
            this.Controls.Add(shirinaLabel);
            this.Controls.Add(this.shirinaTextBox);
            this.Controls.Add(dlinaLabel);
            this.Controls.Add(this.dlinaTextBox);
            this.Controls.Add(nameTkanLabel);
            this.Controls.Add(this.nameTkanTextBox);
            this.Controls.Add(this.panel1);
            this.Name = "FormRedaktZapisTekstMir";
            this.Load += new System.EventHandler(this.FormRedaktZapisTekstMir_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.univermagDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tekstilnijMirBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private UnivermagDataSet univermagDataSet;
        private System.Windows.Forms.BindingSource tekstilnijMirBindingSource;
        private UnivermagDataSetTableAdapters.TekstilnijMirTableAdapter tekstilnijMirTableAdapter;
        private UnivermagDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.TextBox nameTkanTextBox;
        private System.Windows.Forms.TextBox dlinaTextBox;
        private System.Windows.Forms.TextBox shirinaTextBox;
        private System.Windows.Forms.TextBox colorTextBox;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}