﻿namespace SUBD_Univermag
{
    partial class FormPoiskRabotnika
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.ShowAll = new System.Windows.Forms.Button();
            this.btnNechetPoisk = new System.Windows.Forms.Button();
            this.dgvRab = new System.Windows.Forms.DataGridView();
            this.tbxLevenshtejn = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRab)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(823, 128);
            this.panel1.TabIndex = 19;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(213, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(609, 37);
            this.label1.TabIndex = 1;
            this.label1.Text = "Нечеткий поиск работника по фамилии";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Left;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(207, 128);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // ShowAll
            // 
            this.ShowAll.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(156)))), ((int)(((byte)(26)))));
            this.ShowAll.Location = new System.Drawing.Point(43, 263);
            this.ShowAll.Name = "ShowAll";
            this.ShowAll.Size = new System.Drawing.Size(150, 48);
            this.ShowAll.TabIndex = 32;
            this.ShowAll.Text = "Отобразить всё";
            this.ShowAll.UseVisualStyleBackColor = false;
            this.ShowAll.Click += new System.EventHandler(this.ShowAll_Click);
            // 
            // btnNechetPoisk
            // 
            this.btnNechetPoisk.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(156)))), ((int)(((byte)(26)))));
            this.btnNechetPoisk.Location = new System.Drawing.Point(43, 209);
            this.btnNechetPoisk.Name = "btnNechetPoisk";
            this.btnNechetPoisk.Size = new System.Drawing.Size(150, 48);
            this.btnNechetPoisk.TabIndex = 31;
            this.btnNechetPoisk.Text = "Нечеткий поиск";
            this.btnNechetPoisk.UseVisualStyleBackColor = false;
            this.btnNechetPoisk.Click += new System.EventHandler(this.btnNechetPoisk_Click);
            // 
            // dgvRab
            // 
            this.dgvRab.AllowUserToAddRows = false;
            this.dgvRab.AllowUserToDeleteRows = false;
            this.dgvRab.AllowUserToResizeColumns = false;
            this.dgvRab.AllowUserToResizeRows = false;
            this.dgvRab.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRab.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1});
            this.dgvRab.Location = new System.Drawing.Point(215, 147);
            this.dgvRab.Name = "dgvRab";
            this.dgvRab.ReadOnly = true;
            this.dgvRab.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvRab.Size = new System.Drawing.Size(573, 291);
            this.dgvRab.TabIndex = 30;
            // 
            // tbxLevenshtejn
            // 
            this.tbxLevenshtejn.Location = new System.Drawing.Point(43, 167);
            this.tbxLevenshtejn.Name = "tbxLevenshtejn";
            this.tbxLevenshtejn.Size = new System.Drawing.Size(150, 20);
            this.tbxLevenshtejn.TabIndex = 29;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(40, 150);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(158, 13);
            this.label3.TabIndex = 28;
            this.label3.Text = "Введите символы для поиска";
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Фамилия";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 500;
            // 
            // FormPoiskRabotnika
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(823, 450);
            this.Controls.Add(this.ShowAll);
            this.Controls.Add(this.btnNechetPoisk);
            this.Controls.Add(this.dgvRab);
            this.Controls.Add(this.tbxLevenshtejn);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.panel1);
            this.Name = "FormPoiskRabotnika";
            this.Text = "FormPoiskRabotnika";
            this.Load += new System.EventHandler(this.FormPoiskRabotnika_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRab)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button ShowAll;
        private System.Windows.Forms.Button btnNechetPoisk;
        private System.Windows.Forms.DataGridView dgvRab;
        private System.Windows.Forms.TextBox tbxLevenshtejn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
    }
}