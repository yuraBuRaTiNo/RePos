﻿namespace SUBD_Univermag
{
    partial class FormRegNewRab
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label label2;
            System.Windows.Forms.Label phoneLabel;
            System.Windows.Forms.Label passwordLabel;
            System.Windows.Forms.Label loginLabel;
            System.Windows.Forms.Label famLabel;
            System.Windows.Forms.Label nameLabel;
            System.Windows.Forms.Label otchLabel;
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.cbxShowPass = new System.Windows.Forms.CheckBox();
            this.tbxProverkaPass = new System.Windows.Forms.TextBox();
            this.tbxPhone = new System.Windows.Forms.MaskedTextBox();
            this.PasswordTextBox = new System.Windows.Forms.TextBox();
            this.LoginTextBox = new System.Windows.Forms.TextBox();
            this.btn_Cansel = new System.Windows.Forms.Button();
            this.Btn_Reg = new System.Windows.Forms.Button();
            this.bsPolzovateli = new System.Windows.Forms.BindingSource(this.components);
            this.univermagDataSet = new SUBD_Univermag.UnivermagDataSet();
            this.polzovateliTableAdapter = new SUBD_Univermag.UnivermagDataSetTableAdapters.PolzovateliTableAdapter();
            this.tableAdapterManager = new SUBD_Univermag.UnivermagDataSetTableAdapters.TableAdapterManager();
            this.lblRole = new System.Windows.Forms.Label();
            this.tbxFam = new System.Windows.Forms.TextBox();
            this.tbxName = new System.Windows.Forms.TextBox();
            this.tbxOtch = new System.Windows.Forms.TextBox();
            label2 = new System.Windows.Forms.Label();
            phoneLabel = new System.Windows.Forms.Label();
            passwordLabel = new System.Windows.Forms.Label();
            loginLabel = new System.Windows.Forms.Label();
            famLabel = new System.Windows.Forms.Label();
            nameLabel = new System.Windows.Forms.Label();
            otchLabel = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsPolzovateli)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.univermagDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(15, 214);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(99, 13);
            label2.TabIndex = 33;
            label2.Text = "Проверка пароля:";
            // 
            // phoneLabel
            // 
            phoneLabel.AutoSize = true;
            phoneLabel.Location = new System.Drawing.Point(15, 394);
            phoneLabel.Name = "phoneLabel";
            phoneLabel.Size = new System.Drawing.Size(55, 13);
            phoneLabel.TabIndex = 30;
            phoneLabel.Text = "Телефон:";
            // 
            // passwordLabel
            // 
            passwordLabel.AutoSize = true;
            passwordLabel.Location = new System.Drawing.Point(15, 188);
            passwordLabel.Name = "passwordLabel";
            passwordLabel.Size = new System.Drawing.Size(48, 13);
            passwordLabel.TabIndex = 22;
            passwordLabel.Text = "Пароль:";
            // 
            // loginLabel
            // 
            loginLabel.AutoSize = true;
            loginLabel.Location = new System.Drawing.Point(15, 145);
            loginLabel.Name = "loginLabel";
            loginLabel.Size = new System.Drawing.Size(41, 13);
            loginLabel.TabIndex = 20;
            loginLabel.Text = "Логин:";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(802, 128);
            this.panel1.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(191, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(455, 37);
            this.label1.TabIndex = 1;
            this.label1.Text = "Регистрация нового стажера";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Left;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(167, 128);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // cbxShowPass
            // 
            this.cbxShowPass.AutoSize = true;
            this.cbxShowPass.Location = new System.Drawing.Point(118, 237);
            this.cbxShowPass.Name = "cbxShowPass";
            this.cbxShowPass.Size = new System.Drawing.Size(114, 17);
            this.cbxShowPass.TabIndex = 34;
            this.cbxShowPass.Text = "Показать пароль";
            this.cbxShowPass.UseVisualStyleBackColor = true;
            this.cbxShowPass.CheckedChanged += new System.EventHandler(this.cbxShowPass_CheckedChanged);
            // 
            // tbxProverkaPass
            // 
            this.tbxProverkaPass.Location = new System.Drawing.Point(118, 211);
            this.tbxProverkaPass.Name = "tbxProverkaPass";
            this.tbxProverkaPass.Size = new System.Drawing.Size(135, 20);
            this.tbxProverkaPass.TabIndex = 32;
            this.tbxProverkaPass.UseSystemPasswordChar = true;
            // 
            // tbxPhone
            // 
            this.tbxPhone.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsPolzovateli, "Phone", true));
            this.tbxPhone.Location = new System.Drawing.Point(78, 391);
            this.tbxPhone.Mask = "+0(000) 000-00-00";
            this.tbxPhone.Name = "tbxPhone";
            this.tbxPhone.Size = new System.Drawing.Size(175, 20);
            this.tbxPhone.TabIndex = 31;
            // 
            // PasswordTextBox
            // 
            this.PasswordTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsPolzovateli, "Password", true));
            this.PasswordTextBox.Location = new System.Drawing.Point(70, 185);
            this.PasswordTextBox.Name = "PasswordTextBox";
            this.PasswordTextBox.Size = new System.Drawing.Size(183, 20);
            this.PasswordTextBox.TabIndex = 23;
            this.PasswordTextBox.UseSystemPasswordChar = true;
            // 
            // LoginTextBox
            // 
            this.LoginTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsPolzovateli, "Login", true));
            this.LoginTextBox.Location = new System.Drawing.Point(70, 142);
            this.LoginTextBox.Name = "LoginTextBox";
            this.LoginTextBox.Size = new System.Drawing.Size(183, 20);
            this.LoginTextBox.TabIndex = 21;
            // 
            // btn_Cansel
            // 
            this.btn_Cansel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(26)))));
            this.btn_Cansel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btn_Cansel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btn_Cansel.Location = new System.Drawing.Point(639, 365);
            this.btn_Cansel.Name = "btn_Cansel";
            this.btn_Cansel.Size = new System.Drawing.Size(149, 46);
            this.btn_Cansel.TabIndex = 36;
            this.btn_Cansel.Text = "Отмена";
            this.btn_Cansel.UseVisualStyleBackColor = false;
            // 
            // Btn_Reg
            // 
            this.Btn_Reg.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(26)))));
            this.Btn_Reg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Btn_Reg.Location = new System.Drawing.Point(639, 313);
            this.Btn_Reg.Name = "Btn_Reg";
            this.Btn_Reg.Size = new System.Drawing.Size(149, 46);
            this.Btn_Reg.TabIndex = 35;
            this.Btn_Reg.Text = "Зарегистрировать";
            this.Btn_Reg.UseVisualStyleBackColor = false;
            this.Btn_Reg.Click += new System.EventHandler(this.Btn_Reg_Click);
            // 
            // bsPolzovateli
            // 
            this.bsPolzovateli.DataMember = "Polzovateli";
            this.bsPolzovateli.DataSource = this.univermagDataSet;
            // 
            // univermagDataSet
            // 
            this.univermagDataSet.DataSetName = "UnivermagDataSet";
            this.univermagDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // polzovateliTableAdapter
            // 
            this.polzovateliTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
        
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.DirectorTableAdapter = null;
            this.tableAdapterManager.KnigiTableAdapter = null;
           
            
            this.tableAdapterManager.PolzovateliTableAdapter = this.polzovateliTableAdapter;
            this.tableAdapterManager.TekstilnijMirTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = SUBD_Univermag.UnivermagDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            
            // 
            // lblRole
            // 
            this.lblRole.AutoSize = true;
            this.lblRole.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsPolzovateli, "Role", true));
            this.lblRole.Location = new System.Drawing.Point(891, 184);
            this.lblRole.Name = "lblRole";
            this.lblRole.Size = new System.Drawing.Size(35, 13);
            this.lblRole.TabIndex = 37;
            this.lblRole.Text = "label3";
            // 
            // famLabel
            // 
            famLabel.AutoSize = true;
            famLabel.Location = new System.Drawing.Point(15, 272);
            famLabel.Name = "famLabel";
            famLabel.Size = new System.Drawing.Size(59, 13);
            famLabel.TabIndex = 37;
            famLabel.Text = "Фамилия:";
            // 
            // nameLabel
            // 
            nameLabel.AutoSize = true;
            nameLabel.Location = new System.Drawing.Point(15, 306);
            nameLabel.Name = "nameLabel";
            nameLabel.Size = new System.Drawing.Size(32, 13);
            nameLabel.TabIndex = 38;
            nameLabel.Text = "Имя:";
            // 
            // otchLabel
            // 
            otchLabel.AutoSize = true;
            otchLabel.Location = new System.Drawing.Point(15, 341);
            otchLabel.Name = "otchLabel";
            otchLabel.Size = new System.Drawing.Size(57, 13);
            otchLabel.TabIndex = 39;
            otchLabel.Text = "Отчество:";
            // 
            // tbxFam
            // 
            this.tbxFam.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsPolzovateli, "Fam", true));
            this.tbxFam.Location = new System.Drawing.Point(78, 272);
            this.tbxFam.Name = "tbxFam";
            this.tbxFam.Size = new System.Drawing.Size(175, 20);
            this.tbxFam.TabIndex = 40;
            // 
            // tbxName
            // 
            this.tbxName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsPolzovateli, "Name", true));
            this.tbxName.Location = new System.Drawing.Point(78, 303);
            this.tbxName.Name = "tbxName";
            this.tbxName.Size = new System.Drawing.Size(175, 20);
            this.tbxName.TabIndex = 41;
            // 
            // tbxOtch
            // 
            this.tbxOtch.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsPolzovateli, "Otch", true));
            this.tbxOtch.Location = new System.Drawing.Point(78, 338);
            this.tbxOtch.Name = "tbxOtch";
            this.tbxOtch.Size = new System.Drawing.Size(175, 20);
            this.tbxOtch.TabIndex = 42;
            // 
            // FormRegNewRab
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(802, 431);
            this.Controls.Add(this.tbxOtch);
            this.Controls.Add(this.tbxName);
            this.Controls.Add(this.tbxFam);
            this.Controls.Add(otchLabel);
            this.Controls.Add(nameLabel);
            this.Controls.Add(famLabel);
            this.Controls.Add(this.lblRole);
            this.Controls.Add(this.btn_Cansel);
            this.Controls.Add(this.Btn_Reg);
            this.Controls.Add(this.cbxShowPass);
            this.Controls.Add(label2);
            this.Controls.Add(this.tbxProverkaPass);
            this.Controls.Add(this.tbxPhone);
            this.Controls.Add(phoneLabel);
            this.Controls.Add(passwordLabel);
            this.Controls.Add(this.PasswordTextBox);
            this.Controls.Add(loginLabel);
            this.Controls.Add(this.LoginTextBox);
            this.Controls.Add(this.panel1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormRegNewRab";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "FormRegNewRab";
            this.Load += new System.EventHandler(this.FormRegNewRab_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsPolzovateli)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.univermagDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.CheckBox cbxShowPass;
        private System.Windows.Forms.TextBox tbxProverkaPass;
        private System.Windows.Forms.MaskedTextBox tbxPhone;
        private System.Windows.Forms.TextBox PasswordTextBox;
        private System.Windows.Forms.TextBox LoginTextBox;
        private System.Windows.Forms.Button btn_Cansel;
        private System.Windows.Forms.Button Btn_Reg;
        private System.Windows.Forms.BindingSource bsPolzovateli;
        private UnivermagDataSet univermagDataSet;
        private UnivermagDataSetTableAdapters.PolzovateliTableAdapter polzovateliTableAdapter;
        private UnivermagDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.Label lblRole;
        private System.Windows.Forms.TextBox tbxFam;
        private System.Windows.Forms.TextBox tbxName;
        private System.Windows.Forms.TextBox tbxOtch;
    }
}