﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Word = Microsoft.Office.Interop.Word;

namespace SUBD_Univermag
{
    public partial class FormFormirDockTkani : Form
    {
        public FormFormirDockTkani()
        {
            InitializeComponent();
        }

        private void tekstilnijMirBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tekstilnijMirBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.univermagDataSet);

        }

        private void FormFormirDockTkani_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "univermagDataSet.Polzovateli". При необходимости она может быть перемещена или удалена.
            this.polzovateliTableAdapter.Fill(this.univermagDataSet.Polzovateli);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "univermagDataSet.TekstilnijMir". При необходимости она может быть перемещена или удалена.
            this.tekstilnijMirTableAdapter.Fill(this.univermagDataSet.TekstilnijMir);

        }

        private void btnFormDoc_Click(object sender, EventArgs e)
        {
            DataRowView drv = (DataRowView)polzovateliBindingSource.Current;
            string date = DateTime.Now.ToShortDateString();
           
            Word.Application wordapp = new Word.Application();
            wordapp.Visible = true;
            Word.Document doc = wordapp.Documents.Open(Application.StartupPath + "\\Заявка на списание.docx", null, true);

            Word.Bookmarks WBmark = doc.Bookmarks; //закладки
            
            WBmark["Oborud"].Range.Text = nameTkanTextBox.Text;
            WBmark["Date"].Range.Text = date;
            WBmark["Prichin"].Range.Text = textBoxPricchina.Text;
        }
    }
}
