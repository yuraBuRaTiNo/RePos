﻿namespace SUBD_Univermag
{
    partial class FormFormirDockTkani
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label nameTkanLabel;
            System.Windows.Forms.Label colorLabel;
            System.Windows.Forms.Label label2;
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.univermagDataSet = new SUBD_Univermag.UnivermagDataSet();
            this.tekstilnijMirBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tekstilnijMirTableAdapter = new SUBD_Univermag.UnivermagDataSetTableAdapters.TekstilnijMirTableAdapter();
            this.tableAdapterManager = new SUBD_Univermag.UnivermagDataSetTableAdapters.TableAdapterManager();
            this.nameTkanTextBox = new System.Windows.Forms.TextBox();
            this.colorTextBox = new System.Windows.Forms.TextBox();
            this.btnFormDoc = new System.Windows.Forms.Button();
            this.polzovateliBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.polzovateliTableAdapter = new SUBD_Univermag.UnivermagDataSetTableAdapters.PolzovateliTableAdapter();
            this.textBoxPricchina = new System.Windows.Forms.TextBox();
            nameTkanLabel = new System.Windows.Forms.Label();
            colorLabel = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.univermagDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tekstilnijMirBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.polzovateliBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(800, 128);
            this.panel1.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(191, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(337, 37);
            this.label1.TabIndex = 1;
            this.label1.Text = "Списание материала";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Left;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(167, 128);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // univermagDataSet
            // 
            this.univermagDataSet.DataSetName = "UnivermagDataSet";
            this.univermagDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tekstilnijMirBindingSource
            // 
            this.tekstilnijMirBindingSource.DataMember = "TekstilnijMir";
            this.tekstilnijMirBindingSource.DataSource = this.univermagDataSet;
            // 
            // tekstilnijMirTableAdapter
            // 
            this.tekstilnijMirTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.DirectorTableAdapter = null;
            this.tableAdapterManager.KnigiTableAdapter = null;
            this.tableAdapterManager.PolzovateliTableAdapter = this.polzovateliTableAdapter;
            this.tableAdapterManager.TekstilnijMirTableAdapter = this.tekstilnijMirTableAdapter;
            this.tableAdapterManager.UpdateOrder = SUBD_Univermag.UnivermagDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // nameTkanLabel
            // 
            nameTkanLabel.AutoSize = true;
            nameTkanLabel.Location = new System.Drawing.Point(17, 149);
            nameTkanLabel.Name = "nameTkanLabel";
            nameTkanLabel.Size = new System.Drawing.Size(66, 13);
            nameTkanLabel.TabIndex = 5;
            nameTkanLabel.Text = "Name Tkan:";
            // 
            // nameTkanTextBox
            // 
            this.nameTkanTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tekstilnijMirBindingSource, "NameTkan", true));
            this.nameTkanTextBox.Location = new System.Drawing.Point(89, 146);
            this.nameTkanTextBox.Name = "nameTkanTextBox";
            this.nameTkanTextBox.Size = new System.Drawing.Size(100, 20);
            this.nameTkanTextBox.TabIndex = 6;
            // 
            // colorLabel
            // 
            colorLabel.AutoSize = true;
            colorLabel.Location = new System.Drawing.Point(49, 194);
            colorLabel.Name = "colorLabel";
            colorLabel.Size = new System.Drawing.Size(34, 13);
            colorLabel.TabIndex = 8;
            colorLabel.Text = "Color:";
            // 
            // colorTextBox
            // 
            this.colorTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tekstilnijMirBindingSource, "Color", true));
            this.colorTextBox.Location = new System.Drawing.Point(89, 191);
            this.colorTextBox.Name = "colorTextBox";
            this.colorTextBox.Size = new System.Drawing.Size(100, 20);
            this.colorTextBox.TabIndex = 9;
            // 
            // btnFormDoc
            // 
            this.btnFormDoc.Location = new System.Drawing.Point(38, 271);
            this.btnFormDoc.Name = "btnFormDoc";
            this.btnFormDoc.Size = new System.Drawing.Size(151, 23);
            this.btnFormDoc.TabIndex = 12;
            this.btnFormDoc.Text = "Сформировать документ";
            this.btnFormDoc.UseVisualStyleBackColor = true;
            this.btnFormDoc.Click += new System.EventHandler(this.btnFormDoc_Click);
            // 
            // polzovateliBindingSource
            // 
            this.polzovateliBindingSource.DataMember = "Polzovateli";
            this.polzovateliBindingSource.DataSource = this.univermagDataSet;
            // 
            // polzovateliTableAdapter
            // 
            this.polzovateliTableAdapter.ClearBeforeFill = true;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(35, 234);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(48, 13);
            label2.TabIndex = 13;
            label2.Text = "Prichina:";
            // 
            // textBoxPricchina
            // 
            this.textBoxPricchina.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tekstilnijMirBindingSource, "Shirina", true));
            this.textBoxPricchina.Location = new System.Drawing.Point(89, 231);
            this.textBoxPricchina.Name = "textBoxPricchina";
            this.textBoxPricchina.Size = new System.Drawing.Size(100, 20);
            this.textBoxPricchina.TabIndex = 14;
            // 
            // FormFormirDockTkani
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 542);
            this.Controls.Add(label2);
            this.Controls.Add(this.textBoxPricchina);
            this.Controls.Add(this.btnFormDoc);
            this.Controls.Add(colorLabel);
            this.Controls.Add(this.colorTextBox);
            this.Controls.Add(nameTkanLabel);
            this.Controls.Add(this.nameTkanTextBox);
            this.Controls.Add(this.panel1);
            this.Name = "FormFormirDockTkani";
            this.Text = "FormFormirDockTkani";
            this.Load += new System.EventHandler(this.FormFormirDockTkani_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.univermagDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tekstilnijMirBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.polzovateliBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private UnivermagDataSet univermagDataSet;
        private System.Windows.Forms.BindingSource tekstilnijMirBindingSource;
        private UnivermagDataSetTableAdapters.TekstilnijMirTableAdapter tekstilnijMirTableAdapter;
        private UnivermagDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.TextBox nameTkanTextBox;
        private System.Windows.Forms.TextBox colorTextBox;
        private System.Windows.Forms.Button btnFormDoc;
        private UnivermagDataSetTableAdapters.PolzovateliTableAdapter polzovateliTableAdapter;
        private System.Windows.Forms.BindingSource polzovateliBindingSource;
        private System.Windows.Forms.TextBox textBoxPricchina;
    }
}