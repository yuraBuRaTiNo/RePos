﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SUBD_Univermag
{
    public partial class FormPoiskRabotnika : Form
    {
        List<string> lstRab = new List<string>();

        public FormPoiskRabotnika()
        {
            InitializeComponent();
        }

        public static int Levenshtejn(string t1, string t2)
        {
            int CntLev = 0;

            CntLev += Math.Abs(t1.Length - t2.Length);

            for (int i = 0; i <= Math.Min(t1.Length, t2.Length) - 1; i++)
            {
                if (t1[i] != t2[i])
                {
                    CntLev++;
                }
            }
            return CntLev;
        }

        private void btnNechetPoisk_Click(object sender, EventArgs e)
        {
            dgvRab.Rows.Clear();


            for (int i = 0; i <= lstRab.Count - 1; i++)
            {
                int lev = Levenshtejn(tbxLevenshtejn.Text, lstRab[i]);
                if (lev <= 3)
                    dgvRab.Rows.Add(lstRab[i]);
            }
        }

        private void FormPoiskRabotnika_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(Properties.Settings.Default.UnivermagConnectionString);

            con.Open();

            SqlCommand q1 = new SqlCommand(string.Format(@"SELECT Fam
                                                                    from Polzovateli"), con);

            SqlDataReader res = q1.ExecuteReader();

            while (res.Read())
            {
                lstRab.Add(res["Fam"].ToString());
                dgvRab.Rows.Add(res["Fam"]);
            }

            con.Close();


        }

        private void ShowAll_Click(object sender, EventArgs e)
        {

            dgvRab.Rows.Clear();
            for (int i = 0; i <= lstRab.Count - 1; i++)
            {
                dgvRab.Rows.Add(lstRab[i]);
            }
        }
    }
}
