﻿namespace SUBD_Univermag
{
    partial class FormKnigi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnProfilPolzovatel = new System.Windows.Forms.Button();
            this.univermagDataSet = new SUBD_Univermag.UnivermagDataSet();
            this.bsPolzovateli = new System.Windows.Forms.BindingSource(this.components);
            this.polzovateliTableAdapter = new SUBD_Univermag.UnivermagDataSetTableAdapters.PolzovateliTableAdapter();
            this.tableAdapterManager = new SUBD_Univermag.UnivermagDataSetTableAdapters.TableAdapterManager();
            this.famLabel1 = new System.Windows.Forms.Label();
            this.nameLabel1 = new System.Windows.Forms.Label();
            this.otchLabel1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.btnAddZapis = new System.Windows.Forms.Button();
            this.btnSpisMaterial = new System.Windows.Forms.Button();
            this.btnNechetPoisk = new System.Windows.Forms.Button();
            this.dgvKnigi = new System.Windows.Forms.DataGridView();
            this.nazvanieKnigaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.authorDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.photoDataGridViewImageColumn = new System.Windows.Forms.DataGridViewImageColumn();
            this.knigiBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.knigiTableAdapter = new SUBD_Univermag.UnivermagDataSetTableAdapters.KnigiTableAdapter();
            this.btnFormDoc = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.univermagDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsPolzovateli)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKnigi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.knigiBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(800, 128);
            this.panel1.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(191, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(511, 37);
            this.label1.TabIndex = 1;
            this.label1.Text = "Рабочее место книжного отдела";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Left;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(167, 128);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // btnProfilPolzovatel
            // 
            this.btnProfilPolzovatel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(156)))), ((int)(((byte)(26)))));
            this.btnProfilPolzovatel.Location = new System.Drawing.Point(13, 240);
            this.btnProfilPolzovatel.Name = "btnProfilPolzovatel";
            this.btnProfilPolzovatel.Size = new System.Drawing.Size(154, 48);
            this.btnProfilPolzovatel.TabIndex = 12;
            this.btnProfilPolzovatel.Text = "Профиль пользователя";
            this.btnProfilPolzovatel.UseVisualStyleBackColor = false;
            this.btnProfilPolzovatel.Click += new System.EventHandler(this.btnProfilPolzovatel_Click);
            // 
            // univermagDataSet
            // 
            this.univermagDataSet.DataSetName = "UnivermagDataSet";
            this.univermagDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bsPolzovateli
            // 
            this.bsPolzovateli.DataMember = "Polzovateli";
            this.bsPolzovateli.DataSource = this.univermagDataSet;
            // 
            // polzovateliTableAdapter
            // 
            this.polzovateliTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.DirectorTableAdapter = null;
            this.tableAdapterManager.KnigiTableAdapter = null;
            this.tableAdapterManager.PolzovateliTableAdapter = this.polzovateliTableAdapter;
            this.tableAdapterManager.TekstilnijMirTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = SUBD_Univermag.UnivermagDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // famLabel1
            // 
            this.famLabel1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsPolzovateli, "Fam", true));
            this.famLabel1.Location = new System.Drawing.Point(74, 140);
            this.famLabel1.Name = "famLabel1";
            this.famLabel1.Size = new System.Drawing.Size(100, 23);
            this.famLabel1.TabIndex = 14;
            this.famLabel1.Text = "label2";
            // 
            // nameLabel1
            // 
            this.nameLabel1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsPolzovateli, "Name", true));
            this.nameLabel1.Location = new System.Drawing.Point(74, 178);
            this.nameLabel1.Name = "nameLabel1";
            this.nameLabel1.Size = new System.Drawing.Size(100, 23);
            this.nameLabel1.TabIndex = 15;
            this.nameLabel1.Text = "label2";
            // 
            // otchLabel1
            // 
            this.otchLabel1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsPolzovateli, "Otch", true));
            this.otchLabel1.Location = new System.Drawing.Point(74, 214);
            this.otchLabel1.Name = "otchLabel1";
            this.otchLabel1.Size = new System.Drawing.Size(100, 23);
            this.otchLabel1.TabIndex = 16;
            this.otchLabel1.Text = "label2";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.button1.Location = new System.Drawing.Point(193, 409);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(154, 48);
            this.button1.TabIndex = 31;
            this.button1.Text = "Редактировать запись ";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnAddZapis
            // 
            this.btnAddZapis.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnAddZapis.Location = new System.Drawing.Point(13, 409);
            this.btnAddZapis.Name = "btnAddZapis";
            this.btnAddZapis.Size = new System.Drawing.Size(154, 48);
            this.btnAddZapis.TabIndex = 30;
            this.btnAddZapis.Text = "Добавить запись";
            this.btnAddZapis.UseVisualStyleBackColor = false;
            this.btnAddZapis.Click += new System.EventHandler(this.btnAddZapis_Click);
            // 
            // btnSpisMaterial
            // 
            this.btnSpisMaterial.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(156)))), ((int)(((byte)(26)))));
            this.btnSpisMaterial.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnSpisMaterial.Location = new System.Drawing.Point(13, 355);
            this.btnSpisMaterial.Name = "btnSpisMaterial";
            this.btnSpisMaterial.Size = new System.Drawing.Size(154, 48);
            this.btnSpisMaterial.TabIndex = 29;
            this.btnSpisMaterial.Text = "Удалить запись";
            this.btnSpisMaterial.UseVisualStyleBackColor = false;
            this.btnSpisMaterial.Click += new System.EventHandler(this.btnSpisMaterial_Click);
            // 
            // btnNechetPoisk
            // 
            this.btnNechetPoisk.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(156)))), ((int)(((byte)(26)))));
            this.btnNechetPoisk.Location = new System.Drawing.Point(13, 301);
            this.btnNechetPoisk.Name = "btnNechetPoisk";
            this.btnNechetPoisk.Size = new System.Drawing.Size(154, 48);
            this.btnNechetPoisk.TabIndex = 28;
            this.btnNechetPoisk.Text = "Нечеткий поиск";
            this.btnNechetPoisk.UseVisualStyleBackColor = false;
            this.btnNechetPoisk.Click += new System.EventHandler(this.btnNechetPoisk_Click);
            // 
            // dgvKnigi
            // 
            this.dgvKnigi.AllowUserToAddRows = false;
            this.dgvKnigi.AllowUserToDeleteRows = false;
            this.dgvKnigi.AutoGenerateColumns = false;
            this.dgvKnigi.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvKnigi.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.nazvanieKnigaDataGridViewTextBoxColumn,
            this.authorDataGridViewTextBoxColumn,
            this.photoDataGridViewImageColumn});
            this.dgvKnigi.DataSource = this.knigiBindingSource;
            this.dgvKnigi.Location = new System.Drawing.Point(198, 140);
            this.dgvKnigi.Name = "dgvKnigi";
            this.dgvKnigi.ReadOnly = true;
            this.dgvKnigi.Size = new System.Drawing.Size(590, 263);
            this.dgvKnigi.TabIndex = 32;
            // 
            // nazvanieKnigaDataGridViewTextBoxColumn
            // 
            this.nazvanieKnigaDataGridViewTextBoxColumn.DataPropertyName = "NazvanieKniga";
            this.nazvanieKnigaDataGridViewTextBoxColumn.HeaderText = "NazvanieKniga";
            this.nazvanieKnigaDataGridViewTextBoxColumn.Name = "nazvanieKnigaDataGridViewTextBoxColumn";
            this.nazvanieKnigaDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // authorDataGridViewTextBoxColumn
            // 
            this.authorDataGridViewTextBoxColumn.DataPropertyName = "Author";
            this.authorDataGridViewTextBoxColumn.HeaderText = "Author";
            this.authorDataGridViewTextBoxColumn.Name = "authorDataGridViewTextBoxColumn";
            this.authorDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // photoDataGridViewImageColumn
            // 
            this.photoDataGridViewImageColumn.DataPropertyName = "Photo";
            this.photoDataGridViewImageColumn.HeaderText = "Photo";
            this.photoDataGridViewImageColumn.Name = "photoDataGridViewImageColumn";
            this.photoDataGridViewImageColumn.ReadOnly = true;
            // 
            // knigiBindingSource
            // 
            this.knigiBindingSource.DataMember = "Knigi";
            this.knigiBindingSource.DataSource = this.univermagDataSet;
            // 
            // knigiTableAdapter
            // 
            this.knigiTableAdapter.ClearBeforeFill = true;
            // 
            // btnFormDoc
            // 
            this.btnFormDoc.Location = new System.Drawing.Point(377, 409);
            this.btnFormDoc.Name = "btnFormDoc";
            this.btnFormDoc.Size = new System.Drawing.Size(154, 48);
            this.btnFormDoc.TabIndex = 33;
            this.btnFormDoc.Text = "Сформировать документ";
            this.btnFormDoc.UseVisualStyleBackColor = true;
            this.btnFormDoc.Click += new System.EventHandler(this.btnFormDoc_Click);
            // 
            // FormKnigi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 487);
            this.Controls.Add(this.btnFormDoc);
            this.Controls.Add(this.dgvKnigi);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnAddZapis);
            this.Controls.Add(this.btnSpisMaterial);
            this.Controls.Add(this.btnNechetPoisk);
            this.Controls.Add(this.otchLabel1);
            this.Controls.Add(this.nameLabel1);
            this.Controls.Add(this.famLabel1);
            this.Controls.Add(this.btnProfilPolzovatel);
            this.Controls.Add(this.panel1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormKnigi";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "FormKnigi";
            this.Load += new System.EventHandler(this.FormKnigi_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.univermagDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsPolzovateli)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKnigi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.knigiBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnProfilPolzovatel;
        private UnivermagDataSet univermagDataSet;
        private UnivermagDataSetTableAdapters.PolzovateliTableAdapter polzovateliTableAdapter;
        private UnivermagDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.Label famLabel1;
        private System.Windows.Forms.Label nameLabel1;
        private System.Windows.Forms.Label otchLabel1;
        public System.Windows.Forms.BindingSource bsPolzovateli;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnAddZapis;
        private System.Windows.Forms.Button btnSpisMaterial;
        private System.Windows.Forms.Button btnNechetPoisk;
        private System.Windows.Forms.DataGridView dgvKnigi;
        private System.Windows.Forms.BindingSource knigiBindingSource;
        private UnivermagDataSetTableAdapters.KnigiTableAdapter knigiTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn nazvanieKnigaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn authorDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewImageColumn photoDataGridViewImageColumn;
        private System.Windows.Forms.Button btnFormDoc;
    }
}