﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SUBD_Univermag
{
    public partial class FormRedaktZapisTekstMir : Form
    {
        public FormRedaktZapisTekstMir()
        {
            InitializeComponent();
        }

        private void tekstilnijMirBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tekstilnijMirBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.univermagDataSet);

        }

        private void FormRedaktZapisTekstMir_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "univermagDataSet.TekstilnijMir". При необходимости она может быть перемещена или удалена.
            this.tekstilnijMirTableAdapter.Fill(this.univermagDataSet.TekstilnijMir);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(nameTkanTextBox.Text == "" || dlinaTextBox.Text == "" || shirinaTextBox.Text == "" || colorTextBox.Text == "")
            {
                MessageBox.Show("Заполните все поля!");
            }
            tekstilnijMirBindingSource.EndEdit();

            this.tekstilnijMirTableAdapter.Update(this.univermagDataSet.TekstilnijMir);

            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
