﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SUBD_Univermag
{
    public partial class FormAddBooks : Form
    {
        public FormAddBooks()
        {
            InitializeComponent();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if (tbxName.Text == "" || tbxAuthor.Text == "" )
            {
                MessageBox.Show("Не заполнены все поля!", "Внимание!");
                return;
            }
        }
    }
}
