﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SUBD_Univermag
{
    public partial class FormDirector : Form
    {
        public FormDirector()
        {
            InitializeComponent();
        }

        private void directorBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
           
            this.tableAdapterManager.UpdateAll(this.univermagDataSet);

        }

        private void FormDirector_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "univermagDataSet.Polzovateli". При необходимости она может быть перемещена или удалена.
            this.polzovateliTableAdapter.Fill(this.univermagDataSet.Polzovateli);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "univermagDataSet.Director". При необходимости она может быть перемещена или удалена.
            

        }

        private void polzovateliBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.bsPolzovateli.EndEdit();
            this.tableAdapterManager.UpdateAll(this.univermagDataSet);

        }

        private void btnProfilPolzovatel_Click(object sender, EventArgs e)
        {
            FormProfile frmprof = new FormProfile();
            frmprof.bsPolzovateli.Filter = this.bsPolzovateli.Filter;
            if (frmprof.ShowDialog() == DialogResult.OK)
            {
                this.polzovateliTableAdapter.Fill(this.univermagDataSet.Polzovateli);
            }
        }

        private void btnNechetPoisk_Click(object sender, EventArgs e)
        {
            FormPoiskRabotnika frm = new FormPoiskRabotnika();

            frm.ShowDialog();
        }

        private void btnSpisMaterial_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow drw in dgvTkani.SelectedRows)
            {
                MessageBox.Show("Удалить выделенную запись?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                dgvTkani.Rows.Remove(drw);

            }

            this.polzovateliTableAdapter.Update(this.univermagDataSet.Polzovateli);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string idTkan = "-1";

            try
            {
                idTkan = dgvTkani.CurrentRow.Cells[0].Value.ToString();
            }

            catch { MessageBox.Show("Для редактирования выделите эелемент в таблице"); return; }

            FormRedaktZapisDirik frm = new FormRedaktZapisDirik();

            

            if (frm.ShowDialog() == DialogResult.OK)
            {
                dgvTkani.Rows.Clear();

                FormDirector_Load(null, null);
            }

        }
    }
}
