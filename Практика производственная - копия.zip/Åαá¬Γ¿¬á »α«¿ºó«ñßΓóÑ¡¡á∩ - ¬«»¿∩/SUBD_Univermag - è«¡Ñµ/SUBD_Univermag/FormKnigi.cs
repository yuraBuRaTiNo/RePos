﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SUBD_Univermag
{
    public partial class FormKnigi : Form
    {
        public FormKnigi()
        {
            InitializeComponent();
        }

        private void polzovateliBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.bsPolzovateli.EndEdit();
            this.tableAdapterManager.UpdateAll(this.univermagDataSet);

        }

        private void FormKnigi_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "univermagDataSet.Knigi". При необходимости она может быть перемещена или удалена.
            this.knigiTableAdapter.Fill(this.univermagDataSet.Knigi);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "univermagDataSet.Polzovateli". При необходимости она может быть перемещена или удалена.
            this.polzovateliTableAdapter.Fill(this.univermagDataSet.Polzovateli);

        }

        private void btnProfilPolzovatel_Click(object sender, EventArgs e)
        {
            FormProfile frmprof = new FormProfile();
            frmprof.bsPolzovateli.Filter = this.bsPolzovateli.Filter;
            if (frmprof.ShowDialog() == DialogResult.OK)
            {
                this.polzovateliTableAdapter.Fill(this.univermagDataSet.Polzovateli);
            }
        }

        private void btnNechetPoisk_Click(object sender, EventArgs e)
        {
            FormPoiskKnigi frm = new FormPoiskKnigi();

            frm.ShowDialog();
        }

        private void btnSpisMaterial_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow drw in dgvKnigi.SelectedRows)
            {
                MessageBox.Show("Удалить выделенную запись?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                dgvKnigi.Rows.Remove(drw);

            }
          

            this.knigiTableAdapter.Update(this.univermagDataSet.Knigi);
        }

        private void btnAddZapis_Click(object sender, EventArgs e)
        {

            FormAddBooks frm = new FormAddBooks();

            if (frm.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    SqlConnection con = new SqlConnection(Properties.Settings.Default.UnivermagConnectionString);
                    con.Open();

                    SqlCommand query = new SqlCommand($@"Insert into Knigi values('{frm.tbxName.Text}','{frm.tbxAuthor.Text}','false', null)", con);
                    query.ExecuteNonQuery();
                    con.Close();
                    dgvKnigi.Rows.Clear();

                    FormKnigi_Load(null, null);
                }
                catch
                {
                    MessageBox.Show("упс, что-то пошло не так, попробуй еще раз!");
                }

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string idTkan = "-1";

            try
            {
                idTkan = dgvKnigi.CurrentRow.Cells[0].Value.ToString();
            }

            catch { MessageBox.Show("Для редактирования выделите эелемент в таблице"); return; }

            FormRedaktZapisKnigi frm = new FormRedaktZapisKnigi();



            if (frm.ShowDialog() == DialogResult.OK)
            {
                dgvKnigi.Rows.Clear();

                FormKnigi_Load(null, null);
            }
        }

        private void btnFormDoc_Click(object sender, EventArgs e)
        {
            FormFromirDockKnigi frm = new FormFromirDockKnigi();

            frm.ShowDialog();
        }
    }
}
