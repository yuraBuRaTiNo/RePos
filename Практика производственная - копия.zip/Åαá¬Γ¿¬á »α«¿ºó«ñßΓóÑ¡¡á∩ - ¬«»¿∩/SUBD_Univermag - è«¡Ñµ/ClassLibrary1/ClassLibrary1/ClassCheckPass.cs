﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class ClassCheckPass
    {
       public static bool CheckPass(string pass)
        {
            if (pass.Length < 6)
                return false;

            bool fUpper = false, fDigit = false, Fsimvol = false;

            foreach (char c in pass)
            {
                if (char.IsUpper(c))
                    fUpper = true;
                if (char.IsDigit(c))
                    fDigit = true;
                if ("!@#$%^".IndexOf(c) > -1)
                    Fsimvol = true;
            }
            return fUpper && fDigit && Fsimvol;
        }
    }
}
